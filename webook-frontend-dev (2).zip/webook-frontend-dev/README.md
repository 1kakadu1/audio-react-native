# WeBook frontend

## Стек
* Стейтменеджер - **[redux-toolkit](https://redux-toolkit.js.org/introduction/getting-started)**
* Навигация - **[react-navigation](https://reactnavigation.org/docs/getting-started/)**

## Скрипты

##### Установка зависимостей
```shell script
yarn
```

##### Установка husky для pre-commit-хука (обязательно)
```shell script
yarn prepare
```

##### Запуск сервера для разработки под android
```shell script
yarn android
```

##### Запуск сервера для разработки под ios
```shell script
yarn ios
```

##### Запуск линтера
```shell script
yarn lint
```

##### Запуск prettier для проекта
```shell script
yarn format
```

## Структура
* **src** - все исходники
  * **api** - слой работы с api
      * endpoints - эндпоинты api
      * methods - методы api
  * **assets** - шрифты, изображения, общие стили
  * **components** - папка с компонентами приложения
    * features - компоненты отдельных страниц
    * shared - переиспользуемые между страницами компоненты
    * templates - основные компоненты приложения, компоненты для общего шаблона
  * **contexts** - контексты
  * **constants** - константы
  * **helpers** - небольшие вспомогательные функции
  * **hocs** - компоненты высшего порядка - подключение прелоадера, предзагрузка информации, etc
  * **hooks** - кастомные хуки
  * **interfaces** - переиспользуемые интерфейсы приложения
  * **layouts** - базовые компоненты-обертки
  * **mock** - моковые данные
  * **routes** - роуты
  * **screens** - страницы приложения
  * **store** - всё, что относится к Redux
  * **utils** - глобальные вспомогательные функции, утилиты, конфигурации

## Code style
* Для соблюдения единого стиля кода есть eslint, для форматирования - prettier
* Стоит pre-commit hook с валидацией и форматированием (убедитесь, что он включен в вашем редакторе кода)

## Разработка
* Работа с SVG
  * Для SVG-иконок, вставленных как react-компонент, в исходном коде изображения заменить значения fill или stroke на currentColor
  * Для управления цветом у компонента с иконкой используем параметр "color"
* Работа с PNG и JPEG
  * Для уменьшения размера приложения все PNG и JPEG изображения необходимо конвертировать в WEBP
* Debug
  * Для отслеживания состояний redux, логов и сетевых запросов необходимо установить React native debugger  https://github.com/jhen0409/react-native-debugger/releases

## Конфигурация

**VSCode**: https://wiki.spectr.dev/pages/viewpage.action?pageId=27296013

**WebStorm**: https://wiki.spectr.dev/pages/viewpage.action?pageId=27296015
