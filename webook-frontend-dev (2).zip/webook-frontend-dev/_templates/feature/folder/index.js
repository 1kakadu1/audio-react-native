module.exports = {
  prompt: async ({ inquirer }) => {
    const { folderName } = await inquirer.prompt({
      type: 'input',
      name: 'folderName',
      message: 'Enter a folder name',
    })
    if (!folderName) throw new Error('Folder name is required!')
    const { name } = await inquirer.prompt({
      type: 'input',
      name: 'name',
      message: 'Enter a component name',
    })
    if (!name) throw new Error()
    return {
      src: `src/components/features/${folderName}/${name}`,
      name,
      folderName,
    }
  },
}
