import { Lecture } from 'interfaces/api/catalog.interfaces'

export type AudioLocal = Record<number, Lecture>

export interface AudioProgressData {
  id: number
  progress: number
}

export type AudioProgress = Record<number, number>
