import { LoginData, PhoneData, RegisterData } from 'interfaces/api/auth.interfaces'

export interface SendPhoneParams {
  data: PhoneData
  onSuccess?: VoidFunction
}

export interface LoginParams {
  data: LoginData
  onSuccess?: VoidFunction
}

export interface RegisterParams {
  data: RegisterData
  onSuccess?: VoidFunction
}
