export interface CategoryBase {
  id: number
  title: string
  image: string | null
  preview: string | null
  coursesCount: number
  lectionsCount: number
  totalDuration: number | null
  isPublished: boolean
}

export interface Category {
  id: number
  title: string
  image: string | null
  preview: string | null
  description?: string | null
  lections: Lecture[]
  courses: CategoryBase[]
  totalDuration: number
  isPublished: boolean
}

export interface Lecture {
  id: number
  title: string
  image: string | null
  preview: string | null
  description?: string
  duration: number
  price: string | null
  createdAt: string
  updatedAt: string
  audioUpdatedAt: string | null
  isPublished: boolean
  audio: string
  courseTitle?: string
  isPurchased?: boolean
  onlyInSubscription: boolean
}
