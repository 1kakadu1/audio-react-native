export interface OrderPayVerificationData {
  payGateway: string
  order: { id: number; status: string; userID: number; [key: string]: unknown }
}

export interface OrderPayVerificationCallbackData {
  order_id: string
}

export interface OrderSuccesData {
  success: boolean
  token: OrderToken
}

export interface OrderToken {
  expirationDate: string
  identifier: string
  userId: number
}

export interface OrderSubscribeData {
  id: number
  name: string
  price: number
}
