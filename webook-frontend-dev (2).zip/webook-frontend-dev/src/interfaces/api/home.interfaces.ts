import { Lecture } from './catalog.interfaces'

export interface HomeBlockBase {
  id: number
  title: string
  slug: string
}

export interface HomeBlock extends HomeBlockBase {
  lections: Lecture[]
}
