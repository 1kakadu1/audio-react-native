export interface User {
  id: number
  name: string
  phone: string
  email: string | null
  registerNumber: string | null
  emailVerifiedAt: string | null
  createdAt: string
  updatedAt: string | null
  isVerified: boolean
  totalListened: number
  activeSub: {
    expiredAt: string
    id: number
    name: string
  } | null
}

export interface UserEditData {
  name: string
  phone: string
  email: string
  registerNumber?: string
}

export interface UserEditResponse extends UserEditData {
  id: number
}

export interface UserListeningTime {
  year: number
  totalListeningTime: number
  canDownloadCertificate: boolean
}
