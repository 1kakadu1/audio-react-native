export interface Card {
  cardNumber: string
  cardType: string
}
