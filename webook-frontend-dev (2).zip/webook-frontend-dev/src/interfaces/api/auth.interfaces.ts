export interface PhoneData {
  phone: string
  device: string
}

export interface LoginData {
  phone: string
  code: string
  device: string
}

export interface RegisterForm {
  name: string
  email: string
  registerNumber?: string
}

export interface RegisterData {
  name: string
  device: string
  code: string
  phone: string
  email: string
  registerNumber?: string
}

export interface TokenResponse {
  token: string
  expirationSeconds: number
  expirationAt: string
}
