import { Lecture } from './catalog.interfaces'

export interface IBannerItem {
  id: number
  position: number
  image: string
  lection?: Lecture | null
}
