export interface StaticPageBase {
  id: number
  title: string
  slug: string
}

export interface StaticPage extends StaticPageBase {
  content: string
  createdAt: string
  updatedAt: string
}
