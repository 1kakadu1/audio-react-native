export type NoParamEndpointConstructor = () => string
export type SingleParamEndpointConstructor = (param1: string | number) => string
export type TwoParamEndpointConstructor = (param1: string | number, param2: string | number) => string

export type GetNoResponse = Promise<void>
export type GetOneResponse<T> = Promise<T>
export type GetArrayResponse<T> = Promise<T[]>

export interface GetArrayData<T> {
  data: T[]
}

export interface GetObjectData<T> {
  data: T
}

export interface Pagination {
  page?: number
  perPage?: number
}

export type ValidationErrors = Record<string, string> | null | undefined
