import { WebViewNavigation } from 'react-native-webview'

import { NativeStackNavigationProp } from '@react-navigation/native-stack'
import { Routes } from 'routes/routes'

import { Lecture } from './api/catalog.interfaces'

export type RootNavigationParamList = {
  [Routes.Home]: undefined
  [Routes.Main]: undefined
  [Routes.Catalog]: undefined
  [Routes.Categories]: undefined
  [Routes.Category]: { categoryId: number }
  [Routes.Course]: { courseId: number }
  [Routes.UserLectures]: undefined
  [Routes.Lectures]: undefined
  [Routes.Profile]: undefined
  [Routes.Login]: undefined
  [Routes.ConfirmPhone]: { phone: string }
  [Routes.Register]: { phone: string; code: string }
  [Routes.Lecture]: { lecture: Lecture; lecturesList: Lecture[] }
  [Routes.LectureDesc]: { lecture: Lecture }
  [Routes.Static]: { slug: string; isPublic?: boolean }
  [Routes.Statics]: undefined
  [Routes.User]: undefined
  [Routes.Purchase]: {
    price?: string | null
    subscriptionId?: string | number | null
    isSubscription?: boolean
    lectureId?: number
    title?: string
    onSuccess?: () => void
    goBack?: boolean
    isCard?: boolean
  }
  [Routes.CardPurchase]: {
    price?: string | null
    subscriptionId?: string | number | null
    isSubscription?: boolean
    lectureId?: number
    title?: string
    onSuccess?: () => void
    goBack?: boolean
    isCard?: boolean
  }
  [Routes.Payment]: { uri: string; onNavigationStateChange: (value: WebViewNavigation) => void }
  [Routes.LegalAssistance]: undefined
  [Routes.ProfileEdit]: undefined
}

export type Navigation = NativeStackNavigationProp<RootNavigationParamList, Routes, any>
