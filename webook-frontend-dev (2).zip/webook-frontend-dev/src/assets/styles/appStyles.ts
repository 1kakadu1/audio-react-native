import { StyleSheet } from 'react-native'

import { mainIndent } from 'constants/app'
import { colors } from 'constants/colors'

export const appStyles = StyleSheet.create({
  text10: {
    fontSize: 10,
    lineHeight: 12.8,
  },
  text12: {
    fontSize: 12,
    lineHeight: 14.4,
  },
  text13: {
    fontSize: 13,
    lineHeight: 15.6,
  },
  text14: {
    fontSize: 14,
    lineHeight: 16.8,
  },
  text16: {
    fontSize: 16,
    lineHeight: 22.4,
  },
  text18: {
    color: colors.white,
    fontSize: 18,
    lineHeight: 21.6,
  },
  text20: {
    fontSize: 20,
    lineHeight: 24,
  },
  text22: {
    fontSize: 22,
    lineHeight: 24.2,
  },
  text24: {
    fontSize: 24,
    lineHeight: 28.8,
  },
  text26: {
    fontSize: 26,
    lineHeight: 28.6,
  },
  text28: {
    fontSize: 28,
    lineHeight: 30.2,
  },
  text30: {
    fontSize: 30,
    lineHeight: 34,
  },
  text32: {
    fontSize: 32,
    lineHeight: 38.4,
  },
  text35: {
    fontSize: 35,
    lineHeight: 44.8,
  },

  textWeight400: {
    fontFamily: 'Onest-Regular',
    fontWeight: '400',
  },
  textWeight500: {
    fontFamily: 'Onest-Medium',
    fontWeight: '500',
  },
  textWeight600: {
    fontFamily: 'Onest-SemiBold',
    fontWeight: '600',
  },
  textWeight700: {
    fontFamily: 'Onest-Bold',
    fontWeight: '700',
  },
  textWeight800: {
    fontFamily: 'Onest-ExtraBold',
    fontWeight: '800',
  },

  textShadow: {
    textShadowColor: colors.black,
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 8,
  },

  flex1: {
    flex: 1,
  },
  mainMarginTop: {
    marginTop: 90,
  },
  mainMarginBottom: {
    marginBottom: 76,
  },
  mainPaddingBottom: {
    paddingBottom: mainIndent,
  },
  mainPaddingHorizontal: {
    paddingHorizontal: mainIndent,
  },
  mainBackground: {
    backgroundColor: colors.darkGray4,
  },
  secondBackground: {
    backgroundColor: colors.black,
  },

  tabBarStyle: {
    backgroundColor: colors.black,
    bottom: 0,
    height: 76,
    paddingBottom: 20,
    paddingTop: 8,
    position: 'absolute',
  },

  flexGrow1: {
    flexGrow: 1,
  },
})
