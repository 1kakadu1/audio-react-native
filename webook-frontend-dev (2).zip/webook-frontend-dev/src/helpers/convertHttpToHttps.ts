export const convertHttpToHttps = (url: string): string => {
  if (url.startsWith('http://')) {
    return url.replace('http://', 'https://')
  } else {
    return url
  }
}
