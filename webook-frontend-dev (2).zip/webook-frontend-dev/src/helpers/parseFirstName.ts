export const parseFirstName = (fullName?: string): string => {
  if (!fullName) {
    return ''
  }
  const nameParts = fullName.trim().split(/\s+/)
  return nameParts.length > 1 ? nameParts[1] : fullName
}
