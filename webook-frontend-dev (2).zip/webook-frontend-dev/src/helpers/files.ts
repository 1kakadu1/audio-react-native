import { deleteAsync, documentDirectory, getInfoAsync, readDirectoryAsync } from 'expo-file-system'

export const clearDirectory = async (directoryPath = documentDirectory) => {
  if (!directoryPath) {
    return
  }

  try {
    const files = await readDirectoryAsync(directoryPath)

    for (const fileName of files) {
      const filePath = `${directoryPath}/${fileName}`
      const fileInfo = await getInfoAsync(filePath)

      if (!fileInfo.isDirectory) {
        await deleteAsync(filePath, { idempotent: true })
      }
    }
  } catch (error) {
    console.error('Ошибка при удалении файлов:', error)
  }
}

export const deleteFile = async (filePath: string) => {
  try {
    await deleteAsync(filePath, { idempotent: true })
  } catch (error) {
    console.error('Ошибка при удалении файла:', error)
  }
}
