import { FC, ReactElement, useEffect } from 'react'
import { Keyboard } from 'react-native'

import { useDownloadContext } from 'contexts/DownloadContext'
import { useAppDispatch, useAppSelector } from 'store'
import { clearToken, setIsLoggedIn } from 'store/auth/actions'
import { getCardUser, getUser } from 'store/user/actions'
import { removeToken, setAxiosAuthHeader } from 'utils/axios'
import { eventBus } from 'utils/eventBus'

export function withAuth<T = any>(Component: FC<T>) {
  return (props: JSX.IntrinsicAttributes & T): ReactElement => {
    const { token } = useAppSelector((state) => state.auth)

    const dispatch = useAppDispatch()

    const { setDownloadProgress, setDownloadQueue } = useDownloadContext()

    const clearPersisterToken = () => {
      dispatch(clearToken())
    }

    useEffect(() => {
      setAxiosAuthHeader(token)
      if (token) {
        Keyboard.dismiss()
      }
      setTimeout(() => {
        if (token) {
          dispatch(setIsLoggedIn(true))
          dispatch(getUser()).then(() => {
            dispatch(getCardUser())
          })
        } else {
          dispatch(setIsLoggedIn(false))
          removeToken()
          setDownloadQueue([])
          setDownloadProgress({})
        }
      }, 500)
    }, [token])

    useEffect(() => {
      eventBus.on('authError', clearPersisterToken)
      return () => {
        eventBus.off('authError', clearPersisterToken)
      }
    }, [])

    return <Component {...props} />
  }
}
