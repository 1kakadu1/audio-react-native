import { FC, ReactElement } from 'react'
import { SafeAreaProvider } from 'react-native-safe-area-context'
import SystemNavigationBar from 'react-native-system-navigation-bar'
import { Provider } from 'react-redux'

import { NavigationContainer } from '@react-navigation/native'
import { Loader } from 'components/shared/Loader'
import { DownloadContainer } from 'components/templates/DownloadContainer'
import { colors } from 'constants/colors'
import { AudioPlayerProvider } from 'contexts/AudioPlayerContext'
import { DownloadProvider } from 'contexts/DownloadContext'
import { StatusBar } from 'expo-status-bar'
import { PersistGate } from 'redux-persist/integration/react'
import { persistor, store } from 'store'

export function withProviders<T = any>(Component: FC<T>) {
  SystemNavigationBar.setNavigationColor(colors.black)
  SystemNavigationBar.setNavigationBarDividerColor(colors.black)

  return (props: JSX.IntrinsicAttributes & T): ReactElement => (
    <Provider store={store}>
      <StatusBar style="light" translucent />
      <PersistGate loading={<Loader />} persistor={persistor}>
        <NavigationContainer>
          <DownloadProvider>
            <AudioPlayerProvider>
              <SafeAreaProvider>
                <Component {...props} />
                <DownloadContainer />
              </SafeAreaProvider>
            </AudioPlayerProvider>
          </DownloadProvider>
        </NavigationContainer>
      </PersistGate>
    </Provider>
  )
}
