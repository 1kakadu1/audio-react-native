import { NoParamEndpointConstructor } from 'interfaces/api.interfaces'

const baseUrl = 'user'
const baseEditUrl = 'profile'

interface Endpoints {
  getUser: NoParamEndpointConstructor
  putUser: NoParamEndpointConstructor
  getListeningTime: NoParamEndpointConstructor
  getCertificate: NoParamEndpointConstructor
}

export const userEndpoints: Endpoints = {
  getUser: () => baseUrl,
  putUser: () => baseEditUrl,
  getListeningTime: () => baseEditUrl + '/listening-time',
  getCertificate: () => baseEditUrl + '/certificate',
}
