import { NoParamEndpointConstructor } from 'interfaces/api.interfaces'

const baseUrl = 'banner'

interface Endpoints {
  getBanners: NoParamEndpointConstructor
}

export const bannerEndpoints: Endpoints = {
  getBanners: () => `${baseUrl}`,
}
