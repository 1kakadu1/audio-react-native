import { NoParamEndpointConstructor, SingleParamEndpointConstructor } from 'interfaces/api.interfaces'

const baseUrl = 'catalog'
const categoriesUrl = 'categories'
const lectureUrl = 'lections'

interface Endpoints {
  getCategories: NoParamEndpointConstructor
  getCategory: SingleParamEndpointConstructor
  getLecture: SingleParamEndpointConstructor
}

export const catalogEndpoints: Endpoints = {
  getCategories: () => `${baseUrl}/${categoriesUrl}`,
  getCategory: (id) => `${baseUrl}/${categoriesUrl}/${id}`,
  getLecture: (id) => `${baseUrl}/${lectureUrl}/${id}`,
}
