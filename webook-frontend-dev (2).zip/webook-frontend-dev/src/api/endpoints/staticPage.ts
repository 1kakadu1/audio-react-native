import { NoParamEndpointConstructor, SingleParamEndpointConstructor } from 'interfaces/api.interfaces'

const baseUrl = 'static_pages'

interface Endpoints {
  getStaticPage: SingleParamEndpointConstructor
  getStaticPages: NoParamEndpointConstructor
}

export const staticPageEndpoints: Endpoints = {
  getStaticPage: (slug) => `${baseUrl}/${slug}`,
  getStaticPages: () => baseUrl,
}
