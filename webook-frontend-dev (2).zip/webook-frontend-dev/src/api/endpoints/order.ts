import { NoParamEndpointConstructor, SingleParamEndpointConstructor } from 'interfaces/api.interfaces'

const baseUrl = 'payments'

interface Endpoints {
  createPayVerification: NoParamEndpointConstructor
  checkPayVerification: NoParamEndpointConstructor
  getOrderCard: NoParamEndpointConstructor
  getPaymentsSubscribe: NoParamEndpointConstructor
  buySubscription: SingleParamEndpointConstructor
  buyLection: SingleParamEndpointConstructor
  getByLections: NoParamEndpointConstructor
  deleteCard: NoParamEndpointConstructor
  getByLectionsAll: NoParamEndpointConstructor
}

export const orderEndpoints: Endpoints = {
  createPayVerification: () => `${baseUrl}/pay-verification`,
  checkPayVerification: () => `${baseUrl}/pay-verification-callback`,
  getOrderCard: () => `${baseUrl}/card`,
  deleteCard: () => `${baseUrl}/card`,
  getPaymentsSubscribe: () => `${baseUrl}/subscriptions`,
  buySubscription: (id: string | number) => `${baseUrl}/buy/subscription/${id}`,
  buyLection: (id: string | number) => `${baseUrl}/buy/lection/${id}`,
  getByLections: () => `${baseUrl}/lections`,
  getByLectionsAll: () => 'my-lections',
}
