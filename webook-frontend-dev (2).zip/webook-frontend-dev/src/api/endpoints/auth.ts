import { NoParamEndpointConstructor } from 'interfaces/api.interfaces'

const baseUrl = 'auth'

interface Endpoints {
  sendPhone: NoParamEndpointConstructor
  login: NoParamEndpointConstructor
  register: NoParamEndpointConstructor
}

export const authEndpoints: Endpoints = {
  sendPhone: () => `${baseUrl}/verify/code`,
  login: () => `${baseUrl}/login`,
  register: () => `${baseUrl}/register`,
}
