import { NoParamEndpointConstructor, SingleParamEndpointConstructor } from 'interfaces/api.interfaces'

const baseUrl = 'main'
const blocksUrl = 'blocks'

interface Endpoints {
  getHomeBlocks: NoParamEndpointConstructor
  getHomeBlock: SingleParamEndpointConstructor
}

export const homeEndpoints: Endpoints = {
  getHomeBlocks: () => `${baseUrl}/${blocksUrl}`,
  getHomeBlock: (slug) => `${baseUrl}/${blocksUrl}/${slug}`,
}
