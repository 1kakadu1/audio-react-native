import { authEndpoints as auth } from 'api/endpoints/auth'
import { bannerEndpoints as banner } from 'api/endpoints/banner'
import { catalogEndpoints as catalog } from 'api/endpoints/catalog'
import { homeEndpoints as home } from 'api/endpoints/home'
import { orderEndpoints as order } from 'api/endpoints/order'
import { staticPageEndpoints as staticPage } from 'api/endpoints/staticPage'
import { userEndpoints as user } from 'api/endpoints/user'

export const endpoints = {
  auth,
  user,
  catalog,
  staticPage,
  home,
  banner,
  order,
}
