import { authApi as auth } from './methods/auth'
import { bannerApi as banner } from './methods/banner'
import { catalogApi as catalog } from './methods/catalog'
import { homeApi as home } from './methods/home'
import { orderApi as order } from './methods/order'
import { staticPageApi as staticPage } from './methods/staticPage'
import { userApi as user } from './methods/user'

export const api = {
  auth,
  user,
  catalog,
  staticPage,
  home,
  banner,
  order,
}
