import { endpoints } from 'api/endpoints'
import { GetArrayData, GetArrayResponse, GetOneResponse } from 'interfaces/api.interfaces'
import { Lecture } from 'interfaces/api/catalog.interfaces'
import {
  OrderPayVerificationCallbackData,
  OrderPayVerificationData,
  OrderSubscribeData,
  OrderSuccesData,
} from 'interfaces/api/order.interface'
import { axios } from 'utils/axios'

const createPayVerification = async (data: { callback_url: string }): GetOneResponse<OrderPayVerificationData> => {
  const response = await axios.request<OrderPayVerificationData>({
    method: 'POST',
    url: endpoints.order.createPayVerification(),
    data,
  })
  return response.data
}

const checkPayVerification = async (data: OrderPayVerificationCallbackData): GetOneResponse<OrderSuccesData> => {
  const response = await axios.request<OrderSuccesData>({
    method: 'POST',
    url: endpoints.order.checkPayVerification(),
    data,
  })
  return response.data
}

const getOrderCard = async (): GetOneResponse<OrderSuccesData> => {
  const response = await axios.request<OrderSuccesData>({
    method: 'GET',
    url: endpoints.order.getOrderCard(),
  })
  return response.data
}

const delateOrderCard = async (): GetOneResponse<{ success: boolean }> => {
  const response = await axios.request<{ success: boolean }>({
    method: 'DELETE',
    url: endpoints.order.deleteCard(),
  })
  return response.data
}

const getPaymentsSubscribe = async (): GetArrayResponse<OrderSubscribeData> => {
  const response = await axios.request<GetArrayData<OrderSubscribeData>>({
    method: 'GET',
    url: endpoints.order.getPaymentsSubscribe(),
  })
  return response.data.data
}

const buySubscribe = async (
  id: string | number,
  callback_url: string,
): GetOneResponse<{ [key: string]: unknown; success: boolean }> => {
  const response = await axios.request<any>({
    method: 'POST',
    url: endpoints.order.buySubscription(id),
    data: {
      callback_url,
    },
  })
  return response.data
}

const buyLection = async (id: string | number, callback_url: string): GetOneResponse<any> => {
  const response = await axios.request<any>({
    method: 'POST',
    url: endpoints.order.buyLection(id),
    data: {
      callback_url,
    },
  })
  return response.data
}

const getByLections = async (): GetArrayResponse<Lecture> => {
  const response = await axios.request<GetArrayData<Lecture>>({
    method: 'GET',
    url: endpoints.order.getByLections(),
  })
  return response.data.data
}
const getByLectionsAll = async (): GetArrayResponse<Lecture> => {
  const response = await axios.request<GetArrayData<Lecture>>({
    method: 'GET',
    url: endpoints.order.getByLectionsAll(),
  })
  return response.data.data
}

export const orderApi = {
  createPayVerification,
  checkPayVerification,
  getOrderCard,
  getPaymentsSubscribe,
  buySubscribe,
  buyLection,
  getByLections,
  delateOrderCard,
  getByLectionsAll,
}
