import { endpoints } from 'api/endpoints'
import { GetArrayData, GetArrayResponse, GetOneResponse } from 'interfaces/api.interfaces'
import { HomeBlock, HomeBlockBase } from 'interfaces/api/home.interfaces'
import { axios } from 'utils/axios'

const getHomeBlocks = async (): GetArrayResponse<HomeBlockBase> => {
  const { data } = await axios.request<GetArrayData<HomeBlockBase>>({
    method: 'GET',
    url: endpoints.home.getHomeBlocks(),
  })
  return data.data
}

const getHomeBlock = async (slug: string): GetOneResponse<HomeBlock> => {
  const response = await axios.request<HomeBlock>({
    method: 'GET',
    url: endpoints.home.getHomeBlock(slug),
  })
  return response.data
}

export const homeApi = {
  getHomeBlocks,
  getHomeBlock,
}
