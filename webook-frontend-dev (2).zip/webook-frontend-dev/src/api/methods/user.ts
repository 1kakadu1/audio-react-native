import { endpoints } from 'api/endpoints'
import { GetArrayData, GetArrayResponse, GetObjectData, GetOneResponse } from 'interfaces/api.interfaces'
import { User, UserEditData, UserEditResponse, UserListeningTime } from 'interfaces/api/user.interfaces'
import { axios } from 'utils/axios'

const getUser = async (): GetOneResponse<User> => {
  const response = await axios.request<User>({
    method: 'GET',
    url: endpoints.user.getUser(),
  })
  return response.data
}

const putUser = async (data: UserEditData): GetOneResponse<UserEditResponse> => {
  const _data: Omit<UserEditData, 'phone'> & { phone?: string } = { ...data }
  delete _data.phone
  const response = await axios.request<GetObjectData<UserEditResponse>>({
    method: 'PUT',
    url: endpoints.user.putUser(),
    data: _data,
  })
  return response.data.data
}

const getCertificate = async (year: string | number): GetOneResponse<any> => {
  const response = await axios.request<User>({
    method: 'POST',
    url: endpoints.user.getCertificate(),
    responseType: 'blob',
    data: {
      year: year.toString(),
    },
  })
  console.log(response)
  return response.data
}

const getListeningTime = async (): GetArrayResponse<UserListeningTime> => {
  const response = await axios.request<GetArrayData<UserListeningTime>>({
    method: 'GET',
    url: endpoints.user.getListeningTime(),
  })
  return response.data.data
}

export const userApi = {
  getUser,
  putUser,
  getListeningTime,
  getCertificate,
}
