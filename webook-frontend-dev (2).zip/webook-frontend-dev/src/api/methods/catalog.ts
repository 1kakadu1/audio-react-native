import { endpoints } from 'api/endpoints'
import { GetArrayData, GetArrayResponse, GetOneResponse } from 'interfaces/api.interfaces'
import { Category, CategoryBase, Lecture } from 'interfaces/api/catalog.interfaces'
import { axios } from 'utils/axios'

const getCategories = async (isShowOnMain?: boolean): GetArrayResponse<CategoryBase> => {
  const { data } = await axios.request<GetArrayData<CategoryBase>>({
    method: 'GET',
    url: endpoints.catalog.getCategories(),
    params: isShowOnMain ? { filter: { is_shown_on_main: true } } : undefined,
  })
  return data.data
}

const getCategory = async (categoryId: number): GetOneResponse<Category> => {
  const { data } = await axios.request<Category>({
    method: 'GET',
    url: endpoints.catalog.getCategory(categoryId),
  })
  return data
}

const getLecture = async (lectureId: number): GetOneResponse<Lecture> => {
  const { data } = await axios.request<Lecture>({
    method: 'GET',
    url: endpoints.catalog.getLecture(lectureId),
  })
  return data
}

export const catalogApi = {
  getCategories,
  getCategory,
  getLecture,
}
