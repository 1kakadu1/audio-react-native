import { endpoints } from 'api/endpoints'
import { GetArrayData, GetArrayResponse } from 'interfaces/api.interfaces'
import { IBannerItem } from 'interfaces/api/banner.interfaces'
import { axios } from 'utils/axios'

const getBanners = async (): GetArrayResponse<IBannerItem> => {
  const { data } = await axios.request<GetArrayData<IBannerItem>>({
    method: 'GET',
    url: endpoints.banner.getBanners(),
  })
  return data.data
}

export const bannerApi = {
  getBanners,
}
