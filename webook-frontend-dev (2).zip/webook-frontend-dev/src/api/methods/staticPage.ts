import { endpoints } from 'api/endpoints'
import { GetArrayData, GetArrayResponse, GetOneResponse } from 'interfaces/api.interfaces'
import { StaticPage } from 'interfaces/api/staticPage.interfaces'
import { axios } from 'utils/axios'

const getStaticPage = async (slug: string): GetOneResponse<StaticPage> => {
  const response = await axios.request<StaticPage>({
    method: 'GET',
    url: endpoints.staticPage.getStaticPage(slug),
  })
  return response.data
}

const getStaticPages = async (): GetArrayResponse<StaticPage> => {
  const { data } = await axios.request<GetArrayData<StaticPage>>({
    method: 'GET',
    url: endpoints.staticPage.getStaticPages(),
  })
  return data.data
}

export const staticPageApi = {
  getStaticPage,
  getStaticPages,
}
