import { endpoints } from 'api/endpoints'
import { GetNoResponse, GetOneResponse } from 'interfaces/api.interfaces'
import { LoginData, PhoneData, RegisterData, TokenResponse } from 'interfaces/api/auth.interfaces'
import { axios } from 'utils/axios'

const sendPhone = async (data: PhoneData): GetNoResponse =>
  axios.request({
    method: 'POST',
    url: endpoints.auth.sendPhone(),
    data,
  })

const login = async (data: LoginData): GetOneResponse<TokenResponse> => {
  const response = await axios.request<TokenResponse>({
    method: 'POST',
    url: endpoints.auth.login(),
    data,
  })
  return response.data
}

const register = async (data: RegisterData): GetOneResponse<TokenResponse> => {
  const response = await axios.request<TokenResponse>({
    method: 'POST',
    url: endpoints.auth.register(),
    data,
  })
  return response.data
}

export const authApi = {
  sendPhone,
  login,
  register,
}
