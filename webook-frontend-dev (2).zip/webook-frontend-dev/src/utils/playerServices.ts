import TrackPlayer, { Capability, Event, RepeatMode, Track } from 'react-native-track-player'

import { store } from 'store'
import { setAudioProgress } from 'store/audio/actions'

export const capabilities = [Capability.Play, Capability.Pause, Capability.SkipToPrevious, Capability.SkipToNext]

export async function setupPlayer() {
  let isSetup = false
  try {
    await TrackPlayer.getActiveTrack()
    isSetup = true
  } catch (error) {
    await TrackPlayer.setupPlayer()
    isSetup = true
  } finally {
    return isSetup
  }
}

export async function setPosition() {
  const currentTrack = await TrackPlayer.getActiveTrack()
  const { position } = await TrackPlayer.getProgress()
  if (currentTrack?.id !== undefined && currentTrack?.id !== null && position > 0) {
    store.dispatch(setAudioProgress({ id: currentTrack.id, progress: position }))
  }
}

export async function addTrack(tracks: Track[], insetToStart?: boolean) {
  await TrackPlayer.add(tracks, insetToStart ? 0 : undefined)
  await TrackPlayer.setRepeatMode(RepeatMode.Off)
}

export async function playbackService() {
  let currentIndex: number | undefined = 0
  TrackPlayer.addEventListener(Event.RemotePause, async () => {
    await setPosition()
    TrackPlayer.pause()
  })
  TrackPlayer.addEventListener(Event.RemotePlay, () => {
    TrackPlayer.play()
  })
  TrackPlayer.addEventListener(Event.RemoteNext, async () => {
    await setPosition()
    const currentTrack = await TrackPlayer.getActiveTrack()
    const queue = await TrackPlayer.getQueue()
    const id = queue[queue.findIndex((item) => item.id === currentTrack?.id) + 1].id
    await TrackPlayer.skipToNext(store.getState().audio.audioProgress[id] ?? 0)
  })
  TrackPlayer.addEventListener(Event.RemotePrevious, async () => {
    await setPosition()
    const currentTrack = await TrackPlayer.getActiveTrack()
    const queue = await TrackPlayer.getQueue()
    const id = queue[queue.findIndex((item) => item.id === currentTrack?.id) - 1].id
    await TrackPlayer.skipToPrevious(store.getState().audio.audioProgress[id] ?? 0)
  })
  TrackPlayer.addEventListener(Event.PlaybackActiveTrackChanged, async (event) => {
    if (
      event.lastTrack?.duration &&
      Math.ceil(event.lastPosition) + 1 >= event.lastTrack?.duration &&
      event.index !== undefined &&
      currentIndex !== undefined &&
      (event.index > currentIndex || currentIndex === 0)
    ) {
      store.dispatch(setAudioProgress({ id: event.lastTrack?.id, progress: 0 }))
      const audioProgress = store.getState().audio.audioProgress
      if (audioProgress[event?.track?.id]) {
        await TrackPlayer.seekTo(audioProgress[event?.track?.id])
      }
    }
    currentIndex = event.index
  })
}
