import { parseToCamelCase, parseToSnakeCase } from 'helpers'
import { stringify } from 'qs'

export const paramsSerializerToSnakeCaseArrayBrackets = (params: any) =>
  stringify(parseToSnakeCase(params), { arrayFormat: 'brackets', encodeValuesOnly: true })

export const transformResponseToCamelCase = (data: any) => {
  try {
    return parseToCamelCase(JSON.parse(data))
  } catch (e) {
    return data
  }
}

export const transformRequestDefault = (data: any) => JSON.stringify(data)

export const transformRequestToSnakeCase = (data: any) =>
  data instanceof FormData ? data : data ? JSON.stringify(parseToSnakeCase(data)) : undefined

export const headersJson = {
  'Content-Type': 'application/json',
  Accept: 'application/json',
}
