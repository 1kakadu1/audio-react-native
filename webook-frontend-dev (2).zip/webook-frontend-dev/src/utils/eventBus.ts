type EventCallback<T = any> = (data: T) => void

type EventListeners = {
  [event: string]: EventCallback[]
}

class EventBus {
  private listeners: EventListeners

  constructor() {
    this.listeners = {}
  }

  on<T>(event: string, callback: EventCallback<T>): void {
    if (!this.listeners[event]) {
      this.listeners[event] = []
    }
    this.listeners[event].push(callback as EventCallback)
  }

  emit<T>(event: string, data?: T): void {
    if (this.listeners[event]) {
      this.listeners[event].forEach((callback: EventCallback<T | undefined>) => callback(data))
    }
  }

  off(event: string, callback: EventCallback): void {
    if (!this.listeners[event]) {
      return
    }
    this.listeners[event] = this.listeners[event].filter((cb) => cb !== callback)
  }
}

export const eventBus = new EventBus()
