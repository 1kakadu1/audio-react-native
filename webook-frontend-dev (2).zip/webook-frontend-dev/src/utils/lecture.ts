import { Lecture } from 'interfaces/api/catalog.interfaces'

export const isPurchasedFree = (lecture: Lecture) => {
  if (
    lecture.price === '0.00' ||
    lecture.price === '' ||
    lecture.price === null ||
    lecture.onlyInSubscription === false
  ) {
    return true
  }
  return false
}

export const isPurchased = (lecture: Lecture, payments: Lecture[] = []) => {
  if (isPurchasedFree(lecture)) {
    return true
  }
  return !!payments.find((item) => item.id === lecture.id)
}

export const splitString = (name?: string) => {
  if (name) {
    return name
      .split(' ')
      .map((item, index) => {
        if (index === 2) {
          return '\n' + item
        }
        return item
      })
      .join(' ')
  }
  return ''
}
