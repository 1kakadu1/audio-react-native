import { Animated } from 'react-native'

export const defaultAnimationTimingConfig: Animated.TimingAnimationConfig = {
  toValue: 0,
  duration: 200,
  useNativeDriver: true,
}
