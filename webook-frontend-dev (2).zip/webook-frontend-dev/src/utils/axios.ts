import Axios from 'axios'
import { ApiErrors } from 'constants/actionMessages'

import {
  headersJson,
  paramsSerializerToSnakeCaseArrayBrackets,
  transformRequestToSnakeCase,
  transformResponseToCamelCase,
} from './api'
import { eventBus } from './eventBus'

const axios = Axios.create({
  baseURL: 'https://api-dev.we-book.ru/api/',
  paramsSerializer: paramsSerializerToSnakeCaseArrayBrackets,
  transformResponse: transformResponseToCamelCase,
  transformRequest: transformRequestToSnakeCase,
  headers: headersJson,
})

const setAxiosAuthHeader = (token: null | string): void => {
  if (token) {
    axios.defaults.headers.Authorization = `Bearer ${token}`
  }
}

export const removeToken = (): void => {
  axios.defaults.headers.common.Authorization = null
}

axios.interceptors.response.use(
  (response) => response,
  (error) => {
    console.log('ERROR AXIOS', error)
    if (error.response.status === 401) {
      eventBus.emit('authError')
    }
    if (error.response.status === 404) {
      throw new Error(ApiErrors.NotFound)
    }
    if (error.response.status === 500) {
      throw new Error(ApiErrors.UnknownError)
    }
    if (error.response.status === 422 && 'errors' in error.response.data) {
      error.response.data.validation = error.response.data.errors
    }
    return Promise.reject(error)
  },
)

export { axios, setAxiosAuthHeader }
