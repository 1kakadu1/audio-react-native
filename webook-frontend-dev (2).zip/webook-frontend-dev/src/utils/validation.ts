import { ValidationErrors } from 'constants/actionMessages'
import { RegisterForm } from 'interfaces/api/auth.interfaces'
import { UserEditData } from 'interfaces/api/user.interfaces'
import { object, ObjectSchema, string } from 'yup'

export const registerSchema: ObjectSchema<RegisterForm> = object({
  name: string().required(ValidationErrors.Required),
  email: string().required(ValidationErrors.Required).email(ValidationErrors.IncorrectEmailFormat),
  registerNumber: string(),
})

export const userEditSchema: ObjectSchema<UserEditData> = object({
  name: string().required(ValidationErrors.Required),
  email: string().email(ValidationErrors.IncorrectEmailFormat).required(ValidationErrors.Required),
  registerNumber: string(),
  phone: string().required(ValidationErrors.Required),
})
