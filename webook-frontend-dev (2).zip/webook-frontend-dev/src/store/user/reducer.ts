import { createReducer } from '@reduxjs/toolkit'
import { OrderToken } from 'interfaces/api/order.interface'
import { User, UserListeningTime } from 'interfaces/api/user.interfaces'

import { deleteCardUser, getCardUser, getListeningTimeUser, getUser, setUserCard, updateUser } from './actions'

export interface UserState {
  user: User | null
  loading: boolean
  error?: string | null
  card: {
    loading: boolean
    data?: OrderToken
    error?: null | string
  }
  listeningTime: {
    loading: boolean
    error?: string | null
    items: UserListeningTime[]
  }
}

const initialState: UserState = {
  user: null,
  loading: false,
  error: null,
  card: {
    loading: false,
    data: undefined,
    error: null,
  },
  listeningTime: {
    loading: false,
    error: undefined,
    items: [],
  },
}

export const userReducer = createReducer(initialState, (builder) => {
  builder
    .addCase(getUser.pending, (state) => {
      state.error = null
      state.loading = true
    })
    .addCase(getUser.fulfilled, (state, { payload }) => {
      state.loading = false
      state.user = payload
    })
    .addCase(getUser.rejected, (state, { payload }) => {
      state.loading = false
      state.error = payload
    })
    .addCase(setUserCard, (state, { payload }) => {
      state.card.data = payload
    })
    .addCase(getCardUser.pending, (state) => {
      state.card.error = null
      state.card.loading = true
    })
    .addCase(getCardUser.fulfilled, (state, { payload }) => {
      state.card.loading = false
      state.card.data = payload.token ? payload.token : undefined
    })
    .addCase(getCardUser.rejected, (state, { payload }) => {
      state.card.loading = false
      state.card.error = payload
    })

    .addCase(deleteCardUser.pending, (state) => {
      state.card.error = null
      state.card.loading = true
    })
    .addCase(deleteCardUser.fulfilled, (state, { payload }) => {
      state.card.loading = false
      if (payload.success === true) {
        state.card.data = undefined
      }
    })
    .addCase(deleteCardUser.rejected, (state, { payload }) => {
      state.card.loading = false
      state.card.error = payload
    })

    .addCase(updateUser.pending, (state) => {
      state.error = null
      state.loading = true
    })
    .addCase(updateUser.fulfilled, (state, { payload }) => {
      state.loading = false

      if (state.user) {
        state.user.email = payload.email
        state.user.name = payload.name
        state.user.registerNumber = payload.registerNumber || null
      }
    })
    .addCase(updateUser.rejected, (state) => {
      state.loading = false
    })

    .addCase(getListeningTimeUser.pending, (state) => {
      state.listeningTime.error = null
      state.listeningTime.loading = true
    })
    .addCase(getListeningTimeUser.fulfilled, (state, { payload }) => {
      state.listeningTime.loading = false
      state.listeningTime.items = payload
    })
    .addCase(getListeningTimeUser.rejected, (state, { payload }) => {
      state.listeningTime.loading = false
      state.listeningTime.error = payload
    })
})
