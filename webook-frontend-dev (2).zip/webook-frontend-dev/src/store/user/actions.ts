import Snackbar from 'react-native-snackbar'

import { createAction } from '@reduxjs/toolkit'
import { api } from 'api'
import { colors } from 'constants/colors'
import { OrderToken } from 'interfaces/api/order.interface'
import { UserEditData } from 'interfaces/api/user.interfaces'
import { createAppAsyncThunk } from 'utils/redux'

export const setUserCard = createAction<OrderToken | undefined>('user/setUserCard')

export const getUser = createAppAsyncThunk('user/getUser', async (_, { rejectWithValue }) =>
  api.user.getUser().catch((error) => rejectWithValue(error.message)),
)

export const updateUser = createAppAsyncThunk('user/updateUser', async (data: UserEditData, { rejectWithValue }) =>
  api.user
    .putUser(data)
    .then((response) => {
      Snackbar.show({ text: 'Данные успешно изменены', backgroundColor: colors.green })
      return response
    })
    .catch((error) => rejectWithValue(error.message)),
)

export const getCardUser = createAppAsyncThunk('user/getCardUser', async (_, { rejectWithValue }) =>
  api.order.getOrderCard().catch((error) => rejectWithValue(error.message)),
)

export const deleteCardUser = createAppAsyncThunk('user/deleteCardUser', async (_, { rejectWithValue }) =>
  api.order.delateOrderCard().catch((error) => rejectWithValue(error.message)),
)

export const getListeningTimeUser = createAppAsyncThunk('user/getListeningTimeUser', async (_, { rejectWithValue }) =>
  api.user.getListeningTime().catch((error) => rejectWithValue(error.message)),
)
