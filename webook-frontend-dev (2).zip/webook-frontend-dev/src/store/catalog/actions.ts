import { api } from 'api'
import { createAppAsyncThunk } from 'utils/redux'

export const getCategories = createAppAsyncThunk('catalog/getCategories', async (_, { rejectWithValue }) =>
  api.catalog.getCategories().catch((error) => rejectWithValue(error.message)),
)

export const getHomeCategories = createAppAsyncThunk('catalog/getHomeCategories', async (_, { rejectWithValue }) =>
  api.catalog.getCategories(true).catch((error) => rejectWithValue(error.message)),
)

export const getCategory = createAppAsyncThunk('catalog/getCategory', async (categoryId: number, { rejectWithValue }) =>
  api.catalog.getCategory(categoryId).catch((error) => rejectWithValue(error.message)),
)

export const getHomeCategory = createAppAsyncThunk(
  'catalog/getHomeCategory',
  async (categoryId: number, { rejectWithValue }) =>
    api.catalog.getCategory(categoryId).catch((error) => rejectWithValue(error.message)),
)

export const getLecture = createAppAsyncThunk('catalog/getLecture', async (lectureId: number, { rejectWithValue }) =>
  api.catalog.getLecture(lectureId).catch((error) => rejectWithValue(error.message)),
)
