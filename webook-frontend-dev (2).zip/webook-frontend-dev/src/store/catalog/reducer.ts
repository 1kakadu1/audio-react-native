import { createReducer } from '@reduxjs/toolkit'
import { Category, CategoryBase, Lecture } from 'interfaces/api/catalog.interfaces'

import { getCategories, getCategory, getHomeCategories, getHomeCategory, getLecture } from './actions'

export interface CatalogState {
  categories: {
    list: CategoryBase[]
    loading: boolean
  }
  homeCategories: {
    list: CategoryBase[]
    loading: boolean
  }
  category: {
    item: Record<string, Category>
    loading: boolean
  }
  homeCategory: {
    item: Record<string, Category>
    loading: boolean
  }
  lecture: {
    item: Record<string, Lecture>
    loading: boolean
  }
}

const initialState: CatalogState = {
  categories: {
    list: [],
    loading: false,
  },
  homeCategories: {
    list: [],
    loading: false,
  },
  category: {
    item: {},
    loading: false,
  },
  homeCategory: {
    item: {},
    loading: false,
  },
  lecture: {
    item: {},
    loading: false,
  },
}

export const catalogReducer = createReducer(initialState, (builder) => {
  builder
    .addCase(getCategories.pending, (state) => {
      state.categories.loading = true
    })
    .addCase(getCategories.fulfilled, (state, { payload }) => {
      state.categories.loading = false
      state.categories.list = payload
    })
    .addCase(getCategories.rejected, (state) => {
      state.categories.loading = false
    })

    .addCase(getHomeCategories.pending, (state) => {
      state.homeCategories.loading = true
    })
    .addCase(getHomeCategories.fulfilled, (state, { payload }) => {
      state.homeCategories.loading = false
      state.homeCategories.list = payload
    })
    .addCase(getHomeCategories.rejected, (state) => {
      state.homeCategories.loading = false
    })

    .addCase(getCategory.pending, (state) => {
      state.category.loading = true
    })
    .addCase(getCategory.fulfilled, (state, { meta, payload }) => {
      state.category.loading = false
      state.category.item[meta.arg] = payload
    })
    .addCase(getCategory.rejected, (state) => {
      state.category.loading = false
    })

    .addCase(getHomeCategory.pending, (state) => {
      state.homeCategory.loading = true
    })
    .addCase(getHomeCategory.fulfilled, (state, { meta, payload }) => {
      state.homeCategory.loading = false
      state.homeCategory.item[meta.arg] = payload
    })
    .addCase(getHomeCategory.rejected, (state) => {
      state.homeCategory.loading = false
    })

    .addCase(getLecture.pending, (state) => {
      state.lecture.loading = true
    })
    .addCase(getLecture.fulfilled, (state, { meta, payload }) => {
      state.lecture.loading = false
      state.lecture.item[meta.arg] = payload
    })
    .addCase(getLecture.rejected, (state) => {
      state.lecture.loading = false
    })
})
