import { createReducer } from '@reduxjs/toolkit'
import { IBannerItem } from 'interfaces/api/banner.interfaces'
import { HomeBlock, HomeBlockBase } from 'interfaces/api/home.interfaces'

import { getBannerBlock, getHomeBlock, getHomeBlocks } from './actions'

export interface HomeState {
  blocks: {
    list: HomeBlockBase[]
    loading: boolean
  }
  block: {
    item: Record<string, HomeBlock>
    loading: boolean
  }
  banners: {
    items: IBannerItem[]
    loading: boolean
  }
}

const initialState: HomeState = {
  blocks: {
    list: [],
    loading: false,
  },
  block: {
    item: {},
    loading: false,
  },
  banners: {
    items: [],
    loading: false,
  },
}

export const homeReducer = createReducer(initialState, (builder) => {
  builder
    .addCase(getHomeBlocks.pending, (state) => {
      state.blocks.loading = true
    })
    .addCase(getHomeBlocks.fulfilled, (state, { payload }) => {
      state.blocks.loading = false
      state.blocks.list = payload
    })
    .addCase(getHomeBlocks.rejected, (state) => {
      state.blocks.loading = false
    })

    .addCase(getHomeBlock.pending, (state) => {
      state.block.loading = true
    })
    .addCase(getHomeBlock.fulfilled, (state, { meta, payload }) => {
      state.block.loading = false
      state.block.item[meta.arg] = payload
    })
    .addCase(getHomeBlock.rejected, (state) => {
      state.block.loading = false
    })

    .addCase(getBannerBlock.pending, (state) => {
      state.banners.loading = true
    })
    .addCase(getBannerBlock.fulfilled, (state, { payload }) => {
      state.banners.loading = false
      state.banners.items = payload
    })
    .addCase(getBannerBlock.rejected, (state) => {
      state.banners.loading = false
    })
})
