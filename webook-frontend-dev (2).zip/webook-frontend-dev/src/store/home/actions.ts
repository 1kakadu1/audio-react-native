import { api } from 'api'
import { createAppAsyncThunk } from 'utils/redux'

export const getHomeBlocks = createAppAsyncThunk('home/getHomeBlocks', async (_, { rejectWithValue }) =>
  api.home.getHomeBlocks().catch((error) => rejectWithValue(error.message)),
)

export const getHomeBlock = createAppAsyncThunk('home/getHomeBlock', async (slug: string, { rejectWithValue }) =>
  api.home.getHomeBlock(slug).catch((error) => rejectWithValue(error.message)),
)

export const getBannerBlock = createAppAsyncThunk('home/getBannerBlock', async (_, { rejectWithValue }) =>
  api.banner.getBanners().catch((error) => rejectWithValue(error.message)),
)
