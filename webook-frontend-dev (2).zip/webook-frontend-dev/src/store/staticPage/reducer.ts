import { createReducer } from '@reduxjs/toolkit'
import { StaticPage, StaticPageBase } from 'interfaces/api/staticPage.interfaces'

import { getStaticPage, getStaticPages } from './actions'

export interface StaticPageState {
  staticPage: {
    item: Record<string, StaticPage>
    loading: boolean
  }
  staticPages: {
    list: StaticPageBase[]
    loading: boolean
  }
}

const initialState: StaticPageState = {
  staticPage: {
    item: {},
    loading: false,
  },
  staticPages: {
    list: [],
    loading: false,
  },
}

export const staticPageReducer = createReducer(initialState, (builder) => {
  builder
    .addCase(getStaticPage.pending, (state) => {
      state.staticPage.loading = true
    })
    .addCase(getStaticPage.fulfilled, (state, { meta, payload }) => {
      state.staticPage.loading = false
      state.staticPage.item[meta.arg] = payload
    })
    .addCase(getStaticPage.rejected, (state) => {
      state.staticPage.loading = false
    })

    .addCase(getStaticPages.pending, (state) => {
      state.staticPages.loading = true
    })
    .addCase(getStaticPages.fulfilled, (state, { payload }) => {
      state.staticPages.loading = false
      state.staticPages.list = payload
    })
    .addCase(getStaticPages.rejected, (state) => {
      state.staticPages.loading = false
    })
})
