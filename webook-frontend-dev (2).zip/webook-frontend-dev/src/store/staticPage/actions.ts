import { api } from 'api'
import { createAppAsyncThunk } from 'utils/redux'

export const getStaticPage = createAppAsyncThunk(
  'staticPage/getStaticPage',
  async (slug: string, { rejectWithValue }) =>
    api.staticPage.getStaticPage(slug).catch((error) => rejectWithValue(error.message)),
)

export const getStaticPages = createAppAsyncThunk('staticPage/getStaticPages', async (_, { rejectWithValue }) =>
  api.staticPage.getStaticPages().catch((error) => rejectWithValue(error.message)),
)
