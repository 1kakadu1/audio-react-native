import AsyncStorage from '@react-native-async-storage/async-storage'
import { PersistConfig, persistReducer } from 'redux-persist'

import { rootReducer, RootState } from './rootReducer'

const persistConfig: PersistConfig<RootState> = {
  key: 'root',
  storage: AsyncStorage,
  blacklist: ['auth', 'downloadAudio'],
}

export const persistedReducer = persistReducer(persistConfig, rootReducer)
