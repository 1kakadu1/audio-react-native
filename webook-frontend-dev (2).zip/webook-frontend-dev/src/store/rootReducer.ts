import AsyncStorage from '@react-native-async-storage/async-storage'
import { combineReducers } from 'redux'
import { PersistConfig, persistReducer } from 'redux-persist'

import { audioReducer as audio } from './audio/reducer'
import { authReducer as auth, AuthState } from './auth/reducer'
import { catalogReducer as catalog } from './catalog/reducer'
import { homeReducer as home } from './home/reducer'
import { paymentReducer as payments } from './payment/reduser'
import { staticPageReducer as staticPage } from './staticPage/reducer'
import { userReducer as user } from './user/reducer'

const authPersistConfig: PersistConfig<AuthState> = {
  key: 'auth',
  storage: AsyncStorage,
  whitelist: ['isLoggedIn', 'token'],
}

export const rootReducer = combineReducers({
  auth: persistReducer(authPersistConfig, auth),
  user,
  catalog,
  audio,
  staticPage,
  home,
  payments,
})

export type RootState = ReturnType<typeof rootReducer>
