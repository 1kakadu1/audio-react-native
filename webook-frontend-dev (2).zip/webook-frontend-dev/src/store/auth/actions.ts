import Snackbar from 'react-native-snackbar'

import { createAction } from '@reduxjs/toolkit'
import { api } from 'api'
import { OriginalErrorMessages } from 'constants/actionMessages'
import { colors } from 'constants/colors'
import { ValidationErrors } from 'interfaces/api.interfaces'
import { LoginParams, RegisterParams, SendPhoneParams } from 'interfaces/store/auth.interfaces'
import { createAppAsyncThunk } from 'utils/redux'

export const setIsLoggedIn = createAction<boolean>('auth/setIsLoggedIn')

export const setSendPhoneValidationErrors = createAction<ValidationErrors>('auth/setSendPhoneValidationErrors')

export const clearSendPhoneValidationError = createAction('auth/clearSendPhoneValidationError')

export const clearToken = createAction('auth/clearToken')

export const sendPhone = createAppAsyncThunk(
  'auth/sendPhone',
  async (params: SendPhoneParams, { dispatch, rejectWithValue }) =>
    api.auth
      .sendPhone(params.data)
      .then(() => params.onSuccess?.())
      .catch((error) => {
        if (error?.response?.data?.validation) {
          dispatch(setSendPhoneValidationErrors(error.response.data.validation))
        } else if (error?.response?.status === 422 && error?.response?.data?.message) {
          dispatch(setSendPhoneValidationErrors({ phone: error?.response?.data?.message }))
        } else {
          Snackbar.show({ text: error.message, backgroundColor: colors.red })
        }
        return rejectWithValue(error.message)
      }),
)

export const login = createAppAsyncThunk('auth/login', async (data: LoginParams, { rejectWithValue }) =>
  api.auth
    .login(data.data)
    .then((response) => {
      data.onSuccess?.()
      return response
    })
    .catch((error) => {
      if (!error?.response?.data?.message && error.message !== OriginalErrorMessages.NotVerifiedStatus) {
        Snackbar.show({ text: error.message, backgroundColor: colors.red })
      }
      return rejectWithValue(error?.response?.data?.message)
    }),
)

export const setRegisterValidationErrors = createAction<ValidationErrors>('auth/setRegisterValidationErrors')

export const clearRegisterValidationError = createAction<ValidationErrors>('auth/clearRegisterValidationError')

export const register = createAppAsyncThunk('auth/reg', async (data: RegisterParams, { dispatch, rejectWithValue }) =>
  api.auth
    .register(data.data)
    .then((response) => {
      data.onSuccess?.()
      return response
    })
    .catch((error) => {
      if (error?.response?.data?.validation) {
        dispatch(setRegisterValidationErrors(error.response.data.validation))
      } else {
        Snackbar.show({ text: error.message, backgroundColor: colors.red })
      }
      return rejectWithValue(error.message)
    }),
)
