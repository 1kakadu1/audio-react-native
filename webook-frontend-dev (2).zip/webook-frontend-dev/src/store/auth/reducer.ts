import { createReducer } from '@reduxjs/toolkit'
import { ValidationErrors } from 'interfaces/api.interfaces'

import {
  clearRegisterValidationError,
  clearSendPhoneValidationError,
  clearToken,
  login,
  register,
  sendPhone,
  setIsLoggedIn,
  setRegisterValidationErrors,
  setSendPhoneValidationErrors,
} from './actions'

export interface AuthState {
  isLoggedIn: boolean
  token: string | null
  error?: string | null
  loading: boolean
  validation: ValidationErrors
  sendPhone: {
    loading: boolean
    validation: ValidationErrors
  }
}

const initialState: AuthState = {
  isLoggedIn: false,
  token: null,
  error: null,
  loading: false,
  validation: null,
  sendPhone: {
    loading: false,
    validation: null,
  },
}

export const authReducer = createReducer(initialState, (builder) => {
  builder
    .addCase(setIsLoggedIn, (state, { payload }) => {
      state.isLoggedIn = payload
    })

    .addCase(clearToken, (state) => {
      state.token = null
    })

    .addCase(login.pending, (state) => {
      state.loading = true
      state.error = null
    })
    .addCase(login.fulfilled, (state, { payload }) => {
      state.token = payload.token
      state.loading = false
    })
    .addCase(login.rejected, (state, { payload }) => {
      state.error = payload
      state.loading = false
    })

    .addCase(sendPhone.pending, (state) => {
      state.sendPhone.loading = true
      state.error = null
    })
    .addCase(sendPhone.fulfilled, (state) => {
      state.sendPhone.loading = false
    })
    .addCase(sendPhone.rejected, (state) => {
      state.sendPhone.loading = false
    })
    .addCase(setSendPhoneValidationErrors, (state, { payload }) => {
      state.sendPhone.validation = payload
    })
    .addCase(clearSendPhoneValidationError, (state) => {
      state.sendPhone.validation = null
    })

    .addCase(register.pending, (state) => {
      state.loading = true
      state.validation = null
    })
    .addCase(register.fulfilled, (state, { payload }) => {
      state.token = payload.token
      state.loading = false
    })
    .addCase(register.rejected, (state) => {
      state.loading = false
    })
    .addCase(setRegisterValidationErrors, (state, { payload }) => {
      state.validation = payload
    })
    .addCase(clearRegisterValidationError, (state) => {
      state.validation = null
    })
})
