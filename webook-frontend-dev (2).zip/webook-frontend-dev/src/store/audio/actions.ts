import { Track } from 'react-native-track-player'

import { createAction } from '@reduxjs/toolkit'
import { Lecture } from 'interfaces/api/catalog.interfaces'
import { AudioProgressData } from 'interfaces/store/audio.interfaces'

export const addAudioDownloadedList = createAction<Lecture>('audio/addAudioDownloadedList')
export const removeFromDownloadedList = createAction<number>('audio/removeFromDownloadedList')

export const setPlaylist = createAction<Track[]>('audio/setPlaylist')
export const setCurrentTrack = createAction<number | null>('audio/setCurrentTrack')

export const setAudioProgress = createAction<AudioProgressData>('audio/setAudioProgress')
