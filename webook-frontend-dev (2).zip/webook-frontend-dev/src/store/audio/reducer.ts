import { Track } from 'react-native-track-player'

import { createReducer } from '@reduxjs/toolkit'
import { AudioLocal, AudioProgress } from 'interfaces/store/audio.interfaces'
import { PURGE } from 'redux-persist'

import {
  addAudioDownloadedList,
  removeFromDownloadedList,
  setAudioProgress,
  setCurrentTrack,
  setPlaylist,
} from './actions'

export interface AudioState {
  list: AudioLocal
  playlist: Track[]
  currentTrack: number | null
  audioProgress: AudioProgress
}

const initialState: AudioState = {
  list: {},
  playlist: [],
  currentTrack: null,
  audioProgress: {},
}

export const audioReducer = createReducer(initialState, (builder) => {
  builder
    .addCase(addAudioDownloadedList, (state, { payload }) => {
      state.list = { ...state.list, [payload.id]: payload }
    })
    .addCase(removeFromDownloadedList, (state, { payload }) => {
      delete state.list[payload]
    })
    .addCase(setPlaylist, (state, { payload }) => {
      state.playlist = payload
    })
    .addCase(setCurrentTrack, (state, { payload }) => {
      state.currentTrack = payload
    })
    .addCase(setAudioProgress, (state, { payload }) => {
      state.audioProgress = { ...state.audioProgress, [payload.id]: payload.progress }
    })

    .addCase(PURGE, () => initialState)
})
