import { createReducer } from '@reduxjs/toolkit'
import { Lecture } from 'interfaces/api/catalog.interfaces'
import { OrderSubscribeData } from 'interfaces/api/order.interface'

import { addLection, getByLections, getPayments } from './actions'

export interface HomeState {
  paymentsSubsribe: {
    payments: OrderSubscribeData[]
    loading: boolean
  }
  lections: {
    loading: boolean
    items: Lecture[]
  }
}

const initialState: HomeState = {
  paymentsSubsribe: {
    payments: [],
    loading: false,
  },
  lections: {
    loading: false,
    items: [],
  },
}

export const paymentReducer = createReducer(initialState, (builder) => {
  builder
    .addCase(getPayments.pending, (state) => {
      state.paymentsSubsribe.loading = true
    })
    .addCase(getPayments.fulfilled, (state, { payload }) => {
      state.paymentsSubsribe.loading = false
      state.paymentsSubsribe.payments = payload
    })
    .addCase(getPayments.rejected, (state) => {
      state.paymentsSubsribe.loading = false
    })

    .addCase(addLection, (state, { payload }) => {
      state.lections.items.push(payload)
    })
    .addCase(getByLections.pending, (state) => {
      state.lections.loading = true
    })
    .addCase(getByLections.fulfilled, (state, { payload }) => {
      state.lections.loading = false
      state.lections.items = payload
    })
    .addCase(getByLections.rejected, (state) => {
      state.lections.loading = false
    })
})
