import { createAction } from '@reduxjs/toolkit'
import { api } from 'api'
import { Lecture } from 'interfaces/api/catalog.interfaces'
import { createAppAsyncThunk } from 'utils/redux'

export const getPayments = createAppAsyncThunk('payments/getPayments', async (_, { rejectWithValue }) =>
  api.order.getPaymentsSubscribe().catch((error) => rejectWithValue(error.message)),
)

export const getByLections = createAppAsyncThunk('payments/getByLections', async (_, { rejectWithValue }) =>
  api.order.getByLectionsAll().catch((error) => rejectWithValue(error.message)),
)

export const addLection = createAction<Lecture>('payments/addLection')
