import { FC, useEffect } from 'react'
import { FlatList, StyleProp, View, ViewStyle } from 'react-native'

import { useNetInfo } from '@react-native-community/netinfo'
import { appStyles } from 'assets/styles/appStyles'
import { StaticItem } from 'components/features/Static/StaticItem'
import { Loader } from 'components/shared/Loader'
import { Text } from 'components/shared/Text'
import { DisconnectedBlock } from 'components/templates/DisconnectedBlock'
import { useIsReady } from 'hooks'
import { useAppDispatch, useAppSelector } from 'store'
import { getStaticPages } from 'store/staticPage/actions'

import styles from './StaticList.styles'

interface Props {
  style?: StyleProp<ViewStyle>
}

export const StaticList: FC<Props> = ({ style }) => {
  const { list, loading } = useAppSelector((state) => state.staticPage.staticPages)

  const dispatch = useAppDispatch()

  const { isConnected } = useNetInfo()
  const isReady = useIsReady()

  useEffect(() => {
    dispatch(getStaticPages())
  }, [])

  if (isConnected === false && !list.length) {
    return <DisconnectedBlock />
  }

  if ((loading && !list.length) || !isReady) {
    return <Loader />
  }

  return (
    <View style={[appStyles.mainMarginTop, appStyles.mainPaddingHorizontal, style]}>
      <Text style={[appStyles.text28, styles.title]}>Правовая информация</Text>
      <FlatList
        contentContainerStyle={styles.list}
        data={list}
        keyExtractor={(item) => String(item.id)}
        renderItem={({ item }) => <StaticItem item={item} />}
      />
    </View>
  )
}
