import { StyleSheet } from 'react-native'

export default StyleSheet.create({
  title: {
    marginBottom: 20,
    marginTop: 12,
  },
  list: {
    gap: 8,
  },
})
