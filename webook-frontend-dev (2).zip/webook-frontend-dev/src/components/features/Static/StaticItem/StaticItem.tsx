import { FC } from 'react'
import { TouchableOpacity } from 'react-native'

import { useNavigation } from '@react-navigation/native'
import { appStyles } from 'assets/styles/appStyles'
import { Text } from 'components/shared/Text'
import { StaticPageBase } from 'interfaces/api/staticPage.interfaces'
import { Navigation } from 'interfaces/common.interfaces'
import { Routes } from 'routes/routes'

import styles from './StaticItem.styles'

interface Props {
  item: StaticPageBase
}

export const StaticItem: FC<Props> = ({ item }) => {
  const navigation = useNavigation<Navigation>()

  const onItemPress = () => {
    navigation.navigate(Routes.Static, { slug: item.slug })
  }

  return (
    <TouchableOpacity activeOpacity={0.8} onPress={onItemPress}>
      <Text color="yellow" style={[appStyles.text16, styles.text]}>
        {item?.title}
      </Text>
    </TouchableOpacity>
  )
}
