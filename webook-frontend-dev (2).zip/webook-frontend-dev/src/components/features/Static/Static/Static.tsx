import React, { FC, useEffect } from 'react'
import { ScrollView, useWindowDimensions, View } from 'react-native'
import RenderHTML, { MixedStyleRecord } from 'react-native-render-html'

import { useNetInfo } from '@react-native-community/netinfo'
import { appStyles } from 'assets/styles/appStyles'
import { Loader } from 'components/shared/Loader'
import { Text } from 'components/shared/Text'
import { DisconnectedBlock } from 'components/templates/DisconnectedBlock'
import { colors } from 'constants/colors'
import { useIsReady } from 'hooks'
import { useAppDispatch, useAppSelector } from 'store'
import { getStaticPage } from 'store/staticPage/actions'

import styles from './Static.styles'

const tagsStyles: MixedStyleRecord = {
  body: { color: colors.gray, lineHeight: 22.4 },
  a: { color: colors.gray, lineHeight: 22.4 },
}

interface Props {
  slug: string
}

export const Static: FC<Props> = ({ slug }) => {
  const { item, loading } = useAppSelector((state) => state.staticPage.staticPage)

  const dispatch = useAppDispatch()

  const { width } = useWindowDimensions()
  const { isConnected } = useNetInfo()
  const isReady = useIsReady()

  useEffect(() => {
    if (slug) {
      dispatch(getStaticPage(slug))
    }
  }, [slug])

  if (isConnected === false && !item[slug]) {
    return <DisconnectedBlock />
  }

  if ((loading && !item[slug]) || !isReady) {
    return <Loader />
  }

  return (
    <>
      <Text style={[appStyles.text28, styles.title]}>{item[slug].title}</Text>
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={appStyles.mainPaddingBottom}>
          <RenderHTML contentWidth={width} source={{ html: item[slug].content }} tagsStyles={tagsStyles} />
        </View>
      </ScrollView>
    </>
  )
}
