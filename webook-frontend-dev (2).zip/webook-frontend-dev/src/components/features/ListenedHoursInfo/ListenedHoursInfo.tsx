import { FC } from 'react'
import { View } from 'react-native'

import CertificateIcon from 'assets/icons/certificate-filled.svg'
import { appStyles } from 'assets/styles/appStyles'
import { ProgressCircle } from 'components/shared/ProgressCircle'
import { Text } from 'components/shared/Text'
import { colors } from 'constants/colors'

import styles from './ListenedHoursInfo.styles'

interface Props {
  hours?: number
}

export const ListenedHoursInfo: FC<Props> = ({ hours = 0 }) => (
  <View style={styles.container}>
    {hours >= 30 ? (
      <CertificateIcon color={colors.yellow} />
    ) : (
      <ProgressCircle end={30} progress={hours} progressColor={colors.yellow} style={styles.progress} withProgress>
        <View style={styles.counter}>
          <Text color="yellow" style={[appStyles.text10, appStyles.textWeight500]}>
            {hours}
          </Text>
        </View>
      </ProgressCircle>
    )}
  </View>
)
