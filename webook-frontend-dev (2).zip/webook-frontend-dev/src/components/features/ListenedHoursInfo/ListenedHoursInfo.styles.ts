import { StyleSheet } from 'react-native'

export default StyleSheet.create({
  container: {
    alignItems: 'center',
    marginBottom: 6,
  },
  progress: {
    transform: [{ scale: 1.2 }],
  },
  counter: {
    marginTop: 1,
  },
})
