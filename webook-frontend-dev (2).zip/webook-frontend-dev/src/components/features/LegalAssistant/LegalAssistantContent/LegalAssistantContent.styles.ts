import { StyleSheet } from 'react-native'

import { colors } from 'constants/colors'

export default StyleSheet.create({
  text: {
    color: colors.gray,
  },
  btn: {},
  container: {
    gap: 18,
    paddingHorizontal: 16,
    paddingTop: 18,
  },
})
