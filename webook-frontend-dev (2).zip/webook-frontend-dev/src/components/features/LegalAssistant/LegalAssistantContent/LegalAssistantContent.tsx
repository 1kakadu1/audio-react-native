import { useCallback } from 'react'
import { Linking, Text, View } from 'react-native'
import Snackbar from 'react-native-snackbar'

import { appStyles } from 'assets/styles/appStyles'
import { Button } from 'components/shared/Button'
import { legalAssistantURL } from 'constants/app'
import { colors } from 'constants/colors'

import styles from './LegalAssistantContent.styles'

export const LegalAssistantContent = () => {
  const handlePress = useCallback(async () => {
    const supported = await Linking.canOpenURL(legalAssistantURL)

    if (supported) {
      await Linking.openURL(legalAssistantURL)
    } else {
      Snackbar.show({ text: 'Невозможно открыть URL', backgroundColor: colors.red })
    }
  }, [])

  return (
    <View style={styles.container}>
      <Text style={[appStyles.text14, appStyles.textWeight400, styles.text]}>
        Юридическая помощь в любой ситуации. Решаем любые юридические вопросы и отвечаем за работу своим именем!
        Получите бесплатную 10-ти минутную консультацию от специалиста с 9 летным практическим опытом.
      </Text>
      <Button onPress={handlePress} title="Получить консультацию" />
    </View>
  )
}
