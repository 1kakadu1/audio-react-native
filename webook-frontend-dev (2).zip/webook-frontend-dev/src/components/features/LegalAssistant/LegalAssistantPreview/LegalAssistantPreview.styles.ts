import { StyleSheet } from 'react-native'

export default StyleSheet.create({
  image: {
    height: 377,
    justifyContent: 'flex-end',
    width: '100%',
  },
  footer: {
    gap: 23,
    paddingBottom: 3,
    paddingHorizontal: 16,
  },
  row: {
    flexDirection: 'row',
    gap: 17,
  },
  item: {
    alignItems: 'flex-end',
    flexDirection: 'row',
    gap: 6,
  },
})
