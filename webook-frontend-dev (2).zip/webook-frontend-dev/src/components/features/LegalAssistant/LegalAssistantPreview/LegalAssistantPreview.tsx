import { ImageBackground, View } from 'react-native'

import PhoneIcon from 'assets/icons/phone-small.svg'
import { appStyles } from 'assets/styles/appStyles'
import { Text } from 'components/shared/Text'

import styles from './LegalAssistantPreview.styles'

export const LegalAssistancePreview = () => (
  <ImageBackground resizeMode="cover" source={require('assets/images/legal-bg.png')} style={styles.image}>
    <View style={styles.footer}>
      <Text style={appStyles.text35}>Юридическая{'\n'}помощь</Text>
      <View style={styles.row}>
        <View style={styles.item}>
          <Text style={[appStyles.text18, appStyles.textWeight500]}>+9</Text>
          <Text style={[appStyles.text14, appStyles.textWeight500]}>лет опыта</Text>
        </View>
        <View style={styles.item}>
          <PhoneIcon />
          <Text style={appStyles.textWeight500}>бесплатная консультация</Text>
        </View>
      </View>
    </View>
  </ImageBackground>
)
