import { FC, useEffect, useState } from 'react'
import { Dimensions, FlatList, RefreshControl, ScrollView, View } from 'react-native'

import { appStyles } from 'assets/styles/appStyles'
import { CategoryItem } from 'components/features/Category/CategoryItem'
import { mainIndent } from 'constants/app'
import { colors } from 'constants/colors'
import { CategoryBase } from 'interfaces/api/catalog.interfaces'
import { Navigation } from 'interfaces/common.interfaces'

import styles from './CategoriesList.styles'

interface Props {
  navigation: Navigation
  categories: CategoryBase[]
  isHomeScreen?: boolean
  refreshing?: boolean
  onRefresh?: VoidFunction
}

export const CategoriesList: FC<Props> = ({ categories, isHomeScreen, navigation, refreshing, onRefresh }) => {
  const [containerWidth, setContainerWidth] = useState(Dimensions.get('window').width - mainIndent * 2)

  const filledCategories = categories.filter((item) => !!item.totalDuration)

  const itemWidth = 223
  const itemsGap = 7
  const totalItemsWidth =
    Math.ceil(filledCategories.length / (filledCategories.length === 2 ? 1 : 2)) * (itemWidth + itemsGap * 2)

  useEffect(() => {
    const subscription = Dimensions.addEventListener('change', ({ window }) => {
      setContainerWidth(window.width - mainIndent * 2)
    })
    return () => subscription?.remove()
  }, [])

  if (isHomeScreen) {
    return (
      <ScrollView
        horizontal
        overScrollMode="never"
        scrollEnabled={totalItemsWidth > containerWidth}
        showsHorizontalScrollIndicator={false}
      >
        <View>
          <View style={styles.horizontalList}>
            {filledCategories
              .filter((_, index) => index % 2 === 0 || filledCategories.length < 3)
              .map((item, index) => (
                <CategoryItem
                  category={item}
                  index={index}
                  isHomeScreen={isHomeScreen}
                  itemLength={categories.length}
                  key={item.id}
                  navigation={navigation}
                  style={[styles.horizontalItem, { width: itemWidth }]}
                />
              ))}
          </View>
          {filledCategories.length >= 3 && (
            <View style={styles.horizontalList}>
              {filledCategories
                .filter((_, index) => index % 2 === 1)
                .map((item, index) => (
                  <CategoryItem
                    category={item}
                    index={index}
                    isHomeScreen={isHomeScreen}
                    itemLength={categories.length}
                    key={item.id}
                    navigation={navigation}
                    style={[styles.horizontalItem, { width: itemWidth }]}
                  />
                ))}
            </View>
          )}
        </View>
      </ScrollView>
    )
  }

  return (
    <FlatList
      columnWrapperStyle={styles.list}
      contentContainerStyle={[appStyles.mainPaddingHorizontal]}
      data={filledCategories}
      keyExtractor={(item) => String(item.id)}
      numColumns={2}
      refreshControl={<RefreshControl onRefresh={onRefresh} refreshing={!!refreshing} tintColor={colors.white} />}
      renderItem={({ item, index }) => (
        <CategoryItem category={item} index={index} itemLength={filledCategories.length} navigation={navigation} />
      )}
      showsVerticalScrollIndicator={false}
      style={appStyles.flex1}
    />
  )
}
