import { StyleSheet } from 'react-native'

export default StyleSheet.create({
  list: {
    gap: 13,
  },
  horizontalList: {
    flexDirection: 'row',
    gap: 10,
    paddingLeft: 15,
    paddingRight: 15,
  },
  horizontalItem: {
    height: 78,
    marginBottom: 10,
  },
})
