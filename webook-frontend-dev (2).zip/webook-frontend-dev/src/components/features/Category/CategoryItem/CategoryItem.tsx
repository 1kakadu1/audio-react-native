import { FC } from 'react'
import { Dimensions, StyleProp, TouchableOpacity, View, ViewStyle } from 'react-native'
import FastImage from 'react-native-fast-image'

import { appStyles } from 'assets/styles/appStyles'
import { Text } from 'components/shared/Text'
import { wordEndings } from 'constants/dictionaries'
import { convertHttpToHttps, parseWordEnding } from 'helpers'
import { formatSecondsToTimeWithTitles } from 'helpers/date'
import { CategoryBase } from 'interfaces/api/catalog.interfaces'
import { Navigation } from 'interfaces/common.interfaces'
import { Routes } from 'routes/routes'

import styles from './CategoryItem.styles'

interface Props {
  style?: StyleProp<ViewStyle>
  category: CategoryBase
  navigation: Navigation
  index: number
  itemLength: number
  isHomeScreen?: boolean
}

export const CategoryItem: FC<Props> = ({ category, navigation, style, index, itemLength, isHomeScreen }) => {
  const { time, timeTitle } = formatSecondsToTimeWithTitles(category?.totalDuration)

  const coursesCount = parseWordEnding(category.lectionsCount + category.coursesCount, wordEndings.material)

  const screenWidth = Dimensions.get('window').width
  const itemWidth = screenWidth / 2 - 20
  const isLastItem = index === itemLength - 1
  const isOddLength = itemLength % 2 !== 0
  const itemStyle = isLastItem && isOddLength ? { width: itemWidth } : { flex: 1 }

  const onItemPress = () => {
    if (category.coursesCount) {
      navigation.navigate(Routes.Category, { categoryId: category.id })
    } else {
      navigation.navigate(Routes.Course, { courseId: category.id })
    }
  }

  return (
    <TouchableOpacity
      activeOpacity={0.8}
      onPress={onItemPress}
      style={[styles.container, style, !isHomeScreen && itemStyle]}
    >
      <FastImage
        resizeMode={FastImage.resizeMode.cover}
        source={
          category.preview
            ? { uri: convertHttpToHttps(category.preview), priority: FastImage.priority.normal }
            : require('assets/images/empty-image.jpeg')
        }
        style={[appStyles.flex1, styles.image]}
      />
      <View style={styles.info}>
        <Text color="lightGray" style={[appStyles.text12, appStyles.textShadow]}>
          {category.lectionsCount + category.coursesCount} {coursesCount} • {time} {timeTitle}
        </Text>
        <Text numberOfLines={3} style={[appStyles.textShadow, styles.lineHeight]}>
          {category.title}
        </Text>
      </View>
      <View style={styles.shadowContainer} />
    </TouchableOpacity>
  )
}
