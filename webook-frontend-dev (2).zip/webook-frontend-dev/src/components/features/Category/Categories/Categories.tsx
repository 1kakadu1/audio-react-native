import { FC, useEffect } from 'react'
import { View } from 'react-native'

import { useNetInfo } from '@react-native-community/netinfo'
import { appStyles } from 'assets/styles/appStyles'
import { CategoriesList } from 'components/features/Category/CategoriesList'
import { Loader } from 'components/shared/Loader'
import { Text } from 'components/shared/Text'
import { DisconnectedBlock } from 'components/templates/DisconnectedBlock'
import { useRefetchOnSwipe } from 'hooks'
import { Navigation } from 'interfaces/common.interfaces'
import { useAppDispatch, useAppSelector } from 'store'
import { getCategories } from 'store/catalog/actions'

import styles from './Categories.styles'

interface Props {
  navigation: Navigation
}

export const Categories: FC<Props> = ({ navigation }) => {
  const { categories } = useAppSelector((state) => state.catalog)

  const dispatch = useAppDispatch()

  const { isConnected } = useNetInfo()

  const fetchData = () => {
    if (isConnected) {
      dispatch(getCategories())
    }
  }

  const { refreshing, onRefresh } = useRefetchOnSwipe(fetchData)

  useEffect(() => {
    fetchData()
  }, [isConnected])

  if (isConnected === false && !categories.list.length) {
    return <DisconnectedBlock />
  }

  if (categories.loading && !categories.list.length) {
    return <Loader />
  }

  return (
    <View style={[appStyles.flex1, appStyles.mainMarginTop, styles.container]}>
      <Text style={[appStyles.text28, appStyles.mainPaddingHorizontal]}>Категории</Text>
      <CategoriesList
        categories={categories.list}
        navigation={navigation}
        onRefresh={onRefresh}
        refreshing={refreshing}
      />
    </View>
  )
}
