import { StyleSheet } from 'react-native'

export default StyleSheet.create({
  container: {
    gap: 20,
    paddingBottom: 0,
    paddingTop: 20,
  },
})
