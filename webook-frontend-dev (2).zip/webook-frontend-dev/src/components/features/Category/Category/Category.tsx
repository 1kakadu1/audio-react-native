import { FC, useEffect } from 'react'
import { RefreshControl, ScrollView, View } from 'react-native'

import { useNetInfo } from '@react-native-community/netinfo'
import { appStyles } from 'assets/styles/appStyles'
import { CoursesList } from 'components/features/Course/CoursesList'
import { LecturesList } from 'components/features/Lectures/LecturesList'
import { Loader } from 'components/shared/Loader'
import { Text } from 'components/shared/Text'
import { DisconnectedBlock } from 'components/templates/DisconnectedBlock'
import { colors } from 'constants/colors'
import { wordEndings } from 'constants/dictionaries'
import { formatSecondsToTimeWithTitles, parseWordEnding } from 'helpers'
import { useIsReady, useRefetchOnSwipe } from 'hooks'
import { Navigation } from 'interfaces/common.interfaces'
import { useAppDispatch, useAppSelector } from 'store'
import { getCategory } from 'store/catalog/actions'

import styles from './Category.styles'

interface Props {
  navigation: Navigation
  categoryId: number
}

export const Category: FC<Props> = ({ categoryId, navigation }) => {
  const { category } = useAppSelector((state) => state.catalog)

  const currentCourse = category?.item?.[categoryId]

  const { time, timeTitle } = formatSecondsToTimeWithTitles(currentCourse?.totalDuration)

  const coursesCount = currentCourse?.courses?.length
    ? currentCourse.courses.filter((item) => item.totalDuration && item.totalDuration > 0).length
    : 0
  const coursesCountTitle = parseWordEnding(coursesCount, wordEndings.course)
  const lecturesCountTitle = parseWordEnding(currentCourse?.lections?.length, wordEndings.lecture)

  const dispatch = useAppDispatch()

  const { isConnected } = useNetInfo()
  const isReady = useIsReady()

  const fetchData = () => {
    if (isConnected) {
      dispatch(getCategory(categoryId))
    }
  }

  const { refreshing, onRefresh } = useRefetchOnSwipe(fetchData)

  useEffect(() => {
    fetchData()
  }, [isConnected])

  if (isConnected === false && !currentCourse?.id) {
    return <DisconnectedBlock />
  }

  if ((category.loading && !currentCourse?.id) || !isReady) {
    return <Loader />
  }

  return (
    <View style={[appStyles.flex1, appStyles.mainMarginTop]}>
      <Text style={[appStyles.text30, appStyles.mainPaddingHorizontal, styles.title]}>
        {category?.item?.[categoryId]?.title}
      </Text>

      {currentCourse?.id ? (
        <>
          <View style={[appStyles.mainPaddingHorizontal, styles.counters]}>
            <View style={styles.counter}>
              <Text style={appStyles.text18}>{coursesCount} </Text>
              <Text style={appStyles.text14}>{coursesCountTitle}</Text>
            </View>
            <View style={styles.counter}>
              <Text style={appStyles.text18}>{currentCourse?.lections?.length ?? 0} </Text>
              <Text style={appStyles.text14}>{lecturesCountTitle}</Text>
            </View>
            <View style={styles.counter}>
              <Text style={appStyles.text18}>{time} </Text>
              <Text style={appStyles.text14}>{timeTitle}</Text>
            </View>
          </View>

          <ScrollView
            refreshControl={<RefreshControl onRefresh={onRefresh} refreshing={!!refreshing} tintColor={colors.white} />}
            showsVerticalScrollIndicator={false}
          >
            {currentCourse?.courses.findIndex((item) => item?.totalDuration && item?.totalDuration > 0) > -1 && (
              <View style={styles.courses}>
                <Text style={[appStyles.text16, appStyles.mainPaddingHorizontal, styles.subtitle]}>Курсы</Text>
                <CoursesList courses={currentCourse.courses} navigation={navigation} />
              </View>
            )}

            {!!currentCourse?.lections?.length && (
              <View style={appStyles.flex1}>
                <Text style={[appStyles.text16, appStyles.mainPaddingHorizontal, styles.subtitle]}>Лекции</Text>
                <LecturesList isBlocked lectures={currentCourse.lections} />
              </View>
            )}
          </ScrollView>
        </>
      ) : (
        <Text style={[appStyles.mainPaddingHorizontal, appStyles.text16]}>
          Отсутствуют материалы по данной категории
        </Text>
      )}
    </View>
  )
}
