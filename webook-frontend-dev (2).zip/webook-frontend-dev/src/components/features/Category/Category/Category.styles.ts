import { StyleSheet } from 'react-native'

export default StyleSheet.create({
  title: {
    marginBottom: 10,
    marginTop: 12,
  },
  subtitle: {
    marginBottom: 10,
  },
  counters: {
    flexDirection: 'row',
    gap: 10,
    marginBottom: 20,
  },
  counter: {
    alignItems: 'center',
    flexDirection: 'row',
  },
  courses: {
    marginBottom: 30,
    marginTop: 10,
  },
})
