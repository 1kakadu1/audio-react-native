import { FC } from 'react'
import { RefreshControl, ScrollView, View } from 'react-native'

import { useNetInfo } from '@react-native-community/netinfo'
import { useNavigation } from '@react-navigation/native'
import { appStyles } from 'assets/styles/appStyles'
import { CardsBlock } from 'components/features/Cards/CardsBlock'
import { Subscription } from 'components/features/Profile/Subscription'
import { Button } from 'components/shared/Button'
import { Loader } from 'components/shared/Loader'
import { Text } from 'components/shared/Text'
import { DisconnectedBlock } from 'components/templates/DisconnectedBlock'
import { colors } from 'constants/colors'
import { useRefetchOnSwipe } from 'hooks'
import { Navigation } from 'interfaces/common.interfaces'
import { Routes } from 'routes/routes'
import { useAppDispatch, useAppSelector } from 'store'
import { clearToken } from 'store/auth/actions'
import { getUser } from 'store/user/actions'

import styles from './ProfileBlock.styles'

export const ProfileBlock: FC = () => {
  const { user, loading } = useAppSelector((state) => state.user)
  const dispatch = useAppDispatch()
  const navigation = useNavigation<Navigation>()

  const { isConnected } = useNetInfo()

  const fetchData = () => {
    if (isConnected) {
      dispatch(getUser())
    }
  }

  const { refreshing, onRefresh } = useRefetchOnSwipe(fetchData)

  if (isConnected === false && !user) {
    return <DisconnectedBlock />
  }

  if (loading && !user) {
    return <Loader />
  }

  return (
    <View style={[appStyles.flex1, appStyles.mainPaddingHorizontal, appStyles.mainMarginTop, styles.container]}>
      <Text style={appStyles.text28}>Профиль</Text>
      <ScrollView
        refreshControl={<RefreshControl onRefresh={onRefresh} refreshing={refreshing} tintColor={colors.white} />}
        showsVerticalScrollIndicator={false}
        style={appStyles.flex1}
      >
        <View style={styles.block}>
          <Text style={appStyles.text18}>Моя подписка</Text>
          <Subscription />
          <CardsBlock />
        </View>
        <View style={styles.block}>
          <Button bordered onPress={() => navigation.navigate(Routes.Statics)} title="Правовая информация" />
          <Button bordered onPress={() => dispatch(clearToken())} title="Logout" />
        </View>
      </ScrollView>
    </View>
  )
}
