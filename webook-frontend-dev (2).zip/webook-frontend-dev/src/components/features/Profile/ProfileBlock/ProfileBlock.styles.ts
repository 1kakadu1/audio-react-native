import { StyleSheet } from 'react-native'

export default StyleSheet.create({
  container: {
    gap: 20,
    paddingTop: 20,
  },
  block: {
    gap: 10,
    marginBottom: 30,
  },
})
