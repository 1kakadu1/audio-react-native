import { StyleSheet } from 'react-native'

import { colors } from 'constants/colors'

export default StyleSheet.create({
  container: {
    gap: 16,
    paddingBottom: 35,
    paddingTop: 40,
  },
  title: {
    color: colors.white,
    marginBottom: 14,
  },
  subtitle: {
    color: colors.gray5,
    marginBottom: 6,
  },
})
