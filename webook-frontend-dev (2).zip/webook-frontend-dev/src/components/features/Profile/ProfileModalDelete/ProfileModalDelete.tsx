import { FC } from 'react'
import { Text, View } from 'react-native'

import { appStyles } from 'assets/styles/appStyles'
import { Button } from 'components/shared/Button'
import { ModalWindow } from 'components/shared/ModalWindow'

import styles from './ProfileModalDelete.styles'

interface Props {
  open: boolean
  onClose: () => void
}

export const ProfileModalDelete: FC<Props> = ({ open, onClose }) => (
  <ModalWindow
    childen={
      <View style={styles.container}>
        <Text style={[appStyles.text28, appStyles.textWeight400, styles.title]}>
          Вы уверены, что хотите удалить профиль?
        </Text>
        <Text style={[appStyles.text14, appStyles.textWeight400, styles.subtitle]}>
          Карта будет отключена от аккаунта, и подписка – приостановится
        </Text>
        <Button bordered colorBordered="red" dangerBordered title="Удалить" />
        <Button onPress={onClose} title="Оставить профиль" />
      </View>
    }
    onClose={onClose}
    open={open}
  />
)
