import { Controller, FormProvider, useForm } from 'react-hook-form'
import { Text, View } from 'react-native'

import { yupResolver } from '@hookform/resolvers/yup'
import { Button } from 'components/shared/Button'
import { TextInput } from 'components/shared/TextInput'
import { inputMask } from 'constants/app'
import { UserEditData } from 'interfaces/api/user.interfaces'
import { useAppDispatch, useAppSelector } from 'store'
import { updateUser } from 'store/user/actions'
import { userEditSchema } from 'utils/validation'

import styles from './ProfileEditForm.styles'

export const ProfileEditForm = () => {
  const { user, loading } = useAppSelector((state) => state.user)
  const dispath = useAppDispatch()

  const methods = useForm<UserEditData>({
    resolver: yupResolver(userEditSchema),
    defaultValues: {
      name: user?.name,
      phone: user?.phone,
      email: user?.email || '',
      registerNumber: user?.registerNumber || '',
    },
  })

  const onSave = async (data: UserEditData) => dispath(updateUser(data))

  return (
    <View style={styles.flex}>
      <View style={styles.container}>
        <Text style={styles.title}>Редактирование профиля</Text>
        <FormProvider {...methods}>
          <View style={styles.form}>
            <Controller
              control={methods.control}
              name="name"
              render={({ field, fieldState: { error } }) => (
                <TextInput
                  clearError={() => methods.clearErrors('name')}
                  error={error?.message}
                  onChangeText={field.onChange}
                  placeholder="ФИО"
                  showLabelAlways
                  style={styles.input}
                  value={field.value}
                />
              )}
            />
            <TextInput
              editable={false}
              mask={inputMask.phone}
              onChangeText={() => void 0}
              placeholder="Номер телефона"
              selectTextOnFocus={false}
              showLabelAlways
              style={styles.inputDisable}
              value={user?.phone}
            />
            <Controller
              control={methods.control}
              name="email"
              render={({ field, fieldState: { error } }) => (
                <TextInput
                  clearError={() => methods.clearErrors('email')}
                  error={error?.message}
                  onChangeText={field.onChange}
                  placeholder="Email"
                  showLabelAlways
                  style={styles.input}
                  value={field.value}
                />
              )}
            />

            <Controller
              control={methods.control}
              name="registerNumber"
              render={({ field, fieldState: { error } }) => (
                <TextInput
                  clearError={() => methods.clearErrors('registerNumber')}
                  error={error?.message}
                  onChangeText={field.onChange}
                  placeholder="Регистрационный номер (для адвокатов)  "
                  showLabelAlways
                  style={styles.input}
                  value={field.value}
                />
              )}
            />
          </View>
        </FormProvider>
      </View>

      <Button
        disabled={Object.keys(methods.formState.errors).length > 0}
        loading={loading}
        onPress={methods.handleSubmit(onSave)}
        style={styles.btnSave}
        title="Сохранить"
      />
    </View>
  )
}
