import { StyleSheet } from 'react-native'

import { colors } from 'constants/colors'

export default StyleSheet.create({
  flex: {
    flex: 1,
    gap: 70,
    justifyContent: 'space-between',
  },
  container: {
    paddingTop: 30,
  },
  title: {
    color: colors.white,
    fontSize: 35,
    fontWeight: '400',
    paddingBottom: 30,
  },
  input: {
    borderBottomColor: colors.white,
  },
  inputDisable: {
    color: colors.gray,
  },
  form: {
    gap: 30,
    marginBottom: 20,
  },
  btnSave: {
    marginBottom: 10,
  },
})
