import { useEffect, useState } from 'react'
import { Text, View } from 'react-native'
import Snackbar from 'react-native-snackbar'

import { useNetInfo } from '@react-native-community/netinfo'
import { useNavigation } from '@react-navigation/native'
import { api } from 'api'
import MedalIcon from 'assets/icons/medal.svg'
import { appStyles } from 'assets/styles/appStyles'
import { CardsBlock } from 'components/features/Cards/CardsBlock'
import { Subscription } from 'components/features/Profile/Subscription'
import { Button } from 'components/shared/Button'
import { Loader } from 'components/shared/Loader'
import { ScrollListText } from 'components/shared/ScrollListText'
import { TimeInfo } from 'components/shared/TimeInfo'
import { DisconnectedBlock } from 'components/templates/DisconnectedBlock'
import { colors } from 'constants/colors'
import { documentDirectory, EncodingType, writeAsStringAsync } from 'expo-file-system'
import * as Sharing from 'expo-sharing'
import { UserListeningTime } from 'interfaces/api/user.interfaces'
import { Navigation } from 'interfaces/common.interfaces'
import { Routes } from 'routes/routes'
import { useAppDispatch, useAppSelector } from 'store'
import { clearToken } from 'store/auth/actions'
import { splitString } from 'utils/lecture'

import styles from './ProfileInfo.styles'

export const ProfileInfo = () => {
  const { user, loading, listeningTime } = useAppSelector((state) => state.user)
  const { isConnected } = useNetInfo()
  const navigation = useNavigation<Navigation>()
  const gotoEdit = () => navigation.navigate(Routes.ProfileEdit)
  const dispatch = useAppDispatch()
  const [year, setYear] = useState<UserListeningTime | null>(null)
  const [loadingCertificate, setLoadingCertificate] = useState(false)

  useEffect(() => {
    if (!listeningTime.loading && listeningTime.items.length > 0) {
      const _year = new Date().getFullYear()
      setYear(listeningTime.items.find((item) => item.year === _year) || null)
    }
  }, [listeningTime.items])

  const onChangeYear = ({ value }: { value: string; label: string }) => {
    const _item = listeningTime.items.find((item) => item.year.toString() === value)
    if (_item) {
      setYear(_item)
    }
  }

  const onDownloadCertificate = () => {
    if (!isConnected) {
      Snackbar.show({ text: 'Проверьте подключение к интернету', backgroundColor: colors.red })
      return
    }
    if (listeningTime.loading || year === null || year.canDownloadCertificate === false) {
      Snackbar.show({ text: 'У вас мало часов для получения сертификата', backgroundColor: colors.red })
      return
    }

    if (!user?.registerNumber) {
      Snackbar.show({
        text: 'Для скачивания сертификата укажите ваш регистрационный номер/почту',
        backgroundColor: colors.red,
      })
      return
    }
    setLoadingCertificate(true)
    api.user
      .getCertificate(year.year)
      .then((res) => {
        const fr = new FileReader()
        fr.onload = async () => {
          const fileUri = `${documentDirectory}/certificate_${year.year}.pdf`
          await writeAsStringAsync(fileUri, (fr.result as string).split(',')[1], { encoding: EncodingType.Base64 })
          Sharing.shareAsync(fileUri)
          setLoadingCertificate(false)
        }
        fr.onerror = () => {
          setLoadingCertificate(false)
          Snackbar.show({
            text: 'Ошибка при создании файла',
            backgroundColor: colors.red,
          })
        }
        fr.readAsDataURL(res)
      })
      .catch((e) => {
        setLoadingCertificate(false)
        Snackbar.show({
          text: e?.rensponse?.data?.messag || e?.message || 'Ошибка сервера',
          backgroundColor: colors.red,
        })
      })
  }

  if (isConnected === false && user !== null) {
    return <DisconnectedBlock />
  }

  if (loading && user === null) {
    return <Loader />
  }

  return (
    <View style={styles.container}>
      <View>
        <Text style={[styles.title, appStyles.textWeight400]}>Профиль</Text>
        <Text style={[appStyles.text28, appStyles.textWeight400, styles.name]}>{splitString(user?.name)}</Text>
        <Text style={[styles.phone, appStyles.textWeight400]}>{user?.phone || 'нет'}</Text>
        <Text style={[styles.number, appStyles.textWeight400]}>Регистрационный номер: {user?.registerNumber}</Text>
        <Button
          bordered
          colorBordered="white"
          disabled={isConnected === false}
          onPress={gotoEdit}
          style={styles.btn}
          title="Редактировать профиль"
        />
      </View>

      <View style={styles.status}>
        <Text style={[appStyles.text16, styles.titleSmall, appStyles.text18, appStyles.textWeight400]}>
          Моя подписка
        </Text>
        <Subscription />
        <CardsBlock />
      </View>

      <View style={styles.certificate}>
        <Text style={[appStyles.text16, styles.titleSmall, appStyles.text18, appStyles.textWeight400]}>Мои часы</Text>

        <ScrollListText
          active={year?.year?.toString() || '2024'}
          items={listeningTime.items.map((item) => ({ label: item.year.toString(), value: item.year.toString() }))}
          onPress={onChangeYear}
        />
        <TimeInfo
          column
          description="в этом году часов материала прослушано"
          time={year?.totalListeningTime.toString() || '0'}
        />
        <Button
          bordered={!loadingCertificate}
          icon={<MedalIcon />}
          loading={loadingCertificate}
          onPress={onDownloadCertificate}
          title="Скачать сертификат"
        />
      </View>

      <Text style={[appStyles.text14, appStyles.textWeight400, styles.info]}>
        ООО ВИБУК {'\n'}
        ИНН: 5902067436 {'\n'}
        КП: 590201001 {'\n'}г Пермь, ул., Окулова 18-39
      </Text>
      <View style={styles.footerActions}>
        <Button bordered onPress={() => navigation.navigate(Routes.Statics)} title="Правовая информация" />
        <Button bordered onPress={() => dispatch(clearToken())} title="Выход" />
      </View>
    </View>
  )
}
