import { StyleSheet } from 'react-native'

import { colors } from 'constants/colors'

export default StyleSheet.create({
  container: {
    gap: 35,
    paddingBottom: 35,
    paddingTop: 40,
  },
  title: {
    color: colors.white,
    fontSize: 35,
    fontWeight: '400',
    paddingBottom: 30,
  },
  name: {
    color: colors.white,
    lineHeight: 35.84,
    maxWidth: 290,
    paddingBottom: 6,
  },
  phone: {
    color: colors.gray5,
    paddingBottom: 6,
  },
  number: {
    color: colors.gray5,
    paddingBottom: 6,
  },
  btn: {
    marginTop: 4,
    width: 238,
  },
  titleSmall: {
    color: colors.white,
  },
  certificate: {
    gap: 14,
  },
  subscribe: {
    gap: 8,
  },
  status: {
    gap: 19,
  },
  info: {
    color: colors.gray5,
  },
  footerActions: {
    gap: 12,
    marginBottom: 10,
  },
})
