import { StyleSheet } from 'react-native'

export default StyleSheet.create({
  info: {
    gap: 2,
  },
  btn: {
    marginTop: 20,
    paddingHorizontal: 40,
  },
})
