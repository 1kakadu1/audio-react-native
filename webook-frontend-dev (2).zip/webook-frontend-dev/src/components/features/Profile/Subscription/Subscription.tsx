import { useMemo, useState } from 'react'
import { View } from 'react-native'

import { useNavigation } from '@react-navigation/native'
import { appStyles } from 'assets/styles/appStyles'
import { Button } from 'components/shared/Button'
import { ConfirmModal } from 'components/shared/ConfirmModal'
import { Text } from 'components/shared/Text'
import { formatDate } from 'helpers'
import { Navigation } from 'interfaces/common.interfaces'
import { Routes } from 'routes/routes'
import { useAppSelector } from 'store'

import styles from './Subscription.styles'

export const Subscription = ({
  hideActions = false,
  hideDesriptionSuccess = false,
}: {
  hideActions?: boolean
  hideDesriptionSuccess?: boolean
}) => {
  const [removeSubscriptionModalVisible, setRemoveSubscriptionModalVisible] = useState(false)
  const { user } = useAppSelector((state) => state.user)
  const { card } = useAppSelector((store) => store.user)
  const { paymentsSubsribe } = useAppSelector((store) => store.payments)
  const navigation = useNavigation<Navigation>()

  const hasCard = !card?.data
  const disabled = useMemo(
    () => paymentsSubsribe.loading || !card?.data || card.loading || paymentsSubsribe.payments.length === 0,
    [paymentsSubsribe, card],
  )
  const isNewSubscription = user?.activeSub === null
  const isSubscribed = user?.activeSub
  const isSubscribedOff = isSubscribed && !user?.activeSub?.expiredAt
  const onConfirmRemove = () => {
    // TODO: Доработать после реализации бэка
    console.log('removing subscription')
  }

  const onBuyPress = () => {
    const item = paymentsSubsribe.payments[0]
    if (item) {
      navigation.navigate(Routes.Purchase, {
        isSubscription: true,
        price: item.price.toString(),
        title: item.name,
        subscriptionId: item.id,
      })
    }
  }

  return (
    <View>
      <View style={styles.info}>
        <Text>
          <Text color={user?.activeSub ? 'yellow' : 'red'} style={[appStyles.text16, appStyles.textWeight700]}>
            {isSubscribed ? 'Подписка активна ' : 'Подписка не активирована'}
          </Text>
          {isSubscribed && !!user?.activeSub?.expiredAt && (
            <Text color="gray" style={appStyles.text16}>
              до {formatDate(user.activeSub.expiredAt)}
            </Text>
          )}
        </Text>
        {hasCard && isSubscribed && (
          <Text color="gray" style={appStyles.text16}>
            Включено автоматическое продление подписки
          </Text>
        )}
        {isSubscribed && !hasCard && !hideDesriptionSuccess && (
          <Text color="gray" style={appStyles.text16}>
            Укажите карту для автоматического продления подписки
          </Text>
        )}
        {isNewSubscription && (
          <Text color="gray" style={appStyles.text16}>
            Приобретите подписку, чтобы получить доступ к бесплатным урокам и иметь возможность получить сертификат
          </Text>
        )}
      </View>
      {/* TODO: нет пока автопродления подписки*/}
      {/* {isSubscribed && !hideActions && (
        <Button
          danger
          disabled={disabled}
          onPress={() => setRemoveSubscriptionModalVisible(true)}
          style={styles.btn}
          title="Отменить подписку"
        />
      )} */}
      {isNewSubscription && !hideActions && (
        <Button disabled={disabled} onPress={onBuyPress} style={styles.btn} title="Купить подписку" />
      )}
      {isSubscribed && isSubscribedOff && !hideActions && (
        <Button disabled={disabled} onPress={onBuyPress} style={styles.btn} title="Восстановить подписку" />
      )}
      <ConfirmModal
        cancelText="Оставить подписку"
        confirmText="Отменить подписку"
        loading={false}
        modalVisible={removeSubscriptionModalVisible}
        onConfirmPress={onConfirmRemove}
        setModalVisible={setRemoveSubscriptionModalVisible}
        title="Вы уверены, что хотите отменить подписку?"
      />
    </View>
  )
}
