import { View } from 'react-native'

import { appStyles } from 'assets/styles/appStyles'
import { ListenedHoursInfo } from 'components/features/ListenedHoursInfo'
import { Loader } from 'components/shared/Loader'
import { Text } from 'components/shared/Text'
import { formatSecondsToHours, parseFirstName } from 'helpers'
import { useAppSelector } from 'store'

import styles from './HomeTop.styles'

export const HomeTop = () => {
  const { user, loading } = useAppSelector((state) => state.user)

  if (loading && !user) {
    return <Loader />
  }

  return (
    <View style={[appStyles.flex1, appStyles.mainPaddingHorizontal, styles.container]}>
      <ListenedHoursInfo hours={formatSecondsToHours(user?.totalListened)} />
      <Text style={appStyles.text28}>{parseFirstName(user?.name)}</Text>
    </View>
  )
}
