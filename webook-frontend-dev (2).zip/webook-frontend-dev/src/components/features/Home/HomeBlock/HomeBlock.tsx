import { FC } from 'react'
import { View } from 'react-native'

import { appStyles } from 'assets/styles/appStyles'
import { NewLecturesList } from 'components/features/Lectures/NewLecturesList'
import { Text } from 'components/shared/Text'
import { HomeBlockBase as HomeBlockInterface } from 'interfaces/api/home.interfaces'
import { useAppSelector } from 'store'

import styles from './HomeBlock.styles'

interface Props {
  item: HomeBlockInterface
}

export const HomeBlock: FC<Props> = ({ item }) => {
  const { block } = useAppSelector((state) => state.home)

  if (!block.item?.[item.slug]?.lections?.length) {
    return null
  }

  return (
    <>
      <View style={[styles.header, appStyles.mainPaddingHorizontal]}>
        <Text style={appStyles.text16}>{item.title}</Text>
      </View>
      <NewLecturesList lectures={block.item[item.slug].lections} />
    </>
  )
}
