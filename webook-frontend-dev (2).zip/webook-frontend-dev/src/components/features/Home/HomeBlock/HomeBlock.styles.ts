import { StyleSheet } from 'react-native'

export default StyleSheet.create({
  header: {
    alignItems: 'center',
    flexDirection: 'row',
    flex: 1,
    justifyContent: 'space-between',
    marginVertical: 15,
  },
})
