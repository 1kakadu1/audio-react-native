import { FC } from 'react'
import { TouchableOpacity, View } from 'react-native'

import { appStyles } from 'assets/styles/appStyles'
import { CategoriesList } from 'components/features/Category/CategoriesList'
import { Text } from 'components/shared/Text'
import { Navigation } from 'interfaces/common.interfaces'
import { Routes } from 'routes/routes'
import { useAppSelector } from 'store'

import styles from './HomeCategories.styles'

interface Props {
  navigation: Navigation
}

export const HomeCategories: FC<Props> = ({ navigation }) => {
  const { homeCategories } = useAppSelector((state) => state.catalog)

  const onPress = () => {
    navigation.navigate(Routes.Catalog)
  }

  if (!homeCategories.list.length) {
    return null
  }

  return (
    <>
      <View style={[styles.header, appStyles.mainPaddingHorizontal]}>
        <Text style={appStyles.text16}>Категории</Text>
        <TouchableOpacity activeOpacity={0.8} hitSlop={10} onPress={onPress}>
          <Text color="yellow" style={[appStyles.text12, appStyles.textWeight500]}>
            смотреть все →
          </Text>
        </TouchableOpacity>
      </View>
      <CategoriesList categories={homeCategories.list} isHomeScreen navigation={navigation} />
    </>
  )
}
