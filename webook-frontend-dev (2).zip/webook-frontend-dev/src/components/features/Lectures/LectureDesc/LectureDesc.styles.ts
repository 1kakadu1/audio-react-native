import { StyleSheet } from 'react-native'

export default StyleSheet.create({
  container: {
    marginTop: 40,
    paddingHorizontal: 15,
  },
  imageWrap: {
    alignSelf: 'center',
    marginBottom: 20,
    marginHorizontal: 15,
  },
  image: {
    bottom: 0,
    left: 0,
    position: 'absolute',
    right: 0,
    top: 0,
  },
  title: {
    marginBottom: 9,
  },
  description: {
    marginBottom: 15,
  },
})
