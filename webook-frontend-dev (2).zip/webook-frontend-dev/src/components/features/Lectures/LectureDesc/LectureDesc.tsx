import { FC } from 'react'
import { Dimensions, ScrollView, View } from 'react-native'

import { appStyles } from 'assets/styles/appStyles'
import { ImageWithPreview } from 'components/shared/ImageWithPreview'
import { Text } from 'components/shared/Text'
import { Lecture as LectureInterface } from 'interfaces/api/catalog.interfaces'

import styles from './LectureDesc.styles'

interface Props {
  item: LectureInterface
}

export const LectureDesc: FC<Props> = ({ item }) => {
  const screenWidth = Dimensions.get('window').width
  const imageSize = screenWidth - 60

  return (
    <ScrollView showsVerticalScrollIndicator={false} style={[appStyles.flex1, styles.container]}>
      <View style={[styles.imageWrap, { width: imageSize, height: imageSize }]}>
        <ImageWithPreview
          emptyImage={require('assets/images/empty-image.jpeg')}
          imageUri={item.image}
          previewUri={item.preview}
          style={[styles.image, { width: imageSize, height: imageSize }]}
        />
      </View>
      <View style={appStyles.mainPaddingHorizontal}>
        <Text style={[appStyles.text26, appStyles.textWeight700, styles.title]}>{item.title}</Text>
        {item.description && (
          <Text color="lightGray" style={[appStyles.text16, styles.description]}>
            {item.description}
          </Text>
        )}
      </View>
    </ScrollView>
  )
}
