export * from './NewLectureItem'
