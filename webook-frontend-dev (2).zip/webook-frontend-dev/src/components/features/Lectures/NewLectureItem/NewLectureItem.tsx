import { FC } from 'react'
import { StyleProp, TouchableOpacity, View, ViewStyle } from 'react-native'
import FastImage from 'react-native-fast-image'

import { useNavigation } from '@react-navigation/native'
import PlayIcon from 'assets/icons/play.svg'
import { appStyles } from 'assets/styles/appStyles'
import { Text } from 'components/shared/Text'
import { colors } from 'constants/colors'
import { convertHttpToHttps } from 'helpers'
import { formatSecondsToTime } from 'helpers/date'
import { Lecture } from 'interfaces/api/catalog.interfaces'
import { Navigation } from 'interfaces/common.interfaces'
import { Routes } from 'routes/routes'

import styles from './NewLectureItem.styles'

interface Props {
  style?: StyleProp<ViewStyle>
  lecture: Lecture
  lecturesList: Lecture[]
  size: number
}

export const NewLectureItem: FC<Props> = ({ lecture, lecturesList, style, size }) => {
  const navigation = useNavigation<Navigation>()

  const time = formatSecondsToTime(lecture?.duration)

  const onItemPress = () => {
    navigation.navigate(Routes.Lecture, { lecture, lecturesList })
  }

  return (
    <TouchableOpacity
      activeOpacity={0.8}
      onPress={onItemPress}
      style={[styles.container, style, { width: size, height: size }]}
    >
      <FastImage
        resizeMode={FastImage.resizeMode.cover}
        source={
          lecture.preview ? { uri: convertHttpToHttps(lecture.preview) } : require('assets/images/empty-image.jpeg')
        }
        style={[styles.image, { width: size, height: size }]}
      />
      <View style={styles.shadowContainer} />
      <View style={styles.info}>
        <Text color="lightGray" style={[appStyles.text12, appStyles.textShadow]}>
          {time}
        </Text>
        <Text numberOfLines={4} style={[appStyles.textShadow, appStyles.text14]}>
          {lecture.title}
        </Text>
        <PlayIcon color={colors.white} style={styles.icon} />
      </View>
    </TouchableOpacity>
  )
}
