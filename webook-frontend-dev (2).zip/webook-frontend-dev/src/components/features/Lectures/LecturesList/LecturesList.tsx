import { FC, useEffect, useState } from 'react'
import { FlatList as FlatListNative, RefreshControl as RefreshControlNative, StyleProp, ViewStyle } from 'react-native'
import { FlatList, RefreshControl } from 'react-native-gesture-handler'
import { State, Track } from 'react-native-track-player'

import { appStyles } from 'assets/styles/appStyles'
import { LecturesItem } from 'components/features/Lectures/LecturesItem'
import { colors } from 'constants/colors'
import { useAudioPlayerContext } from 'contexts/AudioPlayerContext'
import { Lecture } from 'interfaces/api/catalog.interfaces'
import { isEqual } from 'lodash'
import { useAppDispatch, useAppSelector } from 'store'
import { setCurrentTrack, setPlaylist } from 'store/audio/actions'

interface Props {
  style?: StyleProp<ViewStyle>
  isBlocked?: boolean
  lectures: Lecture[]
  isAnimated?: boolean
  refreshing?: boolean
  onRefresh?: VoidFunction
  setIsBlockedSwipe?: (value: boolean) => void
}

export const LecturesList: FC<Props> = ({
  isBlocked,
  lectures,
  style,
  isAnimated,
  refreshing,
  onRefresh,
  setIsBlockedSwipe,
}) => {
  const List = isAnimated ? FlatList : FlatListNative
  const RefreshComponent = isAnimated ? RefreshControl : RefreshControlNative

  const [preparingId, setPreparingId] = useState<number | null>(null)
  const [playBackStateInternal, setPlayBackStateInternal] = useState<State | undefined>(State.Ready)
  const [newPlayList, setNewPlayList] = useState<Track[]>([])

  const { list, playlist, currentTrack } = useAppSelector((state) => state.audio)

  const dispatch = useAppDispatch()

  const { playBackState, activeTrack, togglePlayback, skipToTrack } = useAudioPlayerContext()

  const playNewPlaylist = (id: number) => {
    const currentIndex = playlist.findIndex((el) => el.id === id)
    togglePlayback(State.Playing)
    if (newPlayList.length !== playlist.length || !isEqual(newPlayList, playlist) || currentIndex === -1) {
      dispatch(setPlaylist(newPlayList))
      dispatch(setCurrentTrack(id))
    } else {
      skipToTrack(currentIndex)
    }
    setPreparingId(id)
  }

  useEffect(() => {
    if (playBackState === State.Playing) {
      setPlayBackStateInternal(State.Playing)
    } else if (playBackState === State.Paused || playBackState === State.Ended) {
      setPlayBackStateInternal(State.Paused)
    }
    if (activeTrack?.id === currentTrack) {
      setPreparingId(null)
    }
  }, [playBackState])

  useEffect(() => {
    setNewPlayList(
      lectures
        .filter((elem) => list[elem.id]?.audioUpdatedAt === elem.audioUpdatedAt)
        .map((elem) => ({ ...list[elem.id], url: list[elem.id].audio })),
    )
  }, [list, lectures])

  return (
    <List
      contentContainerStyle={[appStyles.mainPaddingHorizontal, style]}
      data={lectures}
      keyExtractor={(item) => String(item.id)}
      onBegan={() => {
        if (!isBlocked) {
          setIsBlockedSwipe?.(true)
        }
      }}
      onTouchEnd={() => setIsBlockedSwipe?.(false)}
      refreshControl={<RefreshComponent onRefresh={onRefresh} refreshing={!!refreshing} tintColor={colors.white} />}
      renderItem={({ item, index }) => (
        <LecturesItem
          isActive={activeTrack?.id === item.id && currentTrack === item.id}
          isDownloaded={list[item.id]?.audioUpdatedAt === item.audioUpdatedAt}
          isLastChild={index === lectures.length - 1}
          isPreparing={preparingId === item.id}
          item={item}
          lecturesList={lectures}
          playBackState={playBackStateInternal}
          playNewPlaylist={playNewPlaylist}
        />
      )}
      scrollEnabled={!isBlocked}
    />
  )
}
