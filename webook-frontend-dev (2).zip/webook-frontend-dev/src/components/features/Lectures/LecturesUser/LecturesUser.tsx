import { FC, useEffect, useMemo } from 'react'
import { ScrollView, Text, View } from 'react-native'

import { useNetInfo } from '@react-native-community/netinfo'
import { useNavigation } from '@react-navigation/native'
import DownloadSmallIcon from 'assets/icons/download-simple.svg'
import { appStyles } from 'assets/styles/appStyles'
import { LecturesList } from 'components/features/Lectures/LecturesList'
import { Subscription } from 'components/features/Profile/Subscription'
import { Button } from 'components/shared/Button'
import { Loader } from 'components/shared/Loader'
import { TimeInfo } from 'components/shared/TimeInfo'
import { Title } from 'components/shared/Title'
import { colors } from 'constants/colors'
import { useDownloadContext } from 'contexts/DownloadContext'
import { Lecture } from 'interfaces/api/catalog.interfaces'
import { Navigation } from 'interfaces/common.interfaces'
import { Routes } from 'routes/routes'
import { useAppDispatch, useAppSelector } from 'store'
import { getByLections } from 'store/payment/actions'

import styles from './LecturesUser.styles'

export const LecturesUser: FC = () => {
  const { listeningTime } = useAppSelector((state) => state.user)
  const { lections } = useAppSelector((state) => state.payments)
  const { list } = useAppSelector((state) => state.audio)
  const navigation = useNavigation<Navigation>()

  const compareLections = useMemo(() => {
    const localLections: { [key: string]: Lecture } = JSON.parse(JSON.stringify(list))
    lections.items.forEach((element) => {
      if (localLections[element.id.toString()] === undefined) {
        localLections[element.id.toString()] = element
      }
    })
    return Object.values(localLections)
  }, [lections, list])

  const { setDownloadQueue } = useDownloadContext()
  const onDowloadAll = () => {
    setDownloadQueue((prev) => [...prev, ...lections.items])
  }
  const dispatch = useAppDispatch()

  const { isConnected } = useNetInfo()
  const fetchData = () => {
    if (isConnected && !lections.loading) {
      dispatch(getByLections())
    }
  }

  useEffect(() => {
    fetchData()
  }, [isConnected])

  if (lections.loading) {
    return <Loader />
  }

  return (
    <ScrollView
      showsVerticalScrollIndicator={false}
      style={[appStyles.flex1, appStyles.mainPaddingBottom, appStyles.mainPaddingHorizontal, appStyles.mainMarginTop]}
    >
      <Title paddingBottom paddingTop title="Мои лекции" />
      <Subscription hideActions hideDesriptionSuccess />
      <Button
        bordered
        onPress={() => navigation.navigate(Routes.User)}
        style={styles.btn}
        title="Управление подпиской"
      />

      <View style={styles.timeWrap}>
        <Text style={[appStyles.text16, styles.titlePadding, { color: colors.white }]}>Мои часы</Text>
        <TimeInfo
          description="в этом году часов материала прослушано"
          style={styles.timePadding}
          time={listeningTime.items.length > 0 ? listeningTime?.items[0]?.totalListeningTime.toString() : '0'}
        />
      </View>

      {lections.items.length > 0 && (
        <>
          <Text style={[appStyles.text18, styles.titlePadding, { color: colors.white }]}>Мне доступны</Text>
          <Button
            bordered
            icon={<DownloadSmallIcon color={colors.yellow} />}
            onPress={onDowloadAll}
            style={styles.btn}
            title="Скачать все"
          />
        </>
      )}

      <LecturesList isBlocked lectures={compareLections} />
    </ScrollView>
  )
}
