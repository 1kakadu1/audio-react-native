import { StyleSheet } from 'react-native'

export default StyleSheet.create({
  btn: {
    marginTop: 12,
  },
  timeWrap: {
    paddingVertical: 35,
  },
  timePadding: {
    paddingTop: 20,
  },
  titlePadding: {
    paddingBottom: 10,
  },
})
