import { FC, useMemo } from 'react'
import { TouchableOpacity } from 'react-native'

import { RouteProp, useRoute } from '@react-navigation/native'
import CurrencyIcon from 'assets/icons/currency.svg'
import { DownloadButton } from 'components/shared/DownloadButton'
import { colors } from 'constants/colors'
import { useDownloadContext } from 'contexts/DownloadContext'
import { usePayToScreen } from 'hooks'
import { RootNavigationParamList } from 'interfaces/common.interfaces'
import { Routes } from 'routes/routes'
import { useAppDispatch, useAppSelector } from 'store'
import { addLection } from 'store/payment/actions'
import { isPurchased } from 'utils/lecture'

type DetailsScreenRouteProp = RouteProp<RootNavigationParamList, Routes.Lecture>

export const DownloadLectureButton: FC = () => {
  const { params } = useRoute<DetailsScreenRouteProp>()
  const { id, onlyInSubscription } = params.lecture

  const { list } = useAppSelector((state) => state.audio)
  const { user, card } = useAppSelector((state) => state.user)
  const { lections } = useAppSelector((state) => state.payments)

  const dispatch = useAppDispatch()
  const { goPayScreen, goCreateCardToPaySubscribe } = usePayToScreen()
  const disabled = useMemo(() => {
    if (onlyInSubscription === false) {
      return false
    }

    return !card.data || !user?.activeSub
  }, [card, user])

  const { downloadQueue, setDownloadQueue } = useDownloadContext()

  const onDownload = () => {
    if (disabled) {
      goPayScreen({ goBack: true })
      return
    }

    setDownloadQueue((prev) => [...prev, params.lecture])
  }

  const onSuccess = () => {
    dispatch(addLection(params.lecture))
  }

  const onBuyPress = () => {
    if (card.data) {
      goPayScreen({ lection: params.lecture, onSuccess })
    } else {
      goCreateCardToPaySubscribe()
    }
  }

  if (!isPurchased(params.lecture, lections.items) || disabled) {
    return (
      <TouchableOpacity activeOpacity={0.8} hitSlop={20} onPress={onBuyPress}>
        <CurrencyIcon color={colors.yellow} />
      </TouchableOpacity>
    )
  }

  return (
    <DownloadButton
      isDownloaded={list[params.lecture.id]?.audioUpdatedAt === params.lecture.audioUpdatedAt}
      onPress={onDownload}
      progress={downloadQueue.findIndex((elem) => elem.id === id) > -1 ? 0 : undefined}
    />
  )
}
