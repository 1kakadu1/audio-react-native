import { FC, useEffect, useRef, useState } from 'react'
import {
  Dimensions,
  LayoutChangeEvent,
  NativeSyntheticEvent,
  ScrollView,
  StyleProp,
  TextLayoutEventData,
  TouchableOpacity,
  View,
  ViewStyle,
} from 'react-native'
import Snackbar from 'react-native-snackbar'
import { State } from 'react-native-track-player'

import { useNavigation } from '@react-navigation/native'
import { appStyles } from 'assets/styles/appStyles'
import { AudioPlayer } from 'components/shared/AudioPlayer'
import { ImageWithPreview } from 'components/shared/ImageWithPreview'
import { Text } from 'components/shared/Text'
import { PlayAudioErrorMessage } from 'constants/actionMessages'
import { colors } from 'constants/colors'
import { useAudioPlayerContext } from 'contexts/AudioPlayerContext'
import { useDownloadContext } from 'contexts/DownloadContext'
import { deleteFile } from 'helpers'
import { useIsReady } from 'hooks'
import { Lecture as LectureInterface } from 'interfaces/api/catalog.interfaces'
import { Navigation } from 'interfaces/common.interfaces'
import { isEqual } from 'lodash'
import { Routes } from 'routes/routes'
import { useAppDispatch, useAppSelector } from 'store'
import { removeFromDownloadedList, setAudioProgress, setCurrentTrack, setPlaylist } from 'store/audio/actions'

import styles from './Lecture.styles'

interface Props {
  style?: StyleProp<ViewStyle>
  item: LectureInterface
  lectures: LectureInterface[]
}

export const Lecture: FC<Props> = ({ item, style, lectures }) => {
  const [showFullDescBtn, setShowFullDescBtn] = useState(false)
  const [viewHeight, setViewHeight] = useState(0)
  const [isFirstRender, setIsFirstRender] = useState(true)
  const [currentLecture, setCurrentLecture] = useState<LectureInterface>(item)

  const { playlist, list } = useAppSelector((state) => state.audio)

  const dispatch = useAppDispatch()

  const navigation = useNavigation<Navigation>()

  const {
    activeTrack,
    skipToTrack,
    isWidgetPlayerHidden,
    togglePlayback,
    playBackState,
    setIsWidgetPlayerHidden,
    clearPlaylist,
    isPlayerReady,
  } = useAudioPlayerContext()

  const { setDownloadProgress } = useDownloadContext()
  const isReady = useIsReady()
  const screenWidth = Dimensions.get('window').width
  const screenHeight = Dimensions.get('window').height
  const isSmallScreen = screenHeight - viewHeight - 180 < screenWidth - 60
  const imageSize = isSmallScreen ? screenHeight - (viewHeight + 220) : screenWidth - 60
  const refDescLen = useRef(0)
  const refDescWidth = useRef(0)
  const refDescHideLen = useRef(0)
  const refTitleLen = useRef(0)
  const refTitleWidth = useRef(0)
  const refTitleHideLen = useRef(0)
  const currentPlaylist = lectures
    .filter((elem) => list[elem.id]?.audioUpdatedAt === elem.audioUpdatedAt)
    .map((elem) => ({ ...list[elem.id], url: list[elem.id].audio }))

  const onDescLayout = (e: NativeSyntheticEvent<TextLayoutEventData>) => {
    const { lines } = e.nativeEvent
    refDescLen.current = lines.length
    refDescWidth.current = lines[1]?.width || 0
  }
  const onDescHideLayout = (e: NativeSyntheticEvent<TextLayoutEventData>) => {
    const { lines } = e.nativeEvent
    refDescHideLen.current = lines.length
  }
  const onTitleLayout = (e: NativeSyntheticEvent<TextLayoutEventData>) => {
    const { lines } = e.nativeEvent
    refTitleLen.current = lines.length
    refTitleWidth.current = lines[1]?.width || 0
  }
  const onTitleHideLayout = (e: NativeSyntheticEvent<TextLayoutEventData>) => {
    const { lines } = e.nativeEvent
    refTitleHideLen.current = lines.length
  }
  const onBottomBlockLayout = (event: LayoutChangeEvent) => {
    const { height } = event.nativeEvent.layout
    setViewHeight(height)
  }

  const openFullDesc = () => navigation.navigate(Routes.LectureDesc, { lecture: currentLecture })

  const setCurrentPlaylist = () => {
    if (isPlayerReady) {
      togglePlayback(State.Playing)
    }
    dispatch(setPlaylist(currentPlaylist))
    dispatch(setCurrentTrack(item.id))
  }

  useEffect(() => {
    if (
      (refDescHideLen.current > refDescLen.current ||
        refDescWidth.current > imageSize - 10 ||
        refDescLen.current > 2 ||
        refTitleHideLen.current > refTitleLen.current ||
        refTitleLen.current > 3 ||
        refTitleWidth.current > imageSize - 10) &&
      isReady
    ) {
      setShowFullDescBtn(true)
    } else {
      setShowFullDescBtn(false)
    }
  }, [
    refDescHideLen.current,
    refDescLen.current,
    refDescWidth.current,
    refTitleWidth.current,
    refTitleHideLen.current,
    refTitleLen.current,
    isReady,
  ])

  useEffect(() => {
    const currentTrack = playlist.find((elem) => elem.id === activeTrack?.id)
    if (!isFirstRender && currentTrack && isWidgetPlayerHidden) {
      setCurrentLecture({
        image: currentTrack.image,
        preview: currentTrack.preview,
        title: currentTrack.title ?? '',
        description: currentTrack.description,
        duration: currentTrack.duration ?? 0,
        audio: currentTrack.url,
        id: currentTrack.id,
        audioUpdatedAt: '',
        createdAt: '',
        price: '',
        updatedAt: '',
        isPublished: true,
        onlyInSubscription: currentLecture.onlyInSubscription,
      })
    }
  }, [activeTrack?.id, item.id])

  useEffect(() => {
    setTimeout(() => setIsFirstRender(false), 2000)
    const currentIndex = currentPlaylist.findIndex((elem) => item.id === elem.id)

    if ((currentPlaylist.length !== playlist.length || !isEqual(currentPlaylist, playlist)) && currentIndex > -1) {
      setCurrentPlaylist()
      return
    }

    if (currentIndex > -1 && item.id !== activeTrack?.id) {
      skipToTrack(currentIndex)
    }
  }, [item.id])

  useEffect(() => {
    if (playBackState === State.Error && activeTrack) {
      Snackbar.show({ text: PlayAudioErrorMessage.PlayError, backgroundColor: colors.red, numberOfLines: 3 })
      dispatch(removeFromDownloadedList(activeTrack.id))
      dispatch(setAudioProgress({ id: activeTrack.id, progress: 0 }))
      setDownloadProgress({ [activeTrack.id]: 0 })
      deleteFile(activeTrack.url)
      navigation.goBack()
      setTimeout(() => {
        clearPlaylist()
        setIsWidgetPlayerHidden(true)
      }, 1000)
    }
  }, [playBackState])

  return (
    <ScrollView showsVerticalScrollIndicator={false} style={[appStyles.flex1, styles.container, style]}>
      <View style={[styles.imageWrap, { width: imageSize, height: imageSize }]}>
        <ImageWithPreview
          emptyImage={require('assets/images/empty-image.jpeg')}
          imageUri={currentLecture.image}
          previewUri={currentLecture.preview}
          style={[styles.image, { width: imageSize, height: imageSize }]}
        />
      </View>
      <View onLayout={onBottomBlockLayout}>
        <View style={appStyles.mainPaddingHorizontal}>
          <View style={styles.titleWrap}>
            <Text
              numberOfLines={3}
              onTextLayout={onTitleLayout}
              style={[appStyles.text26, appStyles.textWeight700, styles.title]}
            >
              {currentLecture.title}
            </Text>
            <Text
              onTextLayout={onTitleHideLayout}
              style={[appStyles.text26, appStyles.textWeight700, styles.title, styles.titleHide]}
            >
              {currentLecture.title}
            </Text>
          </View>

          {currentLecture.description && (
            <View style={styles.descWrap}>
              <Text color="gray" numberOfLines={2} onTextLayout={onDescLayout} style={styles.description}>
                {currentLecture.description}
              </Text>
              <Text color="gray" onTextLayout={onDescHideLayout} style={[styles.description, styles.none]}>
                {currentLecture.description}
              </Text>
              <TouchableOpacity activeOpacity={0.8} onPress={openFullDesc} style={styles.openDescBtn}>
                <Text color="green" style={appStyles.text14}>
                  {showFullDescBtn ? 'полное описание' : ' '}
                </Text>
              </TouchableOpacity>
            </View>
          )}
        </View>
        <AudioPlayer
          disabled={!item || list[item.id]?.audioUpdatedAt !== item?.audioUpdatedAt}
          duration={currentLecture.duration}
          isFirstRender={isFirstRender}
          lectureId={item.id}
          setCurrentPlaylist={setCurrentPlaylist}
        />
      </View>
    </ScrollView>
  )
}
