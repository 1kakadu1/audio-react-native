import { StyleSheet } from 'react-native'

export default StyleSheet.create({
  container: {
    marginBottom: 15,
    marginTop: 40,
    paddingHorizontal: 15,
  },
  imageWrap: {
    alignSelf: 'center',
    marginBottom: 50,
    marginHorizontal: 15,
  },
  image: {
    bottom: 0,
    left: 0,
    position: 'absolute',
    right: 0,
    top: 0,
  },
  title: {
    marginBottom: 9,
    textAlign: 'center',
  },
  description: {
    lineHeight: 19.6,
    textAlign: 'center',
  },
  openDescBtn: {
    alignSelf: 'center',
    marginTop: 2,
  },
  descWrap: {
    height: 60,
  },
  none: { display: 'none' },
  titleHide: { left: 0, opacity: 0, position: 'absolute', top: 0, zIndex: -1 },
  titleWrap: {
    overflow: 'hidden',
    position: 'relative',
  },
})
