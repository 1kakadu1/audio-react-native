import { StyleSheet } from 'react-native'

import { colors } from 'constants/colors'

export default StyleSheet.create({
  container: {
    borderBottomWidth: 1,
    borderColor: colors.darkGray2,
    paddingVertical: 12,
  },
  lastChildContainer: {
    borderBottomWidth: 0,
  },
  content: {
    alignItems: 'center',
    flexDirection: 'row',
    gap: 12,
    height: 55,
  },
  image: {
    backgroundColor: colors.darkGray5,
    borderRadius: 3,
    height: 55,
    width: 55,
  },
  imageBtn: {
    alignItems: 'center',
    bottom: 0,
    justifyContent: 'center',
    left: 0,
    position: 'absolute',
    right: 0,
    top: 0,
    zIndex: 2,
  },
  info: {
    flex: 1,
    gap: 4,
    justifyContent: 'center',
    zIndex: 2,
  },
  controls: {
    width: 24,
  },
  shadowContainer: {
    backgroundColor: colors.darkGray4,
    borderRadius: 3,
    bottom: 0,
    left: 0,
    opacity: 0.2,
    position: 'absolute',
    right: 0,
    top: 0,
    zIndex: 1,
  },
})
