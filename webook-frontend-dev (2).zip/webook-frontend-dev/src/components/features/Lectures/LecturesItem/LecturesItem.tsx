import { FC, useMemo } from 'react'
import { StyleProp, TouchableOpacity, View, ViewStyle } from 'react-native'
import FastImage from 'react-native-fast-image'
import { State } from 'react-native-track-player'

import { useNavigation } from '@react-navigation/native'
import CurrencyIcon from 'assets/icons/currency.svg'
import PauseIcon from 'assets/icons/pause.svg'
import PlayIcon from 'assets/icons/play.svg'
import { appStyles } from 'assets/styles/appStyles'
import { DownloadButton } from 'components/shared/DownloadButton'
import { ProgressCircle } from 'components/shared/ProgressCircle'
import { Text } from 'components/shared/Text'
import { colors } from 'constants/colors'
import { useAudioPlayerContext } from 'contexts/AudioPlayerContext'
import { useDownloadContext } from 'contexts/DownloadContext'
import { convertHttpToHttps, formatSecondsToTime } from 'helpers'
import { usePayToScreen } from 'hooks'
import { Lecture } from 'interfaces/api/catalog.interfaces'
import { Navigation } from 'interfaces/common.interfaces'
import { Routes } from 'routes/routes'
import { useAppSelector } from 'store'
import { isPurchased } from 'utils/lecture'

import styles from './LecturesItem.styles'

interface Props {
  style?: StyleProp<ViewStyle>
  item: Lecture
  isLastChild?: boolean
  lecturesList: Lecture[]
  playBackState?: State
  isActive: boolean
  isPreparing: boolean
  isDownloaded: boolean
  playNewPlaylist: (id: number) => void
}

export const LecturesItem: FC<Props> = ({
  item,
  isLastChild,
  lecturesList,
  style,
  playBackState,
  isActive,
  isPreparing,
  isDownloaded,
  playNewPlaylist,
}) => {
  const { list } = useAppSelector((state) => state.audio)
  const { user, card } = useAppSelector((state) => state.user)
  const { lections } = useAppSelector((store) => store.payments)

  const { downloadQueue, setDownloadQueue } = useDownloadContext()
  const { position, togglePlayback } = useAudioPlayerContext()

  const navigation = useNavigation<Navigation>()
  const { goPayScreen, goCreateCardToPaySubscribe } = usePayToScreen()
  const isPlaying = isActive && playBackState === State.Playing

  const disabled = useMemo(() => {
    if (item.onlyInSubscription !== true) {
      return false
    }

    return !card.data || !user?.activeSub
  }, [card, user])

  const isShowDowloadBtn = useMemo(
    () =>
      (!disabled && lections.items.find((lection) => lection.id === item.id)) ||
      (isPurchased(item) && !disabled) ||
      item?.onlyInSubscription !== true,
    [item.id, disabled, lections, item],
  )
  const isDownloadedLection = list[item.id]?.audioUpdatedAt === item.audioUpdatedAt

  const onOpenLecture = () => navigation.navigate(Routes.Lecture, { lecture: item, lecturesList })
  const onDownload = () => {
    if (disabled) {
      goPayScreen({ goBack: true })
      return
    }
    setDownloadQueue((prev) => [...prev, item])
  }
  const startImagePress = () => {
    if (!isDownloaded) {
      onOpenLecture()
    } else if (isActive) {
      togglePlayback(playBackState)
    } else {
      playNewPlaylist(item.id)
    }
  }
  const onImagePress = () => {
    if (item.onlyInSubscription) {
      if (!isPurchased(item, lections.items)) {
        if (card.data) {
          goPayScreen({ lection: item })
        } else {
          goCreateCardToPaySubscribe()
        }
      } else {
        startImagePress()
      }
    } else {
      startImagePress()
    }
  }

  return (
    <View style={[styles.container, style, isLastChild && styles.lastChildContainer]}>
      <TouchableOpacity activeOpacity={0.8} onPress={onOpenLecture} style={styles.content}>
        <TouchableOpacity activeOpacity={0.8} onPress={onImagePress}>
          <FastImage
            resizeMode={FastImage.resizeMode.cover}
            source={
              item.preview
                ? { uri: convertHttpToHttps(item.preview), priority: FastImage.priority.normal }
                : require('assets/images/empty-image-small.jpeg')
            }
            style={styles.image}
          />
          <View style={styles.imageBtn}>
            {!isPurchased(item, lections.items) || disabled ? (
              <CurrencyIcon color={colors.white} />
            ) : isPreparing ? (
              <ProgressCircle backgroundProgressColor={colors.transparent} progressColor={colors.white} size={16} />
            ) : isPlaying ? (
              <PauseIcon color={colors.white} />
            ) : (
              <PlayIcon color={isDownloadedLection ? colors.white : colors.whiteOpacity} />
            )}
          </View>
          <View style={styles.shadowContainer} />
        </TouchableOpacity>
        <View style={styles.info}>
          <Text numberOfLines={2} style={appStyles.textWeight500}>
            {item.title}
          </Text>
          <Text color="yellow" numberOfLines={1} style={appStyles.text12}>
            {isActive && (
              <>
                {isPlaying ? 'Воспроизводится' : 'Приостановлено'}{' '}
                <Text color="gray" style={appStyles.text12}>
                  {formatSecondsToTime(Math.floor(position), true, true)} /{' '}
                </Text>
              </>
            )}
            <Text color="gray" style={[appStyles.text12, appStyles.textWeight500]}>
              {formatSecondsToTime(item.duration, true, isActive)}
            </Text>
          </Text>
        </View>
        {isShowDowloadBtn ? (
          <DownloadButton
            disabled={!isPurchased(item)}
            isDownloaded={isDownloadedLection}
            mainColor="gray"
            onPress={onDownload}
            progress={downloadQueue.findIndex((elem) => elem.id === item.id) > -1 ? 0 : undefined}
            style={styles.controls}
          />
        ) : null}
      </TouchableOpacity>
    </View>
  )
}
