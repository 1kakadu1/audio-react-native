import { FC, useEffect, useState } from 'react'
import { Dimensions, FlatList, StyleProp, ViewStyle } from 'react-native'

import { NewLectureItem } from 'components/features/Lectures/NewLectureItem'
import { mainIndent } from 'constants/app'
import { Lecture } from 'interfaces/api/catalog.interfaces'

import styles from './NewLecturesList.styles'

interface Props {
  style?: StyleProp<ViewStyle>
  lectures: Lecture[]
}

export const NewLecturesList: FC<Props> = ({ lectures, style }) => {
  const [containerWidth, setContainerWidth] = useState(Dimensions.get('window').width - mainIndent * 2)

  const itemSize = 126
  const itemsGap = 7
  const totalItemsWidth = lectures.length * (itemSize + itemsGap * 2)

  useEffect(() => {
    const subscription = Dimensions.addEventListener('change', ({ window }) => {
      setContainerWidth(window.width - mainIndent * 2)
    })
    return () => subscription?.remove()
  }, [])

  return (
    <FlatList
      contentContainerStyle={[styles.container, style, { gap: itemsGap }]}
      data={lectures}
      horizontal
      keyExtractor={(item) => String(item.id)}
      overScrollMode="never"
      renderItem={({ item, index }) => (
        <NewLectureItem
          lecture={item}
          lecturesList={lectures}
          size={itemSize}
          style={{
            marginLeft: index === 0 ? mainIndent : undefined,
            marginRight: index === lectures.length - 1 ? mainIndent : undefined,
          }}
        />
      )}
      scrollEnabled={totalItemsWidth > containerWidth}
      showsHorizontalScrollIndicator={false}
    />
  )
}
