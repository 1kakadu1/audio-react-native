import { FC, useMemo, useState } from 'react'
import { ImageBackground, View } from 'react-native'
import LinearGradient from 'react-native-linear-gradient'
import Snackbar from 'react-native-snackbar'

import { useNavigation } from '@react-navigation/native'
import { api } from 'api'
import LogoIcon from 'assets/icons/logo.svg'
import { appStyles } from 'assets/styles/appStyles'
import { Button } from 'components/shared/Button'
import { Text } from 'components/shared/Text'
import { appName, legalAssistantURL } from 'constants/app'
import { colors } from 'constants/colors'
import { useCreateCard } from 'hooks/useCreateCard'
import { Navigation } from 'interfaces/common.interfaces'
import { Routes } from 'routes/routes'
import { useAppDispatch } from 'store'
import { getUser } from 'store/user/actions'

import styles from './Purchase.styles'

interface Props {
  price?: string | null
  isSubscription?: boolean
  lectureId?: number
  title?: string
  subscriptionId?: string | number | null
  onSuccess?: () => void
  goBack?: boolean
  isCard?: boolean
}

export const Purchase: FC<Props> = ({
  isSubscription,
  title,
  price,
  subscriptionId,
  lectureId,
  onSuccess,
  goBack = false,
  isCard,
}) => {
  const navigation = useNavigation<Navigation>()
  const dispath = useAppDispatch()
  const [loading, setLoading] = useState(false)
  const { onCreateCard } = useCreateCard({ navigation, offBack: true })
  const typePurchase = useMemo(() => {
    if (isCard) {
      return {
        type: 'CARD',
        title: 'Перед покупкой необходимо добавить карту',
        label: 'Добавить карту',
        price: '',
      }
    }

    if (isSubscription) {
      return {
        type: 'SUBSCRIPTION',
        title: 'Приобретите подписку и возможность покупать и слушать любые лекции приложения',
        label: 'Купить подписку',
        price: '₽ /мес',
      }
    }

    return {
      type: 'LECTIONS',
      title: 'Вы приобретаете лекцию',
      label: 'Купить лекцию',
      price: '₽ единоразово',
    }
  }, [isSubscription, isCard, subscriptionId, lectureId])

  const onPaySubscription = (subscriptionID: string | number) => {
    setLoading(true)
    api.order
      .buySubscribe(subscriptionID, legalAssistantURL)
      .then((res) => {
        if (res.success) {
          Snackbar.show({ text: 'Подписка оформлена', backgroundColor: colors.green })
        } else {
          throw new Error('Ошибка при оплате подписки')
        }

        dispath(getUser())

        if (onSuccess) {
          onSuccess()
        }

        if (goBack) {
          navigation.goBack()
        } else {
          navigation.navigate(Routes.Profile)
        }
      })
      .catch((error) => {
        Snackbar.show({ text: error.toString(), backgroundColor: colors.red })
        navigation.goBack()
      })
      .finally(() => setLoading(false))
  }

  const onPayLecture = (lectureID: string | number) => {
    setLoading(true)
    api.order
      .buyLection(lectureID, legalAssistantURL)
      .then(() => {
        if (onSuccess) {
          onSuccess()
        }
        navigation.goBack()
      })
      .catch((error) => {
        Snackbar.show({ text: error.toString(), backgroundColor: colors.red })
        navigation.navigate(Routes.Profile)
      })
      .finally(() => setLoading(false))
  }
  const onCard = () => {
    onCreateCard(onSuccess)
  }
  const onBuyPress = () => {
    if (typePurchase.type === 'CARD') {
      onCard()
    } else if (subscriptionId) {
      onPaySubscription(subscriptionId)
    } else if (lectureId) {
      onPayLecture(lectureId)
    }
  }

  return (
    <View style={appStyles.flex1}>
      <ImageBackground source={require('assets/images/purchase-background.jpg')} style={styles.image} />
      <LinearGradient
        colors={['rgba(17, 17, 17, 0)', 'rgba(17, 17, 17, 1)']}
        style={[appStyles.flex1, styles.gradient]}
      />
      <View style={[appStyles.flex1, appStyles.mainPaddingBottom, appStyles.mainPaddingHorizontal, styles.content]}>
        <View style={styles.logoWrap}>
          <Text style={[appStyles.textWeight800, appStyles.text26, styles.logoTitle]}>{appName}</Text>
          <LogoIcon style={styles.logoIcon} />
        </View>
        <Text color="gray" style={appStyles.text16}>
          {typePurchase.title}
        </Text>
        {!isSubscription && title && (
          <Text color="yellow" style={appStyles.text16}>
            {title}
          </Text>
        )}

        <Text style={[appStyles.text26, appStyles.textWeight700, styles.price]}>
          {price} {typePurchase.price}
        </Text>

        <Button loading={loading} onPress={onBuyPress} title={typePurchase.label} />
      </View>
    </View>
  )
}
