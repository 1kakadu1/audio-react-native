import { StyleSheet } from 'react-native'

import { colors } from 'constants/colors'

export default StyleSheet.create({
  image: {
    backgroundColor: colors.darkGray4,
    bottom: 0,
    height: '100%',
    left: 0,
    opacity: 0.8,
    position: 'absolute',
    right: 0,
    top: 0,
    width: '100%',
    zIndex: 1,
  },
  gradient: {
    bottom: 0,
    height: 800,
    left: 0,
    position: 'absolute',
    right: 0,
    zIndex: 2,
  },
  content: {
    bottom: 0,
    left: 0,
    marginBottom: 10,
    position: 'absolute',
    right: 0,
    zIndex: 3,
  },
  logoWrap: {
    alignSelf: 'flex-start',
    marginBottom: 25,
  },
  logoTitle: {
    zIndex: 1,
  },
  logoIcon: {
    bottom: 2,
    height: 38,
    position: 'absolute',
    right: -11,
    top: -2,
    width: 38,
  },
  price: {
    marginVertical: 30,
  },
})
