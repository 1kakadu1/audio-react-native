import { StyleSheet } from 'react-native'

import { colors } from 'constants/colors'

export default StyleSheet.create({
  animatedView: {
    zIndex: 2,
  },
  image: {
    backgroundColor: colors.darkGray4,
    height: 360,
    left: 0,
    opacity: 0.8,
    position: 'absolute',
    right: 0,
    top: 0,
    zIndex: 1,
  },
  gradient: {
    height: 800,
    left: 0,
    position: 'absolute',
    right: 0,
    top: 0,
    zIndex: 2,
  },
  titleWrap: {
    position: 'absolute',
  },
  title: {
    bottom: '100%',
  },
  lecturesList: {
    backgroundColor: colors.darkGray4,
  },
})
