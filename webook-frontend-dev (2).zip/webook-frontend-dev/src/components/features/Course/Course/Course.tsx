/* eslint-disable react-native/no-inline-styles */
import { FC, useEffect, useRef, useState } from 'react'
import { LayoutChangeEvent, View } from 'react-native'
import { Gesture, GestureDetector, GestureHandlerRootView } from 'react-native-gesture-handler'
import LinearGradient from 'react-native-linear-gradient'
import Animated, { runOnJS, useAnimatedStyle, useSharedValue } from 'react-native-reanimated'

import { useNetInfo } from '@react-native-community/netinfo'
import { appStyles } from 'assets/styles/appStyles'
import { CourseTop } from 'components/features/Course/CourseTop'
import { LecturesList } from 'components/features/Lectures/LecturesList'
import { ImageWithPreview } from 'components/shared/ImageWithPreview'
import { Loader } from 'components/shared/Loader'
import { Text } from 'components/shared/Text'
import { DisconnectedBlock } from 'components/templates/DisconnectedBlock'
import { useIsReady, useRefetchOnSwipe } from 'hooks'
import { useAppDispatch, useAppSelector } from 'store'
import { getCategory } from 'store/catalog/actions'

import styles from './Course.styles'

interface Props {
  courseId: number
}

export const Course: FC<Props> = ({ courseId }) => {
  const [isBlocked, setIsBlocked] = useState(true)
  const [isBlockedSwipe, setIsBlockedSwipe] = useState(false)
  const [titleHeight, setTitleHeight] = useState(0)

  const { item: course, loading: courseLoading } = useAppSelector((state) => state.catalog.category)

  const dispatch = useAppDispatch()

  const { isConnected } = useNetInfo()
  const isReady = useIsReady()

  const endPosition = 180
  const ref = useRef<View>(null)
  const onTop = useSharedValue(false)
  const position = useSharedValue(endPosition)

  const fetchData = () => {
    if (isConnected) {
      dispatch(getCategory(courseId))
    }
  }

  const handleLayout = (event: LayoutChangeEvent) => {
    const { height } = event.nativeEvent.layout
    setTitleHeight(height)
  }

  const clamp = (value: number, lowerBound: number, upperBound: number) => {
    'worklet'
    return Math.min(Math.max(lowerBound, value), upperBound)
  }

  const panGesture = Gesture.Pan()
    .onUpdate((e) => {
      if (onTop.value && e.translationY > 0 && !isBlockedSwipe) {
        position.value = clamp(titleHeight + e.translationY, titleHeight, endPosition)
        runOnJS(setIsBlockedSwipe)(false)
      }
      if (!onTop.value && e.translationY < 0 && !isBlockedSwipe) {
        position.value = clamp(endPosition + e.translationY, titleHeight, endPosition)
        runOnJS(setIsBlockedSwipe)(false)
      }
    })
    .onEnd((e) => {
      if (position.value > endPosition / 2 && e.translationY > 0) {
        position.value = endPosition
        onTop.value = false
        runOnJS(setIsBlocked)(true)
      } else {
        position.value = titleHeight
        onTop.value = true
        runOnJS(setIsBlocked)(false)
      }
    })

  const viewAnimatedStyle = useAnimatedStyle(() => ({
    transform: [{ translateY: position.value }],
  }))

  const gradientAnimatedStyle = useAnimatedStyle(() => ({
    transform: [{ translateY: position.value - (endPosition - position.value) * (1 / endPosition) }],
  }))

  const { refreshing, onRefresh } = useRefetchOnSwipe(fetchData)

  useEffect(() => {
    fetchData()
  }, [isConnected])

  if (isConnected === false && !course[courseId]) {
    return <DisconnectedBlock />
  }

  if ((courseLoading && !course[courseId]) || !isReady) {
    return <Loader />
  }

  return (
    <GestureHandlerRootView style={appStyles.flex1}>
      {course[courseId] ? (
        <>
          <ImageWithPreview
            imageUri={course[courseId].image}
            previewUri={course[courseId].preview}
            style={styles.image}
          />
          <Animated.View style={[styles.gradient, gradientAnimatedStyle]}>
            <LinearGradient
              colors={['rgba(17, 17, 17, 0)', 'rgba(17, 17, 17, 1)']}
              end={{ x: 0, y: 0.12 }}
              start={{ x: 0, y: 0.04 }}
              style={appStyles.flex1}
            />
          </Animated.View>
          <GestureDetector gesture={panGesture}>
            <Animated.View
              style={[
                appStyles.flex1,
                appStyles.mainMarginTop,
                styles.animatedView,
                course[courseId]?.image ? viewAnimatedStyle : { transform: [{ translateY: titleHeight }] },
              ]}
            >
              <View
                onLayout={handleLayout}
                onTouchStart={() => setIsBlockedSwipe(false)}
                ref={ref}
                style={[appStyles.mainPaddingHorizontal, styles.titleWrap]}
              >
                <Text numberOfLines={3} style={[appStyles.text32, styles.title]}>
                  {course[courseId].title}
                </Text>
              </View>
              <CourseTop course={course[courseId]} onTouchStart={() => setIsBlockedSwipe(false)} />
              <LecturesList
                isAnimated
                isBlocked={isBlocked}
                lectures={course[courseId]?.lections}
                onRefresh={onRefresh}
                refreshing={refreshing}
                setIsBlockedSwipe={setIsBlockedSwipe}
                style={[styles.lecturesList, { paddingBottom: titleHeight }]}
              />
            </Animated.View>
          </GestureDetector>
        </>
      ) : (
        <Text style={[appStyles.mainPaddingHorizontal, appStyles.mainMarginTop, appStyles.text16]}>
          В данном курсе отсутствую материалы
        </Text>
      )}
    </GestureHandlerRootView>
  )
}
