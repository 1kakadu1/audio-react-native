import { StyleSheet } from 'react-native'

import { colors } from 'constants/colors'

export default StyleSheet.create({
  container: {
    flex: 1,
    gap: 10,
  },
  image: {
    backgroundColor: colors.darkGray5,
    borderRadius: 5,
  },
  info: {
    bottom: 0,
    gap: 6,
    justifyContent: 'space-between',
    left: 0,
    padding: 8,
    position: 'absolute',
    right: 0,
    top: 0,
    zIndex: 2,
  },
  icon: {
    position: 'absolute',
    right: 6,
    top: 6,
  },
  shadowContainer: {
    backgroundColor: colors.darkGray4,
    borderRadius: 5,
    bottom: 0,
    left: 0,
    opacity: 0.2,
    position: 'absolute',
    right: 0,
    top: 0,
    zIndex: 1,
  },
})
