import { FC } from 'react'
import { StyleProp, TouchableOpacity, View, ViewStyle } from 'react-native'
import FastImage from 'react-native-fast-image'

import PlayIcon from 'assets/icons/play.svg'
import { appStyles } from 'assets/styles/appStyles'
import { Text } from 'components/shared/Text'
import { colors } from 'constants/colors'
import { wordEndings } from 'constants/dictionaries'
import { convertHttpToHttps, parseWordEnding } from 'helpers'
import { formatSecondsToTime } from 'helpers/date'
import { useIsReady } from 'hooks'
import { CategoryBase } from 'interfaces/api/catalog.interfaces'
import { Navigation } from 'interfaces/common.interfaces'
import { Routes } from 'routes/routes'

import styles from './CourseItem.styles'

interface Props {
  style?: StyleProp<ViewStyle>
  course: CategoryBase
  navigation: Navigation
  size: number
}

export const CourseItem: FC<Props> = ({ course, navigation, style, size }) => {
  const isReady = useIsReady()

  const time = formatSecondsToTime(course?.totalDuration)

  const lecturesCount = parseWordEnding(course.lectionsCount, wordEndings.lecture)

  const onItemPress = () => {
    navigation.navigate(Routes.Course, { courseId: course.id })
  }

  return (
    <TouchableOpacity
      activeOpacity={0.8}
      onPress={onItemPress}
      style={[styles.container, style, { width: size, height: size }]}
    >
      <FastImage
        resizeMode={FastImage.resizeMode.cover}
        source={
          course.preview ? { uri: convertHttpToHttps(course.preview) } : require('assets/images/empty-image.jpeg')
        }
        style={[styles.image, { width: size, height: size }]}
      />
      <View style={styles.shadowContainer} />
      {isReady ? (
        <View style={styles.info}>
          <Text color="lightGray" style={[appStyles.text12, appStyles.textShadow]}>
            {course.lectionsCount} {lecturesCount}
          </Text>
          <View>
            <Text color="lightGray" style={[appStyles.text12, appStyles.textShadow]}>
              {time}
            </Text>
            <Text numberOfLines={4} style={[appStyles.textShadow, appStyles.text14]}>
              {course.title}
            </Text>
          </View>
          <PlayIcon color={colors.white} style={styles.icon} />
        </View>
      ) : (
        <View />
      )}
    </TouchableOpacity>
  )
}
