import { FC } from 'react'

import { useNetInfo } from '@react-native-community/netinfo'
import { RouteProp, useRoute } from '@react-navigation/native'
import { DownloadButton } from 'components/shared/DownloadButton'
import { useDownloadContext } from 'contexts/DownloadContext'
import { RootNavigationParamList } from 'interfaces/common.interfaces'
import { Routes } from 'routes/routes'
import { useAppSelector } from 'store'
import { isPurchased } from 'utils/lecture'

type DetailsScreenRouteProp = RouteProp<RootNavigationParamList, Routes.Course>

export const DownloadCourseButton: FC = () => {
  const { item: course } = useAppSelector((state) => state.catalog.category)
  const { list } = useAppSelector((state) => state.audio)

  const { setDownloadQueue, downloadQueue } = useDownloadContext()

  const { params } = useRoute<DetailsScreenRouteProp>()
  const { isConnected } = useNetInfo()

  const lections = course[params.courseId]?.lections
  const filteredQueue = downloadQueue
    .map((el) => el.id)
    .filter((el) => lections?.findIndex((elem) => elem.id === el) > -1)
  const downloadedLections = lections?.filter((item) => list[item.id]?.audioUpdatedAt === item.audioUpdatedAt)
  const progress = filteredQueue?.length ? (downloadedLections.length / lections.length) * 100 : undefined

  const onDownload = () => {
    if (isConnected !== false) {
      lections?.forEach((item) => {
        if (list[item.id]?.audioUpdatedAt !== item.audioUpdatedAt && isPurchased(item)) {
          setDownloadQueue((prev) => [...prev, item])
        }
      })
    }
  }

  if (!lections?.length || isConnected === false) {
    return null
  }

  return (
    <DownloadButton
      isDownloaded={lections.length === downloadedLections?.length}
      onPress={onDownload}
      progress={progress}
      withProgress
    />
  )
}
