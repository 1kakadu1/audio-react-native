import { FC, useEffect, useState } from 'react'
import { Dimensions, FlatList } from 'react-native'

import { CourseItem } from 'components/features/Course/CourseItem'
import { mainIndent } from 'constants/app'
import { CategoryBase } from 'interfaces/api/catalog.interfaces'
import { Navigation } from 'interfaces/common.interfaces'

interface Props {
  navigation: Navigation
  courses: CategoryBase[]
}

export const CoursesList: FC<Props> = ({ courses, navigation }) => {
  const [containerWidth, setContainerWidth] = useState(Dimensions.get('window').width - mainIndent * 2)

  const shownCourses = courses.filter((item) => !!item.totalDuration)
  const itemSize = 126
  const itemsGap = 7
  const totalItemsWidth = shownCourses.length * (itemSize + itemsGap * 2)

  useEffect(() => {
    const subscription = Dimensions.addEventListener('change', ({ window }) => {
      setContainerWidth(window.width - mainIndent * 2)
    })
    return () => subscription?.remove()
  }, [])

  return (
    <FlatList
      contentContainerStyle={{ gap: itemsGap }}
      data={shownCourses}
      horizontal
      keyExtractor={(item) => String(item.id)}
      overScrollMode="never"
      renderItem={({ item, index }) => (
        <CourseItem
          course={item}
          navigation={navigation}
          size={itemSize}
          style={{
            marginLeft: index === 0 ? mainIndent : undefined,
            marginRight: index === shownCourses.length - 1 ? mainIndent : undefined,
          }}
        />
      )}
      scrollEnabled={totalItemsWidth > containerWidth}
      showsHorizontalScrollIndicator={false}
    />
  )
}
