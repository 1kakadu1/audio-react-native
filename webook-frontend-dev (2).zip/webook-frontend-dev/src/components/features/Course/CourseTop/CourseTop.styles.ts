import { StyleSheet } from 'react-native'

export default StyleSheet.create({
  container: {
    marginBottom: 10,
    paddingTop: 6,
  },
  info: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 12,
  },
  infoContent: {
    alignItems: 'center',
    flexDirection: 'row',
    marginBottom: 6,
  },
  counter: {
    marginRight: 4,
  },
  description: {
    marginBottom: 30,
  },
})
