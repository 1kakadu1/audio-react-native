import { FC } from 'react'
import { StyleProp, View, ViewStyle } from 'react-native'

import { appStyles } from 'assets/styles/appStyles'
import { Text } from 'components/shared/Text'
import { wordEndings } from 'constants/dictionaries'
import { parseWordEnding } from 'helpers'
import { formatSecondsToTimeWithTitles } from 'helpers/date'
import { Category } from 'interfaces/api/catalog.interfaces'

import styles from './CourseTop.styles'

interface Props {
  style?: StyleProp<ViewStyle>
  course: Category
  onTouchStart?: VoidFunction
}

export const CourseTop: FC<Props> = ({ course, style, onTouchStart }) => {
  const { time, timeTitle } = formatSecondsToTimeWithTitles(course.totalDuration)

  const materialsCount = parseWordEnding(course.lections.length, wordEndings.material)

  return (
    <View onTouchStart={onTouchStart} style={[appStyles.mainPaddingHorizontal, styles.container, style]}>
      <View style={styles.info}>
        <View style={styles.infoContent}>
          <Text style={[appStyles.text18, appStyles.textWeight500, styles.counter]}>{time} </Text>
          <Text style={appStyles.textWeight500}>{timeTitle}</Text>
        </View>
      </View>
      {!!course.description && (
        <Text color="gray" numberOfLines={10} style={styles.description}>
          {course.description}
        </Text>
      )}
      <View>
        <Text style={appStyles.text22}>
          {course.lections.length || 0} {materialsCount}
        </Text>
      </View>
    </View>
  )
}
