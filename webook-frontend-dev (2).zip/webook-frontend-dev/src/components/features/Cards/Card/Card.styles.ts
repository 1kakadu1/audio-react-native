import { StyleSheet } from 'react-native'

import { colors } from 'constants/colors'

export default StyleSheet.create({
  container: {
    borderColor: colors.white,
    borderRadius: 5,
    borderWidth: 1,
    height: 82,
    justifyContent: 'space-between',
    padding: 10,
    width: 134,
  },
  cardType: {
    textTransform: 'uppercase',
  },
})
