import { FC } from 'react'
import { View } from 'react-native'

import { appStyles } from 'assets/styles/appStyles'
import { Text } from 'components/shared/Text'
import { Card as CardInterface } from 'interfaces/api/profile.interfaces'

import styles from './Card.styles'

interface Props {
  card: CardInterface
}

export const Card: FC<Props> = ({ card }) => (
  <View style={styles.container}>
    <Text style={appStyles.text16}>*{card.cardNumber}</Text>
    <Text style={[appStyles.text16, styles.cardType]}>{card.cardType}</Text>
  </View>
)
