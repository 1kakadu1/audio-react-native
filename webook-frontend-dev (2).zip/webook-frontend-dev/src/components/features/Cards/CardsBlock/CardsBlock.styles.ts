import { StyleSheet } from 'react-native'

export default StyleSheet.create({
  cards: {
    flexDirection: 'row',
    gap: 4,
    marginTop: 10,
  },
  deleteBtn: {
    borderRadius: 5,
  },
})
