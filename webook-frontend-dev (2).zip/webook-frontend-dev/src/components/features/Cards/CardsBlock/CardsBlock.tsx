import { FC, useState } from 'react'
import { StyleProp, View, ViewStyle } from 'react-native'

import { useNavigation } from '@react-navigation/native'
import DeleteIcon from 'assets/icons/delete.svg'
import PlusIcon from 'assets/icons/plus.svg'
import { Card } from 'components/features/Cards/Card/Card'
import { Button } from 'components/shared/Button'
import { ConfirmModal } from 'components/shared/ConfirmModal'
import { colors } from 'constants/colors'
import { useCreateCard } from 'hooks/useCreateCard'
import { Navigation } from 'interfaces/common.interfaces'
import { useAppDispatch, useAppSelector } from 'store'
import { deleteCardUser } from 'store/user/actions'

import styles from './CardsBlock.styles'

interface Props {
  style?: StyleProp<ViewStyle>
}

export const CardsBlock: FC<Props> = ({ style }) => {
  const [addCardModalVisible, setAddCardModalVisible] = useState(false)
  const [removeCardModalVisible, setRemoveCardModalVisible] = useState(false)
  const { card } = useAppSelector((store) => store.user)
  const dispath = useAppDispatch()
  const navigation = useNavigation<Navigation>()
  const { onCreateCard } = useCreateCard({ navigation })

  const onConfirmAdd = () => {
    setAddCardModalVisible(false)
    onCreateCard()
  }

  const onConfirmRemove = () => {
    dispath(deleteCardUser())
    setRemoveCardModalVisible(false)
  }

  return (
    <View style={style}>
      {card.data ? (
        <View style={styles.cards}>
          <Card card={{ cardType: 'МИР', cardNumber: card.data.identifier.slice(-4) }} />
          <Button
            dangerBordered
            icon={<DeleteIcon color={colors.red} />}
            onPress={() => setRemoveCardModalVisible(true)}
            style={styles.deleteBtn}
          />
        </View>
      ) : (
        <Button
          bordered
          icon={<PlusIcon color={colors.yellow} />}
          onPress={() => setAddCardModalVisible(true)}
          title="Добавить карту"
        />
      )}
      <ConfirmModal
        confirmText="Добавить карту"
        loading={false}
        modalVisible={addCardModalVisible}
        onConfirmPress={onConfirmAdd}
        setModalVisible={setAddCardModalVisible}
        subtitle="С вашей карты мы спишем и вернем 1 р."
        title="Для автоматического продления подписки необходимо привязать карту к аккаунту"
      />
      <ConfirmModal
        cancelText="Оставить карту"
        confirmText="Отвязать карту"
        loading={card.loading}
        modalVisible={removeCardModalVisible}
        onConfirmPress={onConfirmRemove}
        setModalVisible={setRemoveCardModalVisible}
        title="Вы уверены, что хотите отвязать карту?"
      />
    </View>
  )
}
