import { FC } from 'react'
import { ScrollView, View } from 'react-native'

import { appStyles } from 'assets/styles/appStyles'
import { RegisterForm } from 'components/features/Login/RegisterForm'
import { Text } from 'components/shared/Text'

import styles from './RegisterTop.styles'

export const RegisterTop: FC = () => (
  <ScrollView keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false} style={styles.scrollView}>
    <View style={[appStyles.flex1, appStyles.mainPaddingBottom]}>
      <Text style={[appStyles.text35, styles.title]}>Создание аккаунта</Text>
      <Text style={[appStyles.text16, styles.text]}>
        Чтобы завершить регистрацию заполните, пожалуйста, данные о себе
      </Text>
      <RegisterForm />
    </View>
  </ScrollView>
)
