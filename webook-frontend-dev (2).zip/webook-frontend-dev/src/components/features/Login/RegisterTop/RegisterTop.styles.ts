import { StyleSheet } from 'react-native'

export default StyleSheet.create({
  scrollView: {
    marginBottom: 70,
  },
  title: {
    marginBottom: 24,
  },
  text: {
    marginBottom: 28,
  },
})
