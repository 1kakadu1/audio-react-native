import { FC } from 'react'
import { View } from 'react-native'

import { LoginPrivacyInfo } from 'components/features/Login/LoginPrivacyInfo'
import { Button } from 'components/shared/Button'
import { useAppSelector } from 'store'

import styles from './LoginBottom.styles'

interface Props {
  disabledContinue?: boolean
  onHandleContinue?: VoidFunction
}

export const LoginBottom: FC<Props> = ({ disabledContinue, onHandleContinue }) => {
  const { loading } = useAppSelector((state) => state.auth.sendPhone)

  return (
    <View style={styles.container}>
      <LoginPrivacyInfo />
      <Button
        disabled={disabledContinue}
        loading={loading}
        onPress={onHandleContinue}
        style={styles.btn}
        title="Продолжить"
      />
    </View>
  )
}
