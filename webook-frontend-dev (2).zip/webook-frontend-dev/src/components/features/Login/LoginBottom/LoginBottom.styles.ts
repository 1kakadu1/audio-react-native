import { StyleSheet } from 'react-native'

import { mainIndent } from 'constants/app'

export default StyleSheet.create({
  container: {
    bottom: 24,
    left: mainIndent,
    position: 'absolute',
    right: mainIndent,
  },
  btn: {
    marginTop: 16,
  },
})
