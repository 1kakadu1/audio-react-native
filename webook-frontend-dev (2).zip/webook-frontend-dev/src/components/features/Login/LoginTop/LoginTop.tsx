import { FC } from 'react'
import { ScrollView } from 'react-native'

import { appStyles } from 'assets/styles/appStyles'
import { PhoneInput } from 'components/shared/PhoneInput'
import { Text } from 'components/shared/Text'
import { useAppDispatch, useAppSelector } from 'store'
import { clearSendPhoneValidationError } from 'store/auth/actions'

import styles from './LoginTop.styles'

interface Props {
  setPhone: (value: string) => void
}

export const LoginTop: FC<Props> = ({ setPhone }) => {
  const { validation } = useAppSelector((state) => state.auth.sendPhone)

  const dispatch = useAppDispatch()

  return (
    <ScrollView
      keyboardShouldPersistTaps="handled"
      showsVerticalScrollIndicator={false}
      style={[appStyles.flex1, styles.container]}
    >
      <Text style={[appStyles.text35, styles.title]}>Войти</Text>
      <Text style={[appStyles.text16, styles.info]}>
        Войдите в аккаунт для получения доступа ко всем функциям приложения
      </Text>
      <PhoneInput
        clearError={() => dispatch(clearSendPhoneValidationError())}
        error={validation?.phone}
        setPhone={setPhone}
      />
    </ScrollView>
  )
}
