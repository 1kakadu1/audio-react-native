import { StyleSheet } from 'react-native'

export default StyleSheet.create({
  container: {
    marginBottom: 142,
  },
  title: {
    marginBottom: 24,
  },
  info: {
    marginBottom: 28,
  },
})
