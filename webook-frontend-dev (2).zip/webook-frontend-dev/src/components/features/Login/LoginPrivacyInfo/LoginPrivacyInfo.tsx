import { FC } from 'react'

import { useNavigation } from '@react-navigation/native'
import { appStyles } from 'assets/styles/appStyles'
import { Text } from 'components/shared/Text'
import { colors } from 'constants/colors'
import { staticPages } from 'constants/staticPages'
import { Navigation } from 'interfaces/common.interfaces'
import { Routes } from 'routes/routes'

import styles from './LoginPrivacyInfo.styles'

export const LoginPrivacyInfo: FC = () => {
  const navigation = useNavigation<Navigation>()

  const navigateToUserAgreement = () => {
    navigation.navigate(Routes.Static, { slug: staticPages.userAgreement, isPublic: true })
  }

  const navigateToPrivacyPolicy = () => {
    navigation.navigate(Routes.Static, { slug: staticPages.privacyPolicy, isPublic: true })
  }

  return (
    <Text color="gray" style={[styles.text, appStyles.textWeight500]}>
      Нажимая на кнопку, вы соглашаетесь с{' '}
      <Text
        onPress={navigateToUserAgreement}
        onPressStyle={{ color: colors.lightGray }}
        style={[styles.text, appStyles.textWeight500]}
      >
        Пользовательским соглашением
      </Text>
      &nbsp;и&nbsp;
      <Text
        onPress={navigateToPrivacyPolicy}
        onPressStyle={{ color: colors.lightGray }}
        style={[styles.text, appStyles.textWeight500]}
      >
        Политикой конфиденциальности
      </Text>
    </Text>
  )
}
