import { StyleSheet } from 'react-native'

export default StyleSheet.create({
  text: {
    lineHeight: 19.6,
  },
})
