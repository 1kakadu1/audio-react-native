import { FC, useState } from 'react'
import { StyleProp, View, ViewStyle } from 'react-native'

import { appStyles } from 'assets/styles/appStyles'
import { Text } from 'components/shared/Text'
import { TextInput } from 'components/shared/TextInput'
import { OriginalErrorMessages } from 'constants/actionMessages'
import { parsePhone } from 'helpers'
import { useTimer } from 'hooks'

import styles from './ConfirmPhoneTop.styles'

interface Props {
  style?: StyleProp<ViewStyle>
  error?: string | null
  phone: string
  onSendPhone: VoidFunction
  onHandleChange: VoidFunction
  onChangeCode: (code: string) => void
}

export const ConfirmPhoneTop: FC<Props> = ({ error, phone, style, onChangeCode, onHandleChange, onSendPhone }) => {
  const [isPhoneSended, setIsPhoneSended] = useState(true)

  const { isTimerOver, secondsLeft } = useTimer(59, isPhoneSended, setIsPhoneSended)

  const onRepeatPhoneSend = () => {
    onSendPhone()
    setIsPhoneSended(true)
  }

  return (
    <View style={style}>
      <Text style={[appStyles.text35, styles.title]}>Подтверждение номера</Text>
      <Text style={styles.info}>
        <Text style={appStyles.text16}>Введите код который мы отправили на номер {parsePhone(phone)} </Text>
        <Text color="darkGray" onPress={onHandleChange} style={appStyles.text16}>
          Изменить
        </Text>
      </Text>
      <TextInput
        error={error === OriginalErrorMessages.NotVerifiedStatus ? null : error}
        keyboardType="numeric"
        maxLength={4}
        onChangeText={onChangeCode}
        placeholder="Код из СМС"
      />
      <View style={styles.sendInfo}>
        {isPhoneSended && !isTimerOver && (
          <Text>
            <Text style={appStyles.text16}>Не пришел код? Отправить повторно код через </Text>
            <Text style={appStyles.text16}>{secondsLeft}</Text>
          </Text>
        )}
        {isTimerOver && (
          <Text color="darkGray" onPress={onRepeatPhoneSend} style={appStyles.text16}>
            Отправить повторно код
          </Text>
        )}
      </View>
    </View>
  )
}
