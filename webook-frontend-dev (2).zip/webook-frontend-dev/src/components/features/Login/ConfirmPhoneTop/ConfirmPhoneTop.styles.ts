import { StyleSheet } from 'react-native'

export default StyleSheet.create({
  title: {
    marginBottom: 24,
  },
  info: {
    marginBottom: 28,
  },
  sendInfo: {
    marginTop: 24,
  },
})
