import { FC, useEffect, useState } from 'react'

import { Button } from 'components/shared/Button'

import styles from './LoginButton.styles'

interface Props {
  title: string
  disabled?: boolean
  loading?: boolean
  error?: boolean
  onPress?: VoidFunction
}

export const LoginButton: FC<Props> = ({ disabled, loading, title, error, onPress }) => {
  const [loadingInternal, setLoadingInternal] = useState(false)

  useEffect(() => {
    if (loading) {
      setLoadingInternal(true)
    } else {
      setTimeout(() => {
        setLoadingInternal(false)
      }, 500)
    }
  }, [loading])

  useEffect(() => {
    if (error) {
      setLoadingInternal(false)
    }
  }, [error])

  return <Button disabled={disabled} loading={loadingInternal} onPress={onPress} style={styles.btn} title={title} />
}
