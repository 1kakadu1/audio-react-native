import { StyleSheet } from 'react-native'

import { mainIndent } from 'constants/app'

export default StyleSheet.create({
  btn: {
    bottom: 24,
    left: mainIndent,
    position: 'absolute',
    right: mainIndent,
  },
})
