import { FC, useEffect } from 'react'
import { Controller, useFormContext } from 'react-hook-form'
import { View } from 'react-native'

import { TextInput } from 'components/shared/TextInput'
import { RegisterData } from 'interfaces/api/auth.interfaces'
import { useAppSelector } from 'store'

import styles from './RegisterForm.styles'

export const RegisterForm: FC = () => {
  const { validation } = useAppSelector((state) => state.auth)

  const { control, clearErrors, setError } = useFormContext<RegisterData>()

  useEffect(() => {
    if (validation) {
      setError('phone', { message: validation?.phone })
      setError('name', { message: validation?.name })
      setError('email', { message: validation?.email })
    }
  }, [validation])

  return (
    <View style={styles.container}>
      <Controller
        control={control}
        name="name"
        render={({ field, fieldState: { error } }) => (
          <TextInput
            clearError={() => clearErrors('name')}
            error={error?.message}
            onChangeText={field.onChange}
            placeholder="ФИО"
          />
        )}
      />
      <Controller
        control={control}
        name="email"
        render={({ field, fieldState: { error } }) => (
          <TextInput
            clearError={() => clearErrors('email')}
            error={error?.message}
            onChangeText={field.onChange}
            placeholder="Email"
          />
        )}
      />
      <Controller
        control={control}
        name="registerNumber"
        render={({ field, fieldState: { error } }) => (
          <TextInput
            clearError={() => clearErrors('registerNumber')}
            error={error?.message}
            onChangeText={field.onChange}
            placeholder="Регистрационный номер"
          />
        )}
      />
    </View>
  )
}
