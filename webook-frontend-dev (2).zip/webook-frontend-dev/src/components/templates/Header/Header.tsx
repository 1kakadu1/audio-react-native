import { FC, ReactNode } from 'react'
import { StyleProp, TouchableOpacity, View, ViewStyle } from 'react-native'

import { BottomTabHeaderProps } from '@react-navigation/bottom-tabs'
import { NativeStackHeaderProps } from '@react-navigation/native-stack'
import ArrowIcon from 'assets/icons/arrow-left.svg'
import LogoIcon from 'assets/icons/logo.svg'
import PhoneIcon from 'assets/icons/phone.svg'
import { appStyles } from 'assets/styles/appStyles'
import { Text } from 'components/shared/Text'
import { appName } from 'constants/app'
import { colors } from 'constants/colors'
import { Routes } from 'routes/routes'

import styles from './Header.styles'

interface Props {
  style?: StyleProp<ViewStyle>
  isTitleHidden?: boolean
  isGoBackHidden?: boolean
  isGoAssistance?: boolean
  rightButton?: ReactNode
  headerProps: NativeStackHeaderProps | BottomTabHeaderProps
}

export const Header: FC<Props> = ({
  isGoBackHidden,
  isGoAssistance,
  isTitleHidden,
  style,
  rightButton,
  headerProps,
}) => {
  const onGoBack = () => {
    if (!isGoBackHidden) {
      headerProps.navigation.goBack()
    }
  }

  const onLegalAssistanceScreen = () => {
    headerProps.navigation.navigate(Routes.LegalAssistance)
  }

  const isLectureScreen = headerProps.route.name === Routes.Lecture

  const title = isLectureScreen ? 'сейчас играет' : appName

  return (
    <View style={[appStyles.flex1, styles.container, style]}>
      <TouchableOpacity activeOpacity={0.8} hitSlop={20} onPress={onGoBack} style={styles.btn}>
        {!isGoBackHidden && <ArrowIcon color={colors.white} />}
      </TouchableOpacity>
      {!isTitleHidden && (
        <View>
          <Text
            style={[
              appStyles.textWeight800,
              appStyles.text26,
              isLectureScreen && appStyles.text14,
              isLectureScreen && appStyles.textWeight500,
              styles.title,
            ]}
          >
            {title}
          </Text>
          {!isLectureScreen && (
            <View style={styles.logo}>
              <LogoIcon />
            </View>
          )}
        </View>
      )}
      <View style={styles.btn}>
        {isGoAssistance && (
          <TouchableOpacity activeOpacity={0.8} hitSlop={20} onPress={onLegalAssistanceScreen} style={styles.btn}>
            <PhoneIcon color={colors.yellow} />
          </TouchableOpacity>
        )}
        {rightButton}
      </View>
    </View>
  )
}
