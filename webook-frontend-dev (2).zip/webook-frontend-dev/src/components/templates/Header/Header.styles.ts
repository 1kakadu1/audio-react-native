import { StyleSheet } from 'react-native'

import { mainIndent } from 'constants/app'

export default StyleSheet.create({
  container: {
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginHorizontal: mainIndent,
    marginTop: 56,
  },
  btn: {
    height: 23,
    width: 23,
  },
  title: {
    zIndex: 1,
  },
  logo: {
    bottom: 2,
    height: 38,
    position: 'absolute',
    right: -11,
    top: -2,
    width: 38,
  },
})
