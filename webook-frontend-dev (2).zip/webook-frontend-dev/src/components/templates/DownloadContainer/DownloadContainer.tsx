import { FC, PropsWithChildren, useEffect } from 'react'

import { useDownloadContext } from 'contexts/DownloadContext'
import { useDownloadAudio } from 'hooks'

export const DownloadContainer: FC<PropsWithChildren> = ({ children }) => {
  const { downloadProgress, downloadQueue } = useDownloadContext()

  const { download } = useDownloadAudio()

  useEffect(() => {
    if (downloadQueue.length && !downloadProgress[downloadQueue[0].id]) {
      setTimeout(() => download(downloadQueue[0]))
    }
  }, [downloadQueue.length])

  return <>{children}</>
}
