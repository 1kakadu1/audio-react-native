import { FC } from 'react'

import { createNativeStackNavigator } from '@react-navigation/native-stack'
import { DownloadLectureButton } from 'components/features/Lectures/DownloadLectureButton'
import { Header } from 'components/templates/Header'
import { RootNavigationParamList } from 'interfaces/common.interfaces'
import { Routes } from 'routes/routes'
import CardPurchaseScreen from 'screens/CardPurchaseScreen'
import LectureDescScreen from 'screens/LectureDescScreen'
import LectureScreen from 'screens/LectureScreen'
import LecturesScreen from 'screens/LecturesScreen'
import PaymentScreen from 'screens/PaymentScreen'
import PurchaseScreen from 'screens/PurchaseScreen'

const Stack = createNativeStackNavigator<RootNavigationParamList>()

export const LecturesNavigation: FC = () => (
  <Stack.Navigator
    initialRouteName={Routes.Lectures}
    screenOptions={{
      headerTransparent: true,
      headerTitle: '',
      animation: 'none',
    }}
  >
    <Stack.Screen
      component={LecturesScreen}
      name={Routes.Lectures}
      options={{
        header: (props) => <Header headerProps={props} isGoBackHidden />,
      }}
    />
    <Stack.Screen
      component={LectureScreen}
      name={Routes.Lecture}
      options={{
        header: (props) => <Header headerProps={props} rightButton={<DownloadLectureButton />} />,
        animation: 'slide_from_bottom',
      }}
    />
    <Stack.Screen
      component={LectureDescScreen}
      name={Routes.LectureDesc}
      options={{
        header: (props) => <Header headerProps={props} />,
        animation: 'slide_from_bottom',
      }}
    />
    <Stack.Screen
      component={PurchaseScreen}
      name={Routes.Purchase}
      options={{
        header: (props) => <Header headerProps={props} isTitleHidden />,
        animation: 'slide_from_bottom',
      }}
    />
    <Stack.Screen
      component={CardPurchaseScreen}
      name={Routes.CardPurchase}
      options={{
        header: (props) => <Header headerProps={props} isTitleHidden />,
        animation: 'slide_from_bottom',
      }}
    />
    <Stack.Screen
      component={PaymentScreen}
      name={Routes.Payment}
      options={{
        header: (props) => <Header headerProps={props} isGoBackHidden isTitleHidden />,
        animation: 'slide_from_bottom',
      }}
    />
  </Stack.Navigator>
)
