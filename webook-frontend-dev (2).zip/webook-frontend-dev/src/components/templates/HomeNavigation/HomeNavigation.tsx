import { FC } from 'react'

import { createNativeStackNavigator } from '@react-navigation/native-stack'
import { DownloadCourseButton } from 'components/features/Course/DownloadCourseButton'
import { DownloadLectureButton } from 'components/features/Lectures/DownloadLectureButton'
import { Header } from 'components/templates/Header'
import { RootNavigationParamList } from 'interfaces/common.interfaces'
import { Routes } from 'routes/routes'
import CardPurchaseScreen from 'screens/CardPurchaseScreen'
import CategoryScreen from 'screens/CategoryScreen'
import CourseScreen from 'screens/CourseScreen'
import HomeScreen from 'screens/HomeScreen'
import LectureDescScreen from 'screens/LectureDescScreen'
import LectureScreen from 'screens/LectureScreen'
import { LegalAssistanceScreen } from 'screens/LegalAssistanceScreen'
import PaymentScreen from 'screens/PaymentScreen'
import PurchaseScreen from 'screens/PurchaseScreen'
import StaticScreen from 'screens/StaticScreen'

const Stack = createNativeStackNavigator<RootNavigationParamList>()

export const HomeNavigation: FC = () => (
  <Stack.Navigator
    initialRouteName={Routes.Home}
    screenOptions={{
      headerTransparent: true,
      headerTitle: '',
      animation: 'none',
    }}
  >
    <Stack.Screen
      component={HomeScreen}
      name={Routes.Home}
      options={{
        header: (props) => <Header headerProps={props} isGoBackHidden />,
      }}
    />
    <Stack.Screen
      component={CategoryScreen}
      name={Routes.Category}
      options={{
        header: (props) => <Header headerProps={props} />,
      }}
    />
    <Stack.Screen
      component={CourseScreen}
      name={Routes.Course}
      options={{
        header: (props) => <Header headerProps={props} rightButton={<DownloadCourseButton />} />,
      }}
    />
    <Stack.Screen
      component={LectureScreen}
      name={Routes.Lecture}
      options={{
        header: (props) => <Header headerProps={props} rightButton={<DownloadLectureButton />} />,
        animation: 'slide_from_bottom',
      }}
    />
    <Stack.Screen
      component={LectureDescScreen}
      name={Routes.LectureDesc}
      options={{
        header: (props) => <Header headerProps={props} />,
        animation: 'slide_from_bottom',
      }}
    />
    <Stack.Screen
      component={PurchaseScreen}
      name={Routes.Purchase}
      options={{
        header: (props) => <Header headerProps={props} isTitleHidden />,
        animation: 'slide_from_bottom',
      }}
    />
    <Stack.Screen
      component={CardPurchaseScreen}
      name={Routes.CardPurchase}
      options={{
        header: (props) => <Header headerProps={props} isTitleHidden />,
        animation: 'slide_from_bottom',
      }}
    />
    <Stack.Screen
      component={PaymentScreen}
      name={Routes.Payment}
      options={{
        header: (props) => <Header headerProps={props} isGoBackHidden isTitleHidden />,
      }}
    />

    <Stack.Screen
      component={LegalAssistanceScreen}
      name={Routes.LegalAssistance}
      options={{
        header: (props) => <Header headerProps={props} />,
        animation: 'slide_from_bottom',
      }}
    />
    <Stack.Screen
      component={StaticScreen}
      name={Routes.Static}
      options={{
        header: (props) => <Header headerProps={props} />,
        animation: 'slide_from_bottom',
      }}
    />
  </Stack.Navigator>
)
