import { StyleSheet } from 'react-native'

export default StyleSheet.create({
  container: {
    alignItems: 'center',
    gap: 20,
    justifyContent: 'center',
  },
})
