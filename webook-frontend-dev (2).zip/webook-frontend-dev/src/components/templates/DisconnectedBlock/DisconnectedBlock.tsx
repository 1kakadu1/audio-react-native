import { FC } from 'react'
import { View } from 'react-native'

import DisconnectedIcon from 'assets/icons/disconnected.svg'
import { appStyles } from 'assets/styles/appStyles'
import { Text } from 'components/shared/Text'
import { colors } from 'constants/colors'

import styles from './DisconnectedBlock.styles'

export const DisconnectedBlock: FC = () => (
  <View style={[appStyles.flex1, styles.container]}>
    <DisconnectedIcon color={colors.white} height={40} width={40} />
    <Text style={appStyles.text16}>Отсутствует подключение к сети.</Text>
  </View>
)
