import { FC } from 'react'

import { createBottomTabNavigator } from '@react-navigation/bottom-tabs'
import CatalogIcon from 'assets/icons/catalog.svg'
import LecturesIcon from 'assets/icons/lectures.svg'
import MainIcon from 'assets/icons/main.svg'
import ProfileIcon from 'assets/icons/profile.svg'
import { appStyles } from 'assets/styles/appStyles'
import { CatalogNavigation } from 'components/templates/CatalogNavigation/CatalogNavigation'
import { HomeNavigation } from 'components/templates/HomeNavigation/HomeNavigation'
import { LecturesNavigation } from 'components/templates/LecturesNavigation/LecturesNavigation'
import { ProfileNavigation } from 'components/templates/ProfileNavigation/ProfileNavigation'
import { colors } from 'constants/colors'
import { RootNavigationParamList } from 'interfaces/common.interfaces'
import { Routes } from 'routes/routes'

const Tab = createBottomTabNavigator<RootNavigationParamList>()

export const TabNavigation: FC = () => (
  <Tab.Navigator
    initialRouteName={Routes.Home}
    screenOptions={{
      headerTransparent: true,
      tabBarStyle: appStyles.tabBarStyle,
      tabBarActiveTintColor: colors.yellow,
      tabBarLabelStyle: { ...appStyles.textWeight500, ...appStyles.text10 },
    }}
  >
    <Tab.Screen
      component={HomeNavigation}
      name={Routes.Main}
      options={{
        title: 'Главная',
        tabBarIcon: ({ color, size }) => <MainIcon color={color} height={size} width={size} />,
        header: () => null,
      }}
    />
    <Tab.Screen
      component={CatalogNavigation}
      name={Routes.Catalog}
      options={{
        title: 'Каталог',
        headerTitle: '',
        tabBarIcon: ({ color, size }) => <CatalogIcon color={color} height={size} width={size} />,
        header: () => null,
      }}
    />
    <Tab.Screen
      component={LecturesNavigation}
      name={Routes.UserLectures}
      options={{
        title: 'Мои лекции',
        tabBarIcon: ({ color, size }) => <LecturesIcon color={color} height={size} width={size} />,
        header: () => null,
      }}
    />
    <Tab.Screen
      component={ProfileNavigation}
      name={Routes.User}
      options={{
        title: 'Профиль',
        tabBarIcon: ({ color, size }) => <ProfileIcon color={color} height={size} width={size} />,
        header: () => null,
      }}
    />
  </Tab.Navigator>
)
