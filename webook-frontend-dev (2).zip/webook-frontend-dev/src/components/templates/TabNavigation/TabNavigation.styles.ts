import { StyleSheet } from 'react-native'

export default StyleSheet.create({
  profileItem: {
    borderRadius: 50,
    borderWidth: 2,
  },
})
