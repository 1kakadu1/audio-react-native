import { FC } from 'react'

import { createNativeStackNavigator } from '@react-navigation/native-stack'
import { DownloadLectureButton } from 'components/features/Lectures/DownloadLectureButton'
import { Header } from 'components/templates/Header'
import { RootNavigationParamList } from 'interfaces/common.interfaces'
import { Routes } from 'routes/routes'
import LectureDescScreen from 'screens/LectureDescScreen'
import LectureScreen from 'screens/LectureScreen'
import PaymentScreen from 'screens/PaymentScreen'
import ProfileEditScreen from 'screens/ProfileEditScreen'
import ProfileScreen from 'screens/ProfileScreen'
import PurchaseScreen from 'screens/PurchaseScreen'
import StaticScreen from 'screens/StaticScreen'
import StaticsScreen from 'screens/StaticsScreen'

const Stack = createNativeStackNavigator<RootNavigationParamList>()

export const ProfileNavigation: FC = () => (
  <Stack.Navigator
    initialRouteName={Routes.Profile}
    screenOptions={{
      headerTransparent: true,
      headerTitle: '',
      animation: 'none',
    }}
  >
    <Stack.Screen
      component={ProfileScreen}
      name={Routes.Profile}
      options={{
        header: (props) => <Header headerProps={props} isGoBackHidden />,
      }}
    />
    <Stack.Screen
      component={StaticsScreen}
      name={Routes.Statics}
      options={{
        header: (props) => <Header headerProps={props} />,
      }}
    />
    <Stack.Screen
      component={ProfileEditScreen}
      name={Routes.ProfileEdit}
      options={{
        header: (props) => <Header headerProps={props} />,
        animation: 'slide_from_bottom',
      }}
    />
    <Stack.Screen
      component={StaticScreen}
      name={Routes.Static}
      options={{
        header: (props) => <Header headerProps={props} />,
        animation: 'slide_from_bottom',
      }}
    />
    <Stack.Screen
      component={LectureScreen}
      name={Routes.Lecture}
      options={{
        header: (props) => <Header headerProps={props} rightButton={<DownloadLectureButton />} />,
        animation: 'slide_from_bottom',
      }}
    />
    <Stack.Screen
      component={LectureDescScreen}
      name={Routes.LectureDesc}
      options={{
        header: (props) => <Header headerProps={props} />,
        animation: 'slide_from_bottom',
      }}
    />
    <Stack.Screen
      component={PurchaseScreen}
      name={Routes.Purchase}
      options={{
        header: (props) => <Header headerProps={props} isTitleHidden />,
        animation: 'slide_from_bottom',
      }}
    />
    <Stack.Screen
      component={PaymentScreen}
      name={Routes.Payment}
      options={{
        header: (props) => <Header headerProps={props} isGoBackHidden isTitleHidden />,
        animation: 'slide_from_bottom',
      }}
    />
  </Stack.Navigator>
)
