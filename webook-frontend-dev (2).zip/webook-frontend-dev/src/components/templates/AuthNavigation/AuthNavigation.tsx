import { FC } from 'react'

import { createNativeStackNavigator } from '@react-navigation/native-stack'
import { Header } from 'components/templates/Header'
import { RootNavigationParamList } from 'interfaces/common.interfaces'
import { Routes } from 'routes/routes'
import ConfirmPhoneScreen from 'screens/ConfirmPhoneScreen'
import HomeScreen from 'screens/HomeScreen'
import LoginScreen from 'screens/LoginScreen'
import RegisterScreen from 'screens/RegisterScreen'
import StaticScreen from 'screens/StaticScreen'

const Stack = createNativeStackNavigator<RootNavigationParamList>()

export const AuthNavigation: FC = () => (
  <Stack.Navigator
    initialRouteName={Routes.Login}
    screenOptions={{
      headerTransparent: true,
      headerTitle: '',
      animation: 'slide_from_right',
    }}
  >
    <Stack.Screen component={LoginScreen} name={Routes.Login} />
    <Stack.Screen
      component={ConfirmPhoneScreen}
      name={Routes.ConfirmPhone}
      options={{
        header: (props) => <Header headerProps={props} isTitleHidden />,
      }}
    />
    <Stack.Screen
      component={RegisterScreen}
      name={Routes.Register}
      options={{
        header: (props) => <Header headerProps={props} isTitleHidden />,
      }}
    />
    <Stack.Screen
      component={HomeScreen}
      name={Routes.Home}
      options={{
        header: (props) => <Header headerProps={props} isGoBackHidden />,
      }}
    />
    <Stack.Screen
      component={StaticScreen}
      name={Routes.Static}
      options={{
        header: (props) => <Header headerProps={props} />,
        animation: 'slide_from_bottom',
      }}
    />
  </Stack.Navigator>
)
