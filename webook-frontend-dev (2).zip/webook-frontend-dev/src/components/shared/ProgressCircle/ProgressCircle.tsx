import { FC, PropsWithChildren, useEffect } from 'react'
import { StyleProp, View, ViewStyle } from 'react-native'
import Animated, { Easing, useAnimatedStyle, useSharedValue, withRepeat, withTiming } from 'react-native-reanimated'
import Svg, { Circle } from 'react-native-svg'

import { colors } from 'constants/colors'

import styles from './ProgressCircle.styles'

interface Props extends PropsWithChildren {
  style?: StyleProp<ViewStyle>
  progress?: number
  size?: number
  strokeWidth?: number
  backgroundProgressColor?: string
  progressColor?: string
  withProgress?: boolean
  end?: number
}

export const ProgressCircle: FC<Props> = ({
  backgroundProgressColor = colors.darkGray2,
  progressColor = colors.yellow,
  progress = 0,
  size = 24,
  strokeWidth = 3,
  style,
  children,
  withProgress,
  end = 100,
}) => {
  const Wrapper = withProgress ? View : Animated.View

  const rotation = useSharedValue(0)

  const radius = (size - strokeWidth) / 2
  const circumference = radius * 2 * Math.PI
  const strokeDashoffset = circumference - ((withProgress ? progress : 30) / end) * circumference

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ rotate: `${rotation.value}deg` }],
  }))

  useEffect(() => {
    if (!withProgress) {
      rotation.value = withRepeat(
        withTiming(360, {
          duration: 500,
          easing: Easing.linear,
        }),
        -1,
        false,
      )
    }
  }, [rotation])

  return (
    <View style={[withProgress && styles.scaled, style]}>
      <Wrapper style={!withProgress ? animatedStyle : undefined}>
        <Svg height={size} viewBox={`0 0 ${size} ${size}`} width={size}>
          <Circle
            cx={size / 2}
            cy={size / 2}
            fill="none"
            r={radius}
            stroke={backgroundProgressColor}
            strokeWidth={strokeWidth}
          />
          <Circle
            cx={size / 2}
            cy={size / 2}
            fill="none"
            r={radius}
            stroke={progressColor}
            strokeDasharray={`${circumference} ${circumference}`}
            strokeDashoffset={strokeDashoffset}
            strokeWidth={strokeWidth}
            transform={`rotate(-90 ${size / 2} ${size / 2})`}
          />
        </Svg>
      </Wrapper>
      <View
        style={[
          styles.innerContent,
          { top: strokeWidth, left: strokeWidth, bottom: strokeWidth, right: strokeWidth, borderRadius: size / 2 },
        ]}
      >
        {children}
      </View>
    </View>
  )
}
