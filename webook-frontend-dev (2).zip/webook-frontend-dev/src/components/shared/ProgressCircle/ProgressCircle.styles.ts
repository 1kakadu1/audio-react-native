import { StyleSheet } from 'react-native'

export default StyleSheet.create({
  innerContent: {
    alignItems: 'center',
    justifyContent: 'center',
    position: 'absolute',
  },
  scaled: {
    transform: [{ scale: 1.3 }],
  },
})
