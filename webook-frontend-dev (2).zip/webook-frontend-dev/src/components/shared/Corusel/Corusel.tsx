import React from 'react'
import { TouchableOpacity, View } from 'react-native'
import FastImage from 'react-native-fast-image'
import { useSharedValue } from 'react-native-reanimated'
import Carousel, { ICarouselInstance } from 'react-native-reanimated-carousel'

import { appStyles } from 'assets/styles/appStyles'
import { convertHttpToHttps } from 'helpers'
import { IBannerItem } from 'interfaces/api/banner.interfaces'

import styles from './Corusel.styles'

const Item = ({ item }: { item: IBannerItem }) => (
  <FastImage
    resizeMode={FastImage.resizeMode.stretch}
    source={
      item.image
        ? { uri: convertHttpToHttps(item.image), priority: FastImage.priority.normal }
        : require('assets/images/empty-image-small.jpeg')
    }
    style={styles.slide}
  />
)

interface PropsImages extends Omit<IBannerItem, 'lection'> {
  onPress?: () => void
}

export const Corusel = ({ images }: { images: PropsImages[] }) => {
  const scrollOffsetValue = useSharedValue<number>(0)
  const ref = React.useRef<ICarouselInstance>(null)
  const baseOptions = {
    vertical: false,
    width: 291,
    height: 172,
  } as const
  return (
    <View style={[appStyles.mainPaddingHorizontal, styles.container]}>
      <Carousel
        {...baseOptions}
        autoPlay
        autoPlayInterval={4000}
        data={images}
        defaultScrollOffsetValue={scrollOffsetValue}
        loop
        mode="parallax"
        modeConfig={{
          parallaxScrollingScale: 1,
          parallaxScrollingOffset: 196,
          parallaxAdjacentItemScale: 0.6,
        }}
        ref={ref}
        renderItem={({ index, item }) =>
          item.onPress ? (
            <TouchableOpacity key={index} onPress={item.onPress}>
              <Item item={item} key={index} />
            </TouchableOpacity>
          ) : (
            <Item item={item} key={index} />
          )
        }
        style={styles.slider}
        testID="xxx"
      />
    </View>
  )
}
