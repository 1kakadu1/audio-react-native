import { StyleSheet } from 'react-native'

export default StyleSheet.create({
  container: { borderRadius: 18, marginBottom: 25, marginTop: 35, overflow: 'hidden' },
  slide: { borderRadius: 18, height: '100%', marginLeft: 0, overflow: 'hidden', position: 'relative', width: '100%' },
  slider: { alignItems: 'center', borderRadius: 20, justifyContent: 'center', overflow: 'hidden', width: '100%' },
  slideActive: {},
})
