import { FC } from 'react'
import { Text, View } from 'react-native'

import styles from './StatusText.styles'

interface Props {
  isSubscribed: boolean
  title: string
  subtitle?: string
  description?: string
}

export const StatusText: FC<Props> = ({ isSubscribed, title, subtitle, description }) => (
  <View style={styles.container}>
    <View style={styles.statusWrap}>
      <Text style={[styles.title, isSubscribed ? styles.signet : styles.not_signet]}>{title}</Text>
      {subtitle && <Text style={styles.subtitle}>{subtitle}</Text>}
    </View>
    {description && <Text style={styles.description}>{description}</Text>}
  </View>
)
