import { StyleSheet } from 'react-native'

import { colors } from 'constants/colors'

export default StyleSheet.create({
  title: {
    color: colors.gray5,
    fontSize: 16,
    lineHeight: 21.6,
  },
  container: {},
  subtitle: {
    color: colors.gray5,
    fontSize: 16,
    lineHeight: 21.6,
    paddingLeft: 8,
  },
  statusWrap: {
    display: 'flex',
    flexDirection: 'row',
  },
  description: {
    color: colors.gray5,
    fontSize: 16,
    lineHeight: 21.6,
    paddingTop: 2,
  },
  signet: {
    color: colors.yellow,
  },
  not_signet: {
    color: colors.red,
  },
})
