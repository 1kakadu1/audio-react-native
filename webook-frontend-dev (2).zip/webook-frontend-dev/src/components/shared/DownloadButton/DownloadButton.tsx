import { FC } from 'react'
import { StyleProp, TouchableOpacity, ViewStyle } from 'react-native'

import { useNetInfo } from '@react-native-community/netinfo'
import DownloadIcon from 'assets/icons/download-simple.svg'
import DownloadSmallIcon from 'assets/icons/download-small.svg'
import DownloadBigIcon from 'assets/icons/download.svg'
import DownloadedIcon from 'assets/icons/downloaded.svg'
import { ProgressCircle } from 'components/shared/ProgressCircle'
import { colors } from 'constants/colors'

interface Props {
  style?: StyleProp<ViewStyle>
  hitSlop?: number
  mainColor?: keyof typeof colors
  progress?: number
  isDownloaded?: boolean
  withProgress?: boolean
  onPress?: VoidFunction
  disabled?: boolean
}

export const DownloadButton: FC<Props> = ({
  style,
  hitSlop = 20,
  progress,
  mainColor = colors.white,
  isDownloaded,
  withProgress,
  onPress,
  disabled = false,
}) => {
  const { isConnected } = useNetInfo()

  const isDownloading = progress !== undefined && progress >= 0

  const onDownloadPress = () => {
    if (isConnected !== false && !isDownloading) {
      onPress?.()
    }
  }

  if (isDownloaded) {
    return <DownloadedIcon color={colors.yellow} />
  }

  return (
    <TouchableOpacity activeOpacity={0.8} disabled={disabled} hitSlop={hitSlop} onPress={onDownloadPress} style={style}>
      {isDownloading ? (
        <ProgressCircle progress={progress} withProgress={withProgress}>
          <DownloadSmallIcon color={colors.yellow} />
        </ProgressCircle>
      ) : (
        isConnected !== false &&
        (withProgress ? <DownloadBigIcon color={mainColor} /> : <DownloadIcon color={mainColor} />)
      )}
    </TouchableOpacity>
  )
}
