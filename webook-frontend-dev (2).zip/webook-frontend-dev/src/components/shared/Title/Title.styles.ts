import { StyleSheet } from 'react-native'

import { colors } from 'constants/colors'

export default StyleSheet.create({
  title: {
    color: colors.white,
    fontSize: 35,
    lineHeight: 44.4,
  },
  paddingTop: {
    paddingTop: 40,
  },
  paddingBottom: {
    paddingBottom: 30,
  },
})
