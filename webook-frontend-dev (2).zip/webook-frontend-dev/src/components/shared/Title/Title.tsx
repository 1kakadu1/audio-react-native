import { FC } from 'react'
import { Text } from 'react-native'
import { StyleProp, TextStyle } from 'react-native/types'

import { appStyles } from 'assets/styles/appStyles'

import styles from './Title.styles'

interface Props {
  style?: StyleProp<TextStyle>
  title: string
  paddingTop?: boolean
  paddingBottom?: boolean
}

export const Title: FC<Props> = ({ style, title, paddingTop = false, paddingBottom = false }) => (
  <Text
    style={[
      appStyles.textWeight400,
      paddingTop ? styles.paddingTop : undefined,
      paddingBottom ? styles.paddingBottom : undefined,
      style,
      styles.title,
    ]}
  >
    {title}
  </Text>
)
