import { FC, useEffect, useState } from 'react'
import { Platform, TouchableOpacity, View } from 'react-native'
import { State } from 'react-native-track-player'

import Slider from '@react-native-community/slider'
import FastForwardIcon from 'assets/icons/fast-forward.svg'
import PauseIcon from 'assets/icons/pause-big.svg'
import PlayIcon from 'assets/icons/play-big.svg'
import PlayNextIcon from 'assets/icons/play-next.svg'
import PlayPrevIcon from 'assets/icons/play-prev.svg'
import RewindIcon from 'assets/icons/rewind.svg'
import { appStyles } from 'assets/styles/appStyles'
import { Text } from 'components/shared/Text'
import { colors } from 'constants/colors'
import { useAudioPlayerContext } from 'contexts/AudioPlayerContext'
import { formatSecondsToTime } from 'helpers'
import { useAppSelector } from 'store'

import styles from './AudioPlayer.styles'

interface Props {
  disabled?: boolean
  duration?: number
  isFirstRender?: boolean
  lectureId: number
  setCurrentPlaylist: VoidFunction
}

export const AudioPlayer: FC<Props> = ({ disabled, duration, isFirstRender, lectureId, setCurrentPlaylist }) => {
  const [positionInternal, setPositionInternal] = useState(0)
  const [isSliding, setIsSliding] = useState(false)
  const [disabledInternal, setDisabledInternal] = useState<boolean | null>(null)
  const [playBackStateInternal, setPlayBackStateInternal] = useState<State | undefined>(State.Ready)

  const { audioProgress } = useAppSelector((state) => state.audio)

  const {
    forward,
    isPlayerReady,
    onSlidingComplete,
    playBackState,
    position,
    activeTrack,
    isLastTrack,
    isFirstTrack,
    isWidgetPlayerHidden,
    rewind,
    togglePlayback,
    skipToNext,
    skipToPrev,
    setIsWidgetPlayerHidden,
  } = useAudioPlayerContext()

  useEffect(() => {
    if (!isSliding && !isFirstRender) {
      setPositionInternal(position)
    }
  }, [position])

  useEffect(() => {
    if (isFirstRender && audioProgress[lectureId] !== undefined) {
      setPositionInternal(audioProgress[lectureId])
    }
    if (!disabled) {
      setIsWidgetPlayerHidden(true)
    }
  }, [lectureId])

  useEffect(() => {
    if (!isFirstRender && audioProgress[activeTrack?.id] !== undefined) {
      setPositionInternal(audioProgress[activeTrack?.id])
    }
    if (!disabled) {
      setIsWidgetPlayerHidden(true)
    }
  }, [activeTrack?.id])

  useEffect(
    () => () => {
      if (isPlayerReady) {
        setIsWidgetPlayerHidden(false)
      }
    },
    [isPlayerReady],
  )

  useEffect(() => {
    if (disabled || !isPlayerReady) {
      setDisabledInternal(true)
    }
    if (!disabled && disabledInternal === true) {
      setDisabledInternal(false)
    }
  }, [disabled, isPlayerReady])

  useEffect(() => {
    if (playBackState === State.Playing) {
      setPlayBackStateInternal(State.Playing)
    } else if (playBackState === State.Paused || playBackState === State.Ended) {
      setPlayBackStateInternal(State.Paused)
    }
  }, [playBackState])

  useEffect(() => {
    if (
      (playBackState === State.Playing ||
        playBackState === State.Paused ||
        playBackState === State.Ended ||
        playBackState === State.Ready) &&
      disabledInternal === false
    ) {
      setIsWidgetPlayerHidden(true)
    }
  }, [playBackState, disabledInternal])

  useEffect(() => {
    if (disabledInternal === false) {
      setIsWidgetPlayerHidden(true)
      setCurrentPlaylist()
      if (!isPlayerReady) {
        setTimeout(() => togglePlayback(State.Ready), 200)
      }
    }
  }, [disabledInternal])

  return (
    <View style={[appStyles.mainPaddingHorizontal, !isWidgetPlayerHidden && styles.marginBottom]}>
      <View>
        <Slider
          disabled={!!disabledInternal}
          maximumTrackTintColor={colors.gray}
          maximumValue={duration}
          minimumTrackTintColor={colors.white}
          minimumValue={0}
          onSlidingComplete={(value) => {
            setTimeout(() => setIsSliding(false), 900)
            onSlidingComplete(value)
          }}
          onSlidingStart={() => setIsSliding(true)}
          onValueChange={setPositionInternal}
          style={[styles.sliderContainer, Platform.OS === 'android' && styles.sliderContainerAndroid]}
          thumbTintColor={disabledInternal ? colors.gray : colors.white}
          value={disabledInternal ? 0 : positionInternal}
        />
        <View style={styles.timeContainer}>
          <Text color="darkGray3" style={appStyles.textWeight500}>
            {formatSecondsToTime(
              Math.floor(disabledInternal ? 0 : positionInternal > (duration ?? 0) ? duration ?? 0 : positionInternal),
              true,
              true,
            )}
          </Text>
          <Text color="darkGray3" style={appStyles.textWeight500}>
            {formatSecondsToTime(Math.floor(duration ?? 0 - positionInternal), true, true)}
          </Text>
        </View>
      </View>
      <View style={styles.controls}>
        <TouchableOpacity
          activeOpacity={disabledInternal || isFirstTrack ? 1 : 0.6}
          hitSlop={10}
          onPress={() => skipToPrev(disabledInternal || isFirstTrack)}
        >
          <PlayPrevIcon color={disabledInternal || isFirstTrack ? colors.darkGray2 : colors.white} />
        </TouchableOpacity>
        <TouchableOpacity
          activeOpacity={disabledInternal ? 1 : 0.6}
          hitSlop={10}
          onPress={() => rewind(disabledInternal)}
        >
          <RewindIcon color={disabledInternal ? colors.darkGray2 : colors.white} />
        </TouchableOpacity>
        <TouchableOpacity
          activeOpacity={disabledInternal ? 1 : 0.6}
          hitSlop={10}
          onPress={() => togglePlayback(playBackState, disabledInternal)}
        >
          {playBackStateInternal === State.Playing ? (
            <PauseIcon color={disabledInternal ? colors.darkGray2 : colors.white} />
          ) : (
            <PlayIcon color={disabledInternal ? colors.darkGray2 : colors.white} />
          )}
        </TouchableOpacity>
        <TouchableOpacity
          activeOpacity={disabledInternal ? 1 : 0.6}
          hitSlop={10}
          onPress={() => forward(disabledInternal)}
        >
          <FastForwardIcon color={disabledInternal ? colors.darkGray2 : colors.white} />
        </TouchableOpacity>
        <TouchableOpacity
          activeOpacity={disabledInternal || isLastTrack ? 1 : 0.6}
          hitSlop={10}
          onPress={() => skipToNext(disabledInternal || isLastTrack)}
        >
          <PlayNextIcon color={disabledInternal || isLastTrack ? colors.darkGray2 : colors.white} />
        </TouchableOpacity>
      </View>
    </View>
  )
}
