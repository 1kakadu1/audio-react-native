import { StyleSheet } from 'react-native'

export default StyleSheet.create({
  loaderContainer: {
    height: 150,
  },
  loader: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  controls: {
    alignItems: 'center',
    alignSelf: 'center',
    flexDirection: 'row',
    gap: 25,
  },
  sliderContainer: {
    flexDirection: 'row',
    height: 20,
    marginTop: 20,
  },
  sliderContainerAndroid: {
    marginLeft: -15,
    marginRight: -15,
  },
  timeContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  marginBottom: {
    marginBottom: 56,
  },
})
