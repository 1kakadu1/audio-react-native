import { StyleSheet } from 'react-native'

import { colors } from 'constants/colors'

export default StyleSheet.create({
  modal: {
    marginBottom: 30,
    paddingHorizontal: 15,
    width: '100%',
  },
  overlay: {
    backgroundColor: colors.overlay,
    height: '100%',
    justifyContent: 'flex-end',
    width: '100%',
  },
  close: {
    flex: 1,
  },
})
