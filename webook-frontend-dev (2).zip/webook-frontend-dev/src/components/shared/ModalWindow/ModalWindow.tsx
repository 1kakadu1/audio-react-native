import { FC } from 'react'
import { Modal, TouchableOpacity, View } from 'react-native'

import { BlurView } from 'expo-blur'

import styles from './ModalWindow.styles'

interface Props {
  open: boolean
  onClose: () => void
  childen?: JSX.Element
}

export const ModalWindow: FC<Props> = ({ open, onClose, childen }) => (
  <Modal animationType="slide" onRequestClose={onClose} transparent visible={open}>
    <BlurView intensity={40} style={styles.overlay} tint="systemChromeMaterialDark">
      <TouchableOpacity activeOpacity={0} onPress={onClose} style={styles.close} />
      <View style={styles.modal}>{childen}</View>
    </BlurView>
  </Modal>
)
