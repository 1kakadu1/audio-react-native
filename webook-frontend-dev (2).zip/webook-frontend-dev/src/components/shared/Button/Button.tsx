import { FC, ReactNode } from 'react'
import { StyleProp, TouchableOpacity, TouchableOpacityProps, View, ViewStyle } from 'react-native'

import { appStyles } from 'assets/styles/appStyles'
import { Text } from 'components/shared/Text'
import { colors } from 'constants/colors'
import LottieView from 'lottie-react-native'

import styles from './Button.styles'

interface ButtonProps extends TouchableOpacityProps {
  style?: StyleProp<ViewStyle>
  title?: string
  disabled?: boolean
  loading?: boolean
  bordered?: boolean
  icon?: ReactNode
  colorBordered?: keyof typeof colors
  danger?: boolean
  dangerBordered?: boolean
}

export const Button: FC<ButtonProps> = ({
  disabled,
  loading,
  style,
  title,
  bordered,
  danger,
  dangerBordered,
  icon,
  ...props
}) => (
  <TouchableOpacity
    {...props}
    activeOpacity={0.8}
    disabled={disabled}
    style={[
      styles.btn,
      disabled && styles.disabledBtn,
      bordered && styles.borderedBtn,
      danger && styles.dangerBtn,
      dangerBordered && styles.dangerBorderedBtn,
      style,
    ]}
  >
    {title && (
      <Text
        color={dangerBordered ? 'red' : bordered ? 'yellow' : danger ? 'white' : 'black'}
        style={[appStyles.text16, appStyles.textWeight500, loading && styles.titleHidden]}
      >
        {title}
      </Text>
    )}
    {icon && !loading && <View>{icon}</View>}
    {loading && (
      <View style={styles.loaderWrapper}>
        <LottieView autoPlay loop source={require('assets/animations/black-loader.json')} style={styles.loader} />
      </View>
    )}
  </TouchableOpacity>
)
