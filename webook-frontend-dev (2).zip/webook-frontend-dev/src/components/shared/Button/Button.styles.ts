import { StyleSheet } from 'react-native'

import { colors } from 'constants/colors'

export default StyleSheet.create({
  btn: {
    alignItems: 'center',
    backgroundColor: colors.yellow,
    borderRadius: 50,
    flexDirection: 'row',
    gap: 8,
    justifyContent: 'center',
    padding: 15,
  },
  disabledBtn: {
    backgroundColor: colors.gray,
  },
  borderedBtn: {
    backgroundColor: colors.transparent,
    borderColor: colors.yellow,
    borderWidth: 1,
  },
  dangerBorderedBtn: {
    backgroundColor: colors.transparent,
    borderColor: colors.red,
    borderWidth: 1,
  },
  dangerBtn: {
    backgroundColor: colors.red,
  },
  loaderWrapper: {
    alignItems: 'center',
    bottom: 0,
    justifyContent: 'center',
    left: 0,
    position: 'absolute',
    right: 0,
    top: 0,
  },
  loader: {
    height: 40,
    width: 40,
  },
  titleHidden: {
    opacity: 0,
  },
  content: {
    alignItems: 'center',
    flexDirection: 'row',
    gap: 8,
  },
})
