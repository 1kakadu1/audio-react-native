import { FC } from 'react'
import { StyleProp, View, ViewStyle } from 'react-native'

import { appStyles } from 'assets/styles/appStyles'
import LottieView from 'lottie-react-native'

import styles from './Loader.styles'

interface Props {
  style?: StyleProp<ViewStyle>
}

export const Loader: FC<Props> = ({ style }) => (
  <View style={[appStyles.mainMarginTop, styles.container, style]}>
    <LottieView autoPlay loop source={require('assets/animations/white-loader.json')} style={styles.loader} />
  </View>
)
