import { StyleSheet } from 'react-native'

import { colors } from 'constants/colors'

export default StyleSheet.create({
  time: {
    color: colors.white,
    fontSize: 36,
    lineHeight: 43.2,
  },
  description: {
    color: colors.gray5,
    fontSize: 14,
    lineHeight: 16.8,
    maxWidth: 176,
  },
  container: {
    alignItems: 'center',
    flexDirection: 'row',
    gap: 16,
  },
  column: {
    alignItems: 'flex-start',
    flexDirection: 'column',
    gap: 10,
  },
})
