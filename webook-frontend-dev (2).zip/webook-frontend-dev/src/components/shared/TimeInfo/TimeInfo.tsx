import { FC } from 'react'
import { StyleProp, Text, View, ViewStyle } from 'react-native'

import styles from './TimeInfo.styles'

interface Props {
  time: string
  description: string
  style?: StyleProp<ViewStyle>
  column?: boolean
}

export const TimeInfo: FC<Props> = ({ time, description, style, column = false }) => (
  <View style={[styles.container, style, column && styles.column]}>
    <Text style={styles.time}>{time}</Text>
    <Text style={styles.description}>{description}</Text>
  </View>
)
