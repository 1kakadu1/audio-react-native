import { StyleSheet } from 'react-native'

export default StyleSheet.create({
  visible: {
    opacity: 1,
  },
  hidden: {
    opacity: 0,
  },
})
