import { FC, useState } from 'react'
import { ImageRequireSource, StyleProp, View } from 'react-native'
import FastImage, { ImageStyle, ResizeMode } from 'react-native-fast-image'

import { convertHttpToHttps } from 'helpers'

import styles from './ImageWithPreview.styles'

interface Props {
  style?: StyleProp<ImageStyle>
  imageUri?: string | null
  previewUri?: string | null
  resizeMode?: ResizeMode
  emptyImage?: ImageRequireSource
}

export const ImageWithPreview: FC<Props> = ({
  style,
  imageUri,
  previewUri,
  resizeMode = FastImage.resizeMode.cover,
  emptyImage,
}) => {
  const [isLoaded, setIsLoaded] = useState(false)
  const [hasError, setHasError] = useState(false)

  return (
    <View>
      {(!isLoaded || hasError) && (
        <FastImage
          resizeMode={resizeMode}
          source={previewUri ? { uri: convertHttpToHttps(previewUri), priority: FastImage.priority.normal } : undefined}
          style={style}
        />
      )}
      <FastImage
        onError={() => setHasError(true)}
        onLoad={() => setIsLoaded(true)}
        resizeMode={resizeMode}
        source={imageUri ? { uri: convertHttpToHttps(imageUri), priority: FastImage.priority.normal } : emptyImage}
        style={[style, !isLoaded || hasError ? styles.hidden : styles.visible]}
      />
    </View>
  )
}
