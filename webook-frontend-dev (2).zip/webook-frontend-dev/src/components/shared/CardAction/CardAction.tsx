import { useEffect, useRef } from 'react'
import { TouchableOpacity, View } from 'react-native'
import LinearGradient from 'react-native-linear-gradient'
import Animated, { useAnimatedStyle, useSharedValue, withRepeat, withTiming } from 'react-native-reanimated'

import IconPhone from 'assets/icons/phone-round.svg'
import { appStyles } from 'assets/styles/appStyles'
import { Text } from 'components/shared/Text'

import styles from './CardAction.styles'

const OFFSET = 8

export const CardAction = ({ onPress, onPressIcon }: { onPress: () => void; onPressIcon?: () => void }) => {
  const offset = useSharedValue<number>(0)
  const refInterval = useRef<number | undefined>()
  const style = useAnimatedStyle(() => ({
    transform: [{ translateX: offset.value }],
  }))
  const onStartAnimation = () => {
    offset.value = withRepeat(withTiming(OFFSET, { duration: 400 }), 4, true)
    refInterval.current = setInterval(() => {
      offset.value = withRepeat(withTiming(OFFSET, { duration: 400 }), 4, true)
    }, 2800)
  }

  useEffect(() => {
    onStartAnimation()
    return () => {
      if (refInterval.current) {
        clearInterval(refInterval.current)
      }
    }
  }, [])

  return (
    <View style={styles.wrap}>
      <LinearGradient colors={['#272727', '#393621']} style={[appStyles.flex1, styles.overlay]} />
      <View style={styles.content}>
        <Animated.View style={style}>
          <TouchableOpacity onPress={onPressIcon}>
            <IconPhone />
          </TouchableOpacity>
        </Animated.View>
        <View style={styles.info}>
          <Text style={[appStyles.text16, appStyles.textWeight400, styles.lineHeingt]}>
            Срочная{'\n'}юридическая помощь
          </Text>
          <Text color="gray4" style={[appStyles.text12, appStyles.textWeight400]}>
            свяжитесь с нами и получите{'\n'}бесплатную консультацию
          </Text>
        </View>
        <Text color="yellow" onPress={onPress} style={[appStyles.text12, appStyles.textWeight500]}>
          подробнее →
        </Text>
      </View>
    </View>
  )
}
