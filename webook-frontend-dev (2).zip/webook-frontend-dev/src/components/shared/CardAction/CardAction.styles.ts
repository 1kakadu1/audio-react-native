import { StyleSheet } from 'react-native'

export default StyleSheet.create({
  wrap: {
    borderRadius: 5,
    height: 109,
    marginTop: 22,
    overflow: 'hidden',
    padding: 16,
    position: 'relative',
    width: '100%',
  },
  overlay: {
    borderRadius: 5,
    bottom: 0,
    flex: 1,
    left: 0,
    position: 'absolute',
    right: 0,
    top: 0,
    zIndex: 1,
  },
  content: {
    flexDirection: 'row',
    gap: 12,
    justifyContent: 'space-between',
    position: 'relative',
    zIndex: 2,
  },
  info: {
    gap: 7,
  },
  lineHeingt: {
    lineHeight: 19.2,
  },
  lineHeightText: {
    lineHeight: 2.4,
  },
})
