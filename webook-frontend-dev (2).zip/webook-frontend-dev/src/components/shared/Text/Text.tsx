import { FC, useState } from 'react'
import { StyleProp, Text as TextNative, TextProps, TextStyle } from 'react-native'

import { appStyles } from 'assets/styles/appStyles'
import { colors } from 'constants/colors'

interface Props extends TextProps {
  color?: keyof typeof colors
  onPressStyle?: StyleProp<TextStyle>
}

export const Text: FC<Props> = ({ style, children, color = 'white', onPressStyle, ...props }) => {
  const [textPressed, setTextPressed] = useState(false)

  return (
    <TextNative
      onPressIn={() => setTextPressed(true)}
      onPressOut={() => setTextPressed(false)}
      {...props}
      style={[appStyles.textWeight400, appStyles.text16, style, { color: colors[color] }, textPressed && onPressStyle]}
    >
      {children}
    </TextNative>
  )
}
