import { FC } from 'react'
import { StyleProp, ViewStyle } from 'react-native'

import { TextInput } from 'components/shared/TextInput'
import { inputMask } from 'constants/app'

interface Props {
  style?: StyleProp<ViewStyle>
  error?: string | null
  clearError?: VoidFunction
  setPhone: (value: string) => void
}

export const PhoneInput: FC<Props> = ({ error, style, clearError, setPhone }) => {
  const setPhoneInternal = (value?: string) => {
    setPhone(value ? `+7${value}` : '')
  }

  return (
    <TextInput
      clearError={clearError}
      error={error}
      keyboardType="numeric"
      mask={inputMask.phone}
      onChangeText={setPhoneInternal}
      placeholder="Номер телефона"
      style={style}
    />
  )
}
