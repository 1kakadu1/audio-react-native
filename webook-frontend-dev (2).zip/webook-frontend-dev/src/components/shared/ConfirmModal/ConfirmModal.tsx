import { FC } from 'react'
import { StyleProp, ViewStyle } from 'react-native'

import { appStyles } from 'assets/styles/appStyles'
import { Button } from 'components/shared/Button/Button'
import { Modal } from 'components/shared/Modal'
import { Text } from 'components/shared/Text'

import styles from './ConfirmModal.styles'

interface Props {
  style?: StyleProp<ViewStyle>
  modalVisible: boolean
  setModalVisible: (value: boolean) => void
  onConfirmPress: VoidFunction
  confirmText?: string
  cancelText?: string
  title: string
  subtitle?: string
  loading: boolean
}

export const ConfirmModal: FC<Props> = ({
  modalVisible,
  setModalVisible,
  onConfirmPress,
  style,
  confirmText = 'Принять',
  cancelText = 'Отменить',
  title,
  subtitle,
  loading,
}) => (
  <Modal modalVisible={modalVisible} setModalVisible={setModalVisible} style={style}>
    <Text style={[appStyles.text24, styles.title]}>{title}</Text>
    {subtitle && (
      <Text color="gray" style={styles.subtitle}>
        {subtitle}
      </Text>
    )}
    <Button
      dangerBordered
      disabled={loading}
      loading={loading}
      onPress={onConfirmPress}
      style={styles.deleteBtn}
      title={confirmText}
    />
    <Button disabled={loading} onPress={() => setModalVisible(false)} title={cancelText} />
  </Modal>
)
