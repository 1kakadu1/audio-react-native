import { StyleSheet } from 'react-native'

import { colors } from 'constants/colors'

export default StyleSheet.create({
  title: {
    marginBottom: 24,
  },
  subtitle: {
    marginBottom: 24,
  },
  deleteBtn: {
    backgroundColor: colors.black,
    marginBottom: 16,
  },
})
