import { FC, PropsWithChildren } from 'react'
import { Modal as ModalNative, StyleProp, View, ViewStyle } from 'react-native'

import { appStyles } from 'assets/styles/appStyles'

import styles from './Modal.styles'

interface Props extends PropsWithChildren {
  style?: StyleProp<ViewStyle>
  modalVisible: boolean
  setModalVisible: (value: boolean) => void
}

export const Modal: FC<Props> = ({ modalVisible, setModalVisible, style, children }) => (
  <View style={[appStyles.flex1, style]}>
    <ModalNative
      animationType="fade"
      onRequestClose={() => setModalVisible(false)}
      statusBarTranslucent
      transparent
      visible={modalVisible}
    >
      <View
        style={[appStyles.flex1, appStyles.mainPaddingHorizontal, appStyles.mainPaddingBottom, styles.modalContainer]}
      >
        {children}
      </View>
    </ModalNative>
  </View>
)
