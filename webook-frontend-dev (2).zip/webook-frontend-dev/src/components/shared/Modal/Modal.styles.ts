import { StyleSheet } from 'react-native'

import { colors } from 'constants/colors'

export default StyleSheet.create({
  modalContainer: {
    backgroundColor: colors.blackTransparent,
    justifyContent: 'flex-end',
  },
  modalContent: {
    gap: 16,
    width: '100%',
  },
})
