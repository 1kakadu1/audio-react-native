import { FC } from 'react'
import { FlatList, Text, TouchableOpacity, View } from 'react-native'

import { appStyles } from 'assets/styles/appStyles'

import styles from './ScrollListText.style'

interface Props {
  items: { label: string; value: string }[]
  active: string
  onPress?: (value: { label: string; value: string }) => void
}

export const ScrollListText: FC<Props> = ({ items, onPress, active }) =>
  items.length < 5 ? (
    <View style={styles.row}>
      {items.map((item) => (
        <TouchableOpacity key={item.value} onPress={() => onPress && onPress(item)}>
          <Text
            style={[
              styles.text,
              appStyles.text24,
              appStyles.textWeight400,
              active === item.value ? styles.active : undefined,
            ]}
          >
            {item.label}
          </Text>
        </TouchableOpacity>
      ))}
    </View>
  ) : (
    <FlatList
      data={items}
      horizontal
      ItemSeparatorComponent={() => <View style={styles.separator} />}
      keyExtractor={(item) => item.value}
      renderItem={({ item }) => (
        <TouchableOpacity onPress={() => onPress && onPress(item)}>
          <Text
            style={[
              styles.text,
              appStyles.text24,
              appStyles.textWeight400,
              active === item.value ? styles.active : undefined,
            ]}
          >
            {item.label}
          </Text>
        </TouchableOpacity>
      )}
    />
  )
