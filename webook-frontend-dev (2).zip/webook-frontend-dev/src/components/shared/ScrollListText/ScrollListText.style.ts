import { StyleSheet } from 'react-native'

import { colors } from 'constants/colors'

export default StyleSheet.create({
  text: {
    color: colors.gray5,
    fontSize: 16,
    lineHeight: 21.6,
  },
  active: {
    color: colors.white,
  },
  separator: {
    width: 10,
  },
  row: {
    flexDirection: 'row',
    gap: 10,
  },
})
