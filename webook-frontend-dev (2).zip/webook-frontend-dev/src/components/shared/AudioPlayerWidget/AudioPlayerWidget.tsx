import { FC, useEffect, useState } from 'react'
import { TouchableOpacity, View } from 'react-native'
import FastImage from 'react-native-fast-image'
import { State, Track } from 'react-native-track-player'

import { useNavigation } from '@react-navigation/native'
import PauseIcon from 'assets/icons/pause.svg'
import PlayIcon from 'assets/icons/play.svg'
import { appStyles } from 'assets/styles/appStyles'
import { Text } from 'components/shared/Text'
import { colors } from 'constants/colors'
import { convertHttpToHttps, formatSecondsToTime } from 'helpers'
import { Navigation } from 'interfaces/common.interfaces'
import { Routes } from 'routes/routes'
import { useAppSelector } from 'store'

import styles from './AudioPlayerWidget.styles'

interface Props {
  activeTrack?: Track
  position: number
  duration: number
  isWidgetOnBottom: boolean
  playBackState: State | undefined
  clearPlaylist: VoidFunction
  togglePlayback: (playback?: State | undefined, disabled?: boolean) => Promise<void>
  setIsWidgetPlayerHidden: (value: boolean) => void
}

export const AudioPlayerWidget: FC<Props> = ({
  activeTrack,
  position,
  duration,
  playBackState,
  isWidgetOnBottom,
  clearPlaylist,
  togglePlayback,
  setIsWidgetPlayerHidden,
}) => {
  const [currentTrack, setCurrentTrack] = useState<Track | undefined>()

  const { playlist } = useAppSelector((state) => state.audio)

  const navigation = useNavigation<Navigation>()

  const onPress = () => {
    if (activeTrack) {
      setIsWidgetPlayerHidden(true)
      navigation.navigate(Routes.Lecture, {
        lecture: {
          id: activeTrack.id,
          title: activeTrack.title ?? '',
          image: activeTrack.image ?? '',
          preview: activeTrack.preview ?? '',
          description: activeTrack.description,
          duration: activeTrack.duration ?? 0,
          price: activeTrack.price,
          createdAt: activeTrack.createdAt,
          updatedAt: activeTrack.updatedAt,
          audioUpdatedAt: activeTrack.audioUpdatedAt,
          isPublished: false,
          audio: activeTrack.url,
          onlyInSubscription: activeTrack.onlyInSubscription,
        },
        lecturesList: playlist.map((item) => ({
          id: item.id,
          title: item.title ?? '',
          image: item.image ?? '',
          preview: item.preview ?? '',
          description: item.description,
          duration: item.duration ?? 0,
          price: item.price,
          createdAt: item.createdAt,
          updatedAt: item.updatedAt,
          audioUpdatedAt: item.audioUpdatedAt,
          isPublished: false,
          audio: item.url,
          onlyInSubscription: activeTrack.onlyInSubscription,
        })),
      })
    }
  }

  useEffect(() => {
    if (playBackState === State.Playing || playBackState === State.Paused || playBackState === State.Ready) {
      setCurrentTrack(activeTrack)
    }
    if (playBackState === State.Error) {
      setCurrentTrack(undefined)
      clearPlaylist()
    }
  }, [playBackState, activeTrack])

  if (!currentTrack?.id) {
    return null
  }

  return (
    <View style={[styles.container, isWidgetOnBottom && styles.bottomContainer]}>
      <TouchableOpacity activeOpacity={0.8} onPress={onPress} style={styles.pressableContainer}>
        <View style={styles.infoWrap}>
          <View style={[styles.leftBlock, appStyles.flex1]}>
            <FastImage
              resizeMode={FastImage.resizeMode.cover}
              source={
                currentTrack?.preview
                  ? { uri: convertHttpToHttps(currentTrack.preview), priority: FastImage.priority.normal }
                  : require('assets/images/empty-image-small.jpeg')
              }
              style={styles.image}
            />
            <View style={[styles.info, appStyles.flex1]}>
              <Text numberOfLines={1} style={appStyles.textWeight500}>
                {currentTrack?.title}
              </Text>
              <Text color="gray" numberOfLines={1} style={[appStyles.textWeight500, appStyles.text12]}>
                {currentTrack?.courseTitle}
              </Text>
            </View>
          </View>
          <View style={styles.rightBlock}>
            <Text color="gray" style={[appStyles.textWeight500, appStyles.text12]}>
              {formatSecondsToTime(Math.floor(position), true, true)}
            </Text>
            <TouchableOpacity
              activeOpacity={0.8}
              hitSlop={10}
              onPress={() => togglePlayback(playBackState)}
              style={styles.button}
            >
              {playBackState === State.Playing ? (
                <PauseIcon color={colors.white} height={30} width={30} />
              ) : (
                <PlayIcon color={colors.white} height={30} width={30} />
              )}
            </TouchableOpacity>
          </View>
        </View>
        <View style={styles.progressTrack}>
          <View style={[styles.progress, { width: `${(position / duration) * 100}%` }]} />
        </View>
      </TouchableOpacity>
    </View>
  )
}
