import { StyleSheet } from 'react-native'

import { colors } from 'constants/colors'

export default StyleSheet.create({
  container: {
    backgroundColor: colors.darkGray6,
    borderRadius: 5,
    bottom: 88,
    left: 14,
    overflow: 'hidden',
    position: 'absolute',
    right: 14,
    zIndex: 1,
  },
  pressableContainer: {
    backgroundColor: colors.darkGray6,
  },
  bottomContainer: {
    bottom: 14,
  },
  infoWrap: {
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 5,
  },
  info: {
    gap: 3,
  },
  image: {
    backgroundColor: colors.darkGray5,
    borderRadius: 3,
    height: 55,
    marginRight: 10,
    width: 55,
  },
  leftBlock: {
    alignItems: 'center',
    flexDirection: 'row',
  },
  rightBlock: {
    alignItems: 'center',
    flexDirection: 'row',
    marginLeft: 5,
  },
  button: {
    marginLeft: 5,
    marginRight: 4,
  },
  progressTrack: {
    backgroundColor: colors.gray,
    height: 4,
    width: '100%',
  },
  progress: {
    backgroundColor: colors.yellow,
    bottom: 0,
    left: 0,
    position: 'absolute',
    top: 0,
    zIndex: 1,
  },
})
