import { StyleSheet } from 'react-native'

import { colors } from 'constants/colors'

export default StyleSheet.create({
  container: {
    flexDirection: 'row',
    gap: 4,
  },
  card: {
    alignItems: 'center',
    borderColor: colors.white,
    borderRadius: 5,
    borderWidth: 1,
    flexDirection: 'row',
    height: 86,
    justifyContent: 'space-between',
    minWidth: 50,
    padding: 10,
  },
  textWrap: {
    height: '100%',
    justifyContent: 'space-between',
  },
  text: {
    color: colors.white,
  },
  big: {
    width: 134,
  },
  red: {
    borderColor: colors.red,
    justifyContent: 'center',
  },
})
