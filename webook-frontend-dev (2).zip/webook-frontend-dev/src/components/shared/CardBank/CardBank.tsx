import { FC } from 'react'
import { Text, TouchableOpacity, View } from 'react-native'

import DeleteIcon from 'assets/icons/delete.svg'
import PanIcon from 'assets/icons/pan.svg'
import { appStyles } from 'assets/styles/appStyles'

import styles from './CardBank.styles'

interface Props {
  number: number
  onDelete: () => void
  onChange: () => void
}

export const CardBank: FC<Props> = ({ number, onChange, onDelete }) => (
  <View style={styles.container}>
    <TouchableOpacity onPress={onChange} style={[styles.card, styles.big]}>
      <View style={styles.textWrap}>
        <Text style={[styles.text, appStyles.text16, appStyles.textWeight400]}>*{number}</Text>
        <Text style={[styles.text, appStyles.text16, appStyles.textWeight400]}>MIR</Text>
      </View>
      <PanIcon />
    </TouchableOpacity>
    <TouchableOpacity onPress={onDelete} style={[styles.card, styles.red]}>
      <DeleteIcon />
    </TouchableOpacity>
  </View>
)
