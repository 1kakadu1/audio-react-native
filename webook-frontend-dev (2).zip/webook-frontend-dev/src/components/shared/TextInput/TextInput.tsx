import { FC, useEffect, useState } from 'react'
import { StyleProp, TextInputProps, TextStyle, View } from 'react-native'
import TextInputMask from 'react-native-text-input-mask'

import { appStyles } from 'assets/styles/appStyles'
import { Text } from 'components/shared/Text/Text'
import { colors } from 'constants/colors'

import styles from './TextInput.styles'

interface Props extends TextInputProps {
  style?: StyleProp<TextStyle>
  mask?: string
  placeholder?: string
  showLabel?: boolean
  error?: string | string[] | null
  clearError?: VoidFunction
  onChangeText: (value: string) => void
  showLabelAlways?: boolean
}

export const TextInput: FC<Props> = ({
  style,
  mask,
  placeholder,
  showLabel = true,
  error,
  clearError,
  onChangeText,
  showLabelAlways = false,
  ...props
}) => {
  const [isFocused, setIsFocused] = useState(false)
  const [showLabelInternal, setShowLabelInternal] = useState(showLabelAlways)
  const [formattedValue, setFormattedValue] = useState('')

  useEffect(() => {
    if (!showLabelAlways) {
      if (showLabel && (formattedValue?.length || isFocused)) {
        setShowLabelInternal(true)
      } else {
        setShowLabelInternal(false)
      }
    }
  }, [formattedValue, isFocused])

  return (
    <View>
      <TextInputMask
        {...props}
        mask={mask}
        onBlur={() => setIsFocused(!!formattedValue?.length)}
        onChangeText={(formatted, extracted) => {
          setFormattedValue(formatted)
          onChangeText(mask ? extracted ?? '' : formatted)
          clearError?.()
        }}
        onFocus={() => setIsFocused(true)}
        placeholder={showLabelInternal ? '' : placeholder}
        placeholderTextColor={colors.gray}
        style={[appStyles.text16, appStyles.textWeight500, styles.input, style, !!error && styles.errorValue]}
      />
      {showLabelInternal && (
        <Text color="gray" style={styles.label}>
          {placeholder}
        </Text>
      )}
      {!!error?.length && (
        <Text color="red" style={[appStyles.text16, styles.errorText]}>
          {Array.isArray(error) ? error[0] : error}
        </Text>
      )}
    </View>
  )
}
