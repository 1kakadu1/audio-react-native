import { StyleSheet } from 'react-native'

import { colors } from 'constants/colors'

export default StyleSheet.create({
  input: {
    borderBottomColor: colors.gray,
    borderBottomWidth: 1,
    color: colors.white,
    height: 48,
  },
  label: {
    left: 0,
    position: 'absolute',
    top: -10,
  },
  errorValue: {
    color: colors.red,
  },
  errorText: {
    marginTop: 8,
  },
})
