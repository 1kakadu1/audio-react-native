export const staticPages = {
  userAgreement: 'polzovatelskoe-soglasenie',
  privacyPolicy: 'politika-konfidencialnosti',
}
