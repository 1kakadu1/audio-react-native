export const wordEndings: Record<string, string[]> = {
  material: ['материал', 'материала', 'материалов'],
  hour: ['час', 'часа', 'часов'],
  minute: ['минута', 'минуты', 'минут'],
  lecture: ['лекция', 'лекции', 'лекций'],
  course: ['курс', 'курса', 'курсов'],
}
