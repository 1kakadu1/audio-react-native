export const appName = 'webook'

export const inputMask = {
  phone: '+7 ([000]) [000]-[00]-[00]',
}

export const mainIndent = 15

export const legalAssistantURL = 'https://xn----7sbbajdnz8degenc2r.xn--p1ai/contacts'

export const phoneCall = '+79026300098'
