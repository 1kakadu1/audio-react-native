import { useLayoutEffect } from 'react'

import { NativeStackScreenProps } from '@react-navigation/native-stack'
import { appStyles } from 'assets/styles/appStyles'
import { Purchase } from 'components/features/Purchase'
import { useAudioPlayerContext } from 'contexts/AudioPlayerContext'
import { RootNavigationParamList } from 'interfaces/common.interfaces'
import { MainLayout } from 'layouts/MainLayout/MainLayout'
import { Routes } from 'routes/routes'

type PurchaseProps = NativeStackScreenProps<RootNavigationParamList, Routes.Purchase>

const PurchaseScreen = ({ route, navigation }: PurchaseProps) => {
  const { price, isSubscription, lectureId, title, subscriptionId, onSuccess, goBack, isCard } = route.params

  const { setIsWidgetOnBottom } = useAudioPlayerContext()

  useLayoutEffect(() => {
    const parent = navigation.getParent()
    parent?.setOptions({ tabBarStyle: { display: 'none' } })
    setIsWidgetOnBottom(true)
    return () => {
      parent?.setOptions({ tabBarStyle: appStyles.tabBarStyle })
      setIsWidgetOnBottom(false)
    }
  })

  return (
    <MainLayout isFullScreen pageName={route.name}>
      <Purchase
        goBack={goBack}
        isCard={isCard}
        isSubscription={isSubscription}
        lectureId={lectureId}
        onSuccess={onSuccess}
        price={price}
        subscriptionId={subscriptionId}
        title={title}
      />
    </MainLayout>
  )
}

export default PurchaseScreen
