import { NativeStackScreenProps } from '@react-navigation/native-stack'
import { Category } from 'components/features/Category/Category'
import { RootNavigationParamList } from 'interfaces/common.interfaces'
import { MainLayout } from 'layouts/MainLayout/MainLayout'
import { Routes } from 'routes/routes'

export type CategoryProps = NativeStackScreenProps<RootNavigationParamList, Routes.Category>

const CategoryScreen = ({ navigation, route }: CategoryProps) => (
  <MainLayout pageName={route.name}>
    <Category categoryId={route.params?.categoryId} navigation={navigation} />
  </MainLayout>
)

export default CategoryScreen
