import { NativeStackScreenProps } from '@react-navigation/native-stack'
import { LecturesUser } from 'components/features/Lectures/LecturesUser'
import { RootNavigationParamList } from 'interfaces/common.interfaces'
import { MainLayout } from 'layouts/MainLayout/MainLayout'
import { Routes } from 'routes/routes'

type LecturesProps = NativeStackScreenProps<RootNavigationParamList, Routes.Lectures>

const LecturesScreen = ({ route }: LecturesProps) => (
  <MainLayout pageName={route.name}>
    <LecturesUser />
  </MainLayout>
)

export default LecturesScreen
