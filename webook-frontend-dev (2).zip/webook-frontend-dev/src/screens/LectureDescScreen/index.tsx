import { useLayoutEffect } from 'react'
import { ScrollView } from 'react-native'

import { NativeStackScreenProps } from '@react-navigation/native-stack'
import { appStyles } from 'assets/styles/appStyles'
import { LectureDesc } from 'components/features/Lectures/LectureDesc'
import { useAudioPlayerContext } from 'contexts/AudioPlayerContext'
import { RootNavigationParamList } from 'interfaces/common.interfaces'
import { MainLayout } from 'layouts/MainLayout/MainLayout'
import { Routes } from 'routes/routes'

type LectureScreenProps = NativeStackScreenProps<RootNavigationParamList, Routes.LectureDesc>

const LectureDescScreen = ({ route, navigation }: LectureScreenProps) => {
  const { setIsWidgetOnBottom } = useAudioPlayerContext()

  useLayoutEffect(() => {
    const parent = navigation.getParent()
    parent?.setOptions({ tabBarStyle: { display: 'none' } })
    setIsWidgetOnBottom(true)
  })

  return (
    <MainLayout isFullScreen pageName={route.name}>
      <ScrollView showsVerticalScrollIndicator={false} style={[appStyles.flex1, appStyles.mainMarginTop]}>
        <LectureDesc item={route.params.lecture} />
      </ScrollView>
    </MainLayout>
  )
}

export default LectureDescScreen
