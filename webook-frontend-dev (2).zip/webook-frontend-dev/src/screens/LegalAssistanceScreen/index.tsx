import { LegalAssistantContent } from 'components/features/LegalAssistant/LegalAssistantContent'
import { LegalAssistancePreview } from 'components/features/LegalAssistant/LegalAssistantPreview'
import { MainLayout } from 'layouts/MainLayout/MainLayout'

export const LegalAssistanceScreen = () => (
  <MainLayout isFullScreen>
    <LegalAssistancePreview />
    <LegalAssistantContent />
  </MainLayout>
)
