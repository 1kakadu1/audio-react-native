import { useEffect, useState } from 'react'
import { ScrollView } from 'react-native'

import { NativeStackScreenProps } from '@react-navigation/native-stack'
import { appStyles } from 'assets/styles/appStyles'
import { ConfirmPhoneTop } from 'components/features/Login/ConfirmPhoneTop'
import { LoginButton } from 'components/features/Login/LoginButton'
import { OriginalErrorMessages } from 'constants/actionMessages'
import { clearDirectory } from 'helpers'
import { useDevice } from 'hooks'
import { RootNavigationParamList } from 'interfaces/common.interfaces'
import { AuthLayout } from 'layouts/AuthLayout/AuthLayout'
import { Routes } from 'routes/routes'
import { persistor, useAppDispatch, useAppSelector } from 'store'
import { login, sendPhone } from 'store/auth/actions'

type ConfirmPhoneProps = NativeStackScreenProps<RootNavigationParamList, Routes.ConfirmPhone>

const ConfirmPhoneScreen = ({ navigation, route }: ConfirmPhoneProps) => {
  const { phone } = route.params

  const [disabledContinue, setDisabledContinue] = useState(true)
  const [code, setCode] = useState('')

  const { error, loading } = useAppSelector((state) => state.auth)
  const { user } = useAppSelector((state) => state.user)

  const dispatch = useAppDispatch()

  const { deviceId } = useDevice()

  const onSuccess = () => {
    if (user?.phone !== phone) {
      persistor.purge()
      clearDirectory()
    }
  }

  const onHandleContinue = () => {
    dispatch(
      login({
        data: {
          phone,
          code,
          device: deviceId,
        },
        onSuccess,
      }),
    )
  }

  const onSendPhone = () => {
    dispatch(
      sendPhone({
        data: {
          phone,
          device: deviceId,
        },
      }),
    )
  }

  useEffect(() => {
    setDisabledContinue(code.length < 4)
  }, [code])

  useEffect(() => {
    if (error === OriginalErrorMessages.NotVerifiedStatus) {
      navigation.navigate(Routes.Register, { phone, code })
    }
  }, [error])

  return (
    <AuthLayout>
      <ScrollView keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false} style={appStyles.flex1}>
        <ConfirmPhoneTop
          error={error}
          onChangeCode={setCode}
          onHandleChange={navigation.goBack}
          onSendPhone={onSendPhone}
          phone={phone}
        />
      </ScrollView>
      <LoginButton
        disabled={disabledContinue}
        error={!!error}
        loading={loading}
        onPress={onHandleContinue}
        title="Подтвердить и продолжить"
      />
    </AuthLayout>
  )
}

export default ConfirmPhoneScreen
