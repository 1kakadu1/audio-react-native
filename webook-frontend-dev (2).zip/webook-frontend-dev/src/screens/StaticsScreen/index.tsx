import { NativeStackScreenProps } from '@react-navigation/native-stack'
import { StaticList } from 'components/features/Static/StaticList'
import { RootNavigationParamList } from 'interfaces/common.interfaces'
import { MainLayout } from 'layouts/MainLayout/MainLayout'
import { Routes } from 'routes/routes'

type StaticsProps = NativeStackScreenProps<RootNavigationParamList, Routes.Statics>

const StaticScreen = ({ route }: StaticsProps) => (
  <MainLayout pageName={route.name}>
    <StaticList />
  </MainLayout>
)

export default StaticScreen
