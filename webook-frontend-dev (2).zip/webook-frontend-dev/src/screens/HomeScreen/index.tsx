import { useCallback, useEffect } from 'react'
import { RefreshControl, ScrollView, View } from 'react-native'

import { useNetInfo } from '@react-native-community/netinfo'
import { useFocusEffect } from '@react-navigation/native'
import { NativeStackScreenProps } from '@react-navigation/native-stack'
import { appStyles } from 'assets/styles/appStyles'
import { HomeBlock } from 'components/features/Home/HomeBlock'
import { HomeCategories } from 'components/features/Home/HomeCategories'
import { HomeTop } from 'components/features/Home/HomeTop'
import { CardAction } from 'components/shared/CardAction'
import { Corusel } from 'components/shared/Corusel'
import { phoneCall } from 'constants/app'
import { colors } from 'constants/colors'
import * as Linking from 'expo-linking'
import { useRefetchOnSwipe } from 'hooks'
import { Lecture } from 'interfaces/api/catalog.interfaces'
import { RootNavigationParamList } from 'interfaces/common.interfaces'
import { MainLayout } from 'layouts/MainLayout/MainLayout'
import { Routes } from 'routes/routes'
import { useAppDispatch, useAppSelector } from 'store'
import { getHomeCategories } from 'store/catalog/actions'
import { getBannerBlock, getHomeBlock, getHomeBlocks } from 'store/home/actions'
import { getByLections, getPayments } from 'store/payment/actions'
import { getListeningTimeUser, getUser } from 'store/user/actions'

type HomeProps = NativeStackScreenProps<RootNavigationParamList, Routes.Home>

const HomeScreen = ({ navigation, route }: HomeProps) => {
  const { blocks, banners } = useAppSelector((state) => state.home)
  const { list } = useAppSelector((state) => state.audio)

  const dispatch = useAppDispatch()

  const { isConnected } = useNetInfo()

  const fetchData = () => {
    if (isConnected) {
      dispatch(getHomeCategories())
      dispatch(getHomeBlocks())
      dispatch(getBannerBlock())
      dispatch(getByLections())
      dispatch(getPayments())
      dispatch(getListeningTimeUser())
    }
  }

  const { refreshing, onRefresh } = useRefetchOnSwipe(fetchData)

  useFocusEffect(
    useCallback(() => {
      if (isConnected) {
        dispatch(getUser())
      }
    }, [list]),
  )

  useEffect(() => {
    if (blocks.list.length && isConnected) {
      blocks.list.forEach((item) => dispatch(getHomeBlock(item.slug)))
    }
  }, [blocks.list])

  useEffect(() => {
    fetchData()
  }, [isConnected])

  const onPressBanner = (lection: Lecture) => {
    navigation.navigate(Routes.Lecture, { lecture: lection, lecturesList: [] })
  }

  return (
    <MainLayout pageName={route.name}>
      <ScrollView
        refreshControl={<RefreshControl onRefresh={onRefresh} refreshing={refreshing} tintColor={colors.white} />}
        showsVerticalScrollIndicator={false}
        style={[appStyles.flex1, appStyles.mainPaddingBottom, appStyles.mainMarginTop]}
      >
        <View style={appStyles.flex1}>
          <View style={[appStyles.mainPaddingHorizontal, appStyles.mainPaddingBottom]}>
            <CardAction
              onPress={() => {
                navigation.navigate(Routes.Static, { isPublic: true, slug: 'free-help' })
              }}
              onPressIcon={() => {
                Linking.openURL('tel:' + phoneCall)
              }}
            />
          </View>
          <HomeTop />
          {banners.items.length > 0 && (
            <Corusel
              images={banners.items.map((item) => ({
                ...item,
                onPress: item.lection ? () => onPressBanner(item.lection!) : undefined,
              }))}
            />
          )}
          <HomeCategories navigation={navigation} />
          {blocks.list?.map((item) => <HomeBlock item={item} key={item.id} />)}
        </View>
      </ScrollView>
    </MainLayout>
  )
}

export default HomeScreen
