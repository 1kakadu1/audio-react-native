import { FormProvider, useForm } from 'react-hook-form'

import { yupResolver } from '@hookform/resolvers/yup'
import { NativeStackScreenProps } from '@react-navigation/native-stack'
import { LoginButton } from 'components/features/Login/LoginButton'
import { RegisterTop } from 'components/features/Login/RegisterTop'
import { clearDirectory } from 'helpers'
import { useDevice } from 'hooks'
import { RegisterForm } from 'interfaces/api/auth.interfaces'
import { RootNavigationParamList } from 'interfaces/common.interfaces'
import { AuthLayout } from 'layouts/AuthLayout/AuthLayout'
import { Routes } from 'routes/routes'
import { persistor, useAppDispatch, useAppSelector } from 'store'
import { register } from 'store/auth/actions'
import { registerSchema } from 'utils/validation'

type RegisterScreenProps = NativeStackScreenProps<RootNavigationParamList, Routes.Register>

const RegisterScreen = ({ route }: RegisterScreenProps) => {
  const { loading } = useAppSelector((state) => state.auth)
  const { user } = useAppSelector((state) => state.user)

  const dispatch = useAppDispatch()

  const { deviceId } = useDevice()

  const methods = useForm<RegisterForm>({
    resolver: yupResolver(registerSchema),
    defaultValues: {
      name: '',
      email: '',
    },
  })

  const { handleSubmit } = methods

  const onSuccess = () => {
    if (user?.phone !== route.params.phone) {
      persistor.purge()
      clearDirectory()
    }
  }

  const onSubmit = (data: RegisterForm) => {
    dispatch(
      register({
        data: {
          ...data,
          device: deviceId,
          phone: route.params.phone,
          code: route.params.code,
        },
        onSuccess,
      }),
    )
  }

  return (
    <AuthLayout>
      <FormProvider {...methods}>
        <RegisterTop />
        <LoginButton disabled={false} loading={loading} onPress={handleSubmit(onSubmit)} title="Зарегистрироваться" />
      </FormProvider>
    </AuthLayout>
  )
}

export default RegisterScreen
