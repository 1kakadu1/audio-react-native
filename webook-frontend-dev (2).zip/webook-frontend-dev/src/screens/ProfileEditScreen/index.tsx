import { ScrollView } from 'react-native'

import { NativeStackScreenProps } from '@react-navigation/native-stack'
import { appStyles } from 'assets/styles/appStyles'
import { ProfileEditForm } from 'components/features/Profile/ProfileEditForm'
import { RootNavigationParamList } from 'interfaces/common.interfaces'
import { MainLayout } from 'layouts/MainLayout/MainLayout'
import { Routes } from 'routes/routes'

type ProfileEditScreenProps = NativeStackScreenProps<RootNavigationParamList, Routes.ProfileEdit>

const ProfileScreen = ({ route }: ProfileEditScreenProps) => (
  <MainLayout pageName={route.name}>
    <ScrollView
      contentContainerStyle={appStyles.flexGrow1}
      showsVerticalScrollIndicator={false}
      style={[appStyles.flex1, appStyles.mainMarginTop, appStyles.mainPaddingHorizontal]}
    >
      <ProfileEditForm />
    </ScrollView>
  </MainLayout>
)

export default ProfileScreen
