import { useEffect, useState } from 'react'

import { NativeStackScreenProps } from '@react-navigation/native-stack'
import { LoginBottom } from 'components/features/Login/LoginBottom'
import { LoginTop } from 'components/features/Login/LoginTop'
import { useDevice } from 'hooks'
import { RootNavigationParamList } from 'interfaces/common.interfaces'
import { AuthLayout } from 'layouts/AuthLayout/AuthLayout'
import { Routes } from 'routes/routes'
import { useAppDispatch } from 'store'
import { sendPhone } from 'store/auth/actions'

type LoginProps = NativeStackScreenProps<RootNavigationParamList, Routes.Login>

const LoginScreen = ({ navigation }: LoginProps) => {
  const [disabledContinue, setDisabledContinue] = useState(true)
  const [phone, setPhone] = useState('')

  const dispatch = useAppDispatch()

  const { deviceId } = useDevice()

  const onSendPhone = () => {
    dispatch(
      sendPhone({
        data: {
          phone,
          device: deviceId,
        },
        onSuccess: () => navigation.navigate(Routes.ConfirmPhone, { phone }),
      }),
    )
  }

  useEffect(() => {
    setDisabledContinue(phone.length < 12)
  }, [phone])

  return (
    <AuthLayout>
      <LoginTop setPhone={setPhone} />
      <LoginBottom disabledContinue={disabledContinue} onHandleContinue={onSendPhone} />
    </AuthLayout>
  )
}

export default LoginScreen
