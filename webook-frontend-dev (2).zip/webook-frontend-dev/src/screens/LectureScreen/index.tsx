import { useLayoutEffect } from 'react'
import { ScrollView } from 'react-native'

import { NativeStackScreenProps } from '@react-navigation/native-stack'
import { appStyles } from 'assets/styles/appStyles'
import { Lecture } from 'components/features/Lectures/Lecture'
import { useAudioPlayerContext } from 'contexts/AudioPlayerContext'
import { RootNavigationParamList } from 'interfaces/common.interfaces'
import { MainLayout } from 'layouts/MainLayout/MainLayout'
import { Routes } from 'routes/routes'

type LectureScreenProps = NativeStackScreenProps<RootNavigationParamList, Routes.Lecture>

const LectureScreen = ({ route, navigation }: LectureScreenProps) => {
  const { setIsWidgetOnBottom } = useAudioPlayerContext()

  useLayoutEffect(() => {
    const parent = navigation.getParent()
    parent?.setOptions({ tabBarStyle: { display: 'none' } })
    setIsWidgetOnBottom(true)
    return () => {
      parent?.setOptions({ tabBarStyle: appStyles.tabBarStyle })
      setIsWidgetOnBottom(false)
    }
  })

  return (
    <MainLayout isFullScreen pageName={route.name}>
      <ScrollView showsVerticalScrollIndicator={false} style={[appStyles.flex1, appStyles.mainMarginTop]}>
        <Lecture item={route.params.lecture} lectures={route.params.lecturesList} />
      </ScrollView>
    </MainLayout>
  )
}

export default LectureScreen
