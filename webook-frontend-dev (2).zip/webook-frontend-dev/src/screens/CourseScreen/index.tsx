import { NativeStackScreenProps } from '@react-navigation/native-stack'
import { Course } from 'components/features/Course/Course'
import { RootNavigationParamList } from 'interfaces/common.interfaces'
import { MainLayout } from 'layouts/MainLayout/MainLayout'
import { Routes } from 'routes/routes'

type CourseScreenProps = NativeStackScreenProps<RootNavigationParamList, Routes.Course>

const CourseScreen = ({ route }: CourseScreenProps) => (
  <MainLayout pageName={route.name}>
    <Course courseId={route.params.courseId} />
  </MainLayout>
)

export default CourseScreen
