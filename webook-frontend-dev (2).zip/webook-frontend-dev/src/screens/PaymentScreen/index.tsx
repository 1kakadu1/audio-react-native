import { SafeAreaView } from 'react-native-safe-area-context'
import WebView from 'react-native-webview'

import { NativeStackScreenProps } from '@react-navigation/native-stack'
import { appStyles } from 'assets/styles/appStyles'
import { RootNavigationParamList } from 'interfaces/common.interfaces'
import { MainLayout } from 'layouts/MainLayout/MainLayout'
import { Routes } from 'routes/routes'

type PurchaseProps = NativeStackScreenProps<RootNavigationParamList, Routes.Payment>

const PaymentScreen = ({ route }: PurchaseProps) => {
  const { uri, onNavigationStateChange } = route.params

  return (
    <MainLayout isFullScreen pageName={route.name}>
      <SafeAreaView style={appStyles.flex1}>
        <WebView
          onNavigationStateChange={(navState) => {
            onNavigationStateChange(navState)
          }}
          source={{ uri }}
          style={appStyles.flex1}
          userAgent="Mozilla/5.0 (Linux; Android 8.0.0; Pixel 2 XL Build/OPD1.170816.004) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3714.0 Mobile Safari/537.36"
        />
      </SafeAreaView>
    </MainLayout>
  )
}

export default PaymentScreen
