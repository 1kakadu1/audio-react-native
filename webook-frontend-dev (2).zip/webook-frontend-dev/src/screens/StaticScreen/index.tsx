import { NativeStackScreenProps } from '@react-navigation/native-stack'
import { Static } from 'components/features/Static/Static/Static'
import { RootNavigationParamList } from 'interfaces/common.interfaces'
import { PublicLayout } from 'layouts/PublicLayout/PublicLayout'
import { Routes } from 'routes/routes'

type StaticScreenProps = NativeStackScreenProps<RootNavigationParamList, Routes.Static>

const StaticScreen = ({ route }: StaticScreenProps) => (
  <PublicLayout isPublic={route.params.isPublic}>
    <Static slug={route.params.slug} />
  </PublicLayout>
)

export default StaticScreen
