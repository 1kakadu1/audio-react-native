import { NativeStackScreenProps } from '@react-navigation/native-stack'
import { Categories } from 'components/features/Category/Categories'
import { RootNavigationParamList } from 'interfaces/common.interfaces'
import { MainLayout } from 'layouts/MainLayout/MainLayout'
import { Routes } from 'routes/routes'

export type CategoriesProps = NativeStackScreenProps<RootNavigationParamList, Routes.Categories>

const CategoriesScreen = ({ navigation, route }: CategoriesProps) => (
  <MainLayout pageName={route.name}>
    <Categories navigation={navigation} />
  </MainLayout>
)

export default CategoriesScreen
