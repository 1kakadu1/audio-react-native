import { FC } from 'react'

import { AuthNavigation } from 'components/templates/AuthNavigation/AuthNavigation'
import { TabNavigation } from 'components/templates/TabNavigation'
import { useAppSelector } from 'store'

export const RenderRoute: FC = () => {
  const { isLoggedIn } = useAppSelector((state) => state.auth)

  return <>{isLoggedIn ? <TabNavigation /> : <AuthNavigation />}</>
}
