import { useEffect, useRef, useState } from 'react'

import { formatSecondsToTime } from 'helpers'

export const useTimer = (seconds: number, isTimerStarted?: boolean, setIsTimerStarted?: (value: boolean) => void) => {
  const [isTimerOver, setIsTimerOver] = useState(false)
  const [time, setTime] = useState(seconds)
  const timerRef = useRef(time)

  const secondsLeft = formatSecondsToTime(time, true)

  useEffect(() => {
    if (isTimerStarted) {
      setIsTimerOver(false)
      const timerId = setInterval(() => {
        timerRef.current -= 1
        if (timerRef.current < 0) {
          clearInterval(timerId)
        } else {
          setTime(timerRef.current)
        }
      }, 1000)
      return () => {
        clearInterval(timerId)
      }
    } else {
      setTime(seconds)
      timerRef.current = seconds
    }
  }, [isTimerStarted])

  useEffect(() => {
    if (time === 0) {
      setIsTimerOver(true)
      setIsTimerStarted?.(false)
    }
  }, [time])

  return { isTimerOver, secondsLeft }
}
