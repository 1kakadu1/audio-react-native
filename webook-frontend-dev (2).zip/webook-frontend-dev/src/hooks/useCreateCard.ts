import { useState } from 'react'
import Snackbar from 'react-native-snackbar'
import { WebViewNavigation } from 'react-native-webview'

import { api } from 'api'
import { legalAssistantURL } from 'constants/app'
import { colors } from 'constants/colors'
import { Navigation } from 'interfaces/common.interfaces'
import { Routes } from 'routes/routes'
import { useAppDispatch } from 'store'
import { setUserCard } from 'store/user/actions'

export const useCreateCard = ({ navigation, offBack = false }: { navigation: Navigation; offBack?: boolean }) => {
  const dispath = useAppDispatch()
  const [loading, setLoading] = useState(false)
  const onNavigationStateChange = (value: WebViewNavigation, onSuccess?: () => void) => {
    const urlParams = new URLSearchParams(value.url.split('?')[1])
    const orderId = urlParams.get('orderId')
    if (orderId) {
      api.order
        .checkPayVerification({ order_id: orderId })
        .then((res) => {
          if (res.success === true) {
            api.order.getOrderCard().then((_res) => {
              dispath(setUserCard(_res.token))
            })

            if (onSuccess) {
              onSuccess()
            }

            if (offBack === false) {
              navigation.goBack()
            }
          } else {
            throw Error('Проблема с возвратом. success = false')
          }
        })
        .catch((error) => {
          Snackbar.show({ text: error.toString(), backgroundColor: colors.red })
          navigation.goBack()
        })
    }
  }
  const onCreateCard = (onSuccess?: () => void) => {
    setLoading(true)
    api.order
      .createPayVerification({ callback_url: legalAssistantURL })
      .then((res) => {
        navigation.navigate(Routes.Payment, {
          uri: res.payGateway,
          onNavigationStateChange: (value) => onNavigationStateChange(value, onSuccess),
        })
      })
      .catch((e) => {
        setLoading(false)
        Snackbar.show({ text: JSON.stringify(e), backgroundColor: colors.red })
      })
  }

  return {
    onCreateCard,
    loading,
  }
}
