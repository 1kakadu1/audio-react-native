import { useState } from 'react'

export const useRefetchOnSwipe = (fn: VoidFunction) => {
  const [refreshing, setRefreshing] = useState(false)

  const onRefresh = () => {
    setRefreshing(true)
    fn()
    setTimeout(() => {
      setRefreshing(false)
    }, 1000)
  }

  return { refreshing, onRefresh }
}
