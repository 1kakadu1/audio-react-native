import Snackbar from 'react-native-snackbar'

import { FileErrorMessage } from 'constants/actionMessages'
import { colors } from 'constants/colors'
import { useDownloadContext } from 'contexts/DownloadContext'
import { createDownloadResumable, documentDirectory } from 'expo-file-system'
import { convertHttpToHttps, deleteFile } from 'helpers'
import { Lecture } from 'interfaces/api/catalog.interfaces'
import { useAppDispatch, useAppSelector } from 'store'
import { addAudioDownloadedList } from 'store/audio/actions'

export const useDownloadAudio = () => {
  const dispatch = useAppDispatch()

  const token = useAppSelector((state) => state.auth.token)

  const { setDownloadQueue, setDownloadProgress } = useDownloadContext()

  const download = async (data: Lecture) => {
    const fileUri = documentDirectory + `${data.id}.mp3`

    const downloadResumable = createDownloadResumable(convertHttpToHttps(data.audio), fileUri, {
      headers: { Authorization: `Bearer ${token}` },
    })

    try {
      await downloadResumable.downloadAsync()
      dispatch(addAudioDownloadedList({ ...data, audio: fileUri }))
      setDownloadQueue((prev) => prev.filter((item: any) => item.id !== data.id))
      setDownloadProgress({ [data.id]: 100 })
    } catch (e) {
      deleteFile(fileUri)
      setDownloadQueue([])
      Snackbar.show({
        text: FileErrorMessage.DownloadError,
        backgroundColor: colors.red,
        duration: 10000,
        numberOfLines: 3,
        marginBottom: 72,
      })
    }
  }

  return { download }
}
