import { useEffect, useState } from 'react'
import TrackPlayer, {
  AppKilledPlaybackBehavior,
  Capability,
  State,
  Track,
  useActiveTrack,
  usePlaybackState,
  useProgress,
} from 'react-native-track-player'

import { documentDirectory } from 'expo-file-system'
import { useAppDispatch, useAppSelector } from 'store'
import { setPlaylist } from 'store/audio/actions'
import { addTrack, capabilities, setupPlayer } from 'utils/playerServices'

export const useAudioControl = () => {
  const [isPlayerReady, setIsPlayerReady] = useState(false)

  const { playlist, currentTrack: currentStateTrack, audioProgress } = useAppSelector((state) => state.audio)
  const { isLoggedIn } = useAppSelector((state) => state.auth)

  const dispatch = useAppDispatch()

  const { state: playBackState } = usePlaybackState()
  const { position, duration } = useProgress(800)
  const activeTrack = useActiveTrack()

  const currentTrackIndex = playlist.findIndex((item) => item.id === activeTrack?.id)
  const isFirstTrack = currentTrackIndex === 0
  const isLastTrack = currentTrackIndex === playlist.length - 1

  const hideNext = async (isFirst?: boolean, isLast?: boolean) => {
    setTimeout(() => {
      const filteredCapabilities = capabilities
        .filter((item) => (isFirst ? item !== Capability.SkipToPrevious : item))
        .filter((item) => (isLast ? item !== Capability.SkipToNext : item))
      TrackPlayer.updateOptions({
        capabilities: filteredCapabilities,
        compactCapabilities: filteredCapabilities,
        android: {
          appKilledPlaybackBehavior: AppKilledPlaybackBehavior.StopPlaybackAndRemoveNotification,
        },
      })
    })
  }

  const rewind = async (disabled?: boolean | null) => {
    if (!disabled) {
      const currentPosition = await TrackPlayer.getProgress()
      TrackPlayer.seekTo(currentPosition.position > 10 ? currentPosition.position - 10 : 0)
    }
  }

  const forward = async (disabled?: boolean | null) => {
    if (!disabled && activeTrack?.duration) {
      const currentPosition = await TrackPlayer.getProgress()
      if (activeTrack?.duration - 30 > activeTrack?.duration) {
        await TrackPlayer.seekTo(activeTrack?.duration)
        TrackPlayer.stop()
      } else {
        TrackPlayer.seekTo(currentPosition.position + 30)
      }
    }
  }

  const onSlidingComplete = async (value: number) => {
    await TrackPlayer.seekTo(value)
  }

  const skipToPosition = async (pos: number, disabled?: boolean | null) => {
    if (!disabled) {
      await TrackPlayer.seekTo(pos)
    }
  }

  const togglePlayback = async (playback?: State, disabled?: boolean | null) => {
    if (disabled || activeTrack === null) {
      return
    }

    if (playback === State.Paused || playback === State.Ready) {
      await TrackPlayer.play()
    } else if (playback === State.Ended) {
      await skipToPosition(0)
      await TrackPlayer.play()
    } else {
      await TrackPlayer.pause()
    }
  }

  const skipToNext = async (disabled?: boolean | null) => {
    if (!disabled) {
      const queue = await TrackPlayer.getQueue()
      const id = queue[queue.findIndex((item) => item.id === activeTrack?.id) + 1].id
      await TrackPlayer.skipToNext(audioProgress[id] ?? 0)
    }
  }

  const skipToTrack = async (index: number) => {
    const queue = await TrackPlayer.getQueue()
    const nextTrack = queue[index]
    await TrackPlayer.skip(index, audioProgress[nextTrack?.id] ?? 0)
    if (playBackState) {
      await TrackPlayer.play()
    }
  }

  const skipToPrev = async (disabled?: boolean | null) => {
    if (!disabled) {
      const queue = await TrackPlayer.getQueue()
      const id = queue[queue.findIndex((item) => item.id === activeTrack?.id) - 1].id
      await TrackPlayer.skipToPrevious(audioProgress[id] ?? 0)
    }
  }

  async function setup(tracks: Track[]) {
    const isSetup = await setupPlayer()

    if (isSetup) {
      await TrackPlayer.reset()
      await addTrack(tracks.map((item) => ({ ...item, artist: item.courseTitle })))
      const trackIndex = playlist.findIndex((item) => item.id === currentStateTrack)
      if (trackIndex > -1) {
        await skipToTrack(trackIndex)
      }
      if (trackIndex > -1 && trackIndex === 0 && currentStateTrack) {
        await TrackPlayer.seekTo(audioProgress[currentStateTrack] ?? 0)
      }
    }

    setIsPlayerReady(isSetup)
  }

  const clearPlaylist = async () => {
    if (isPlayerReady) {
      await TrackPlayer.stop()
      await TrackPlayer.reset()
      dispatch(setPlaylist([]))
      setIsPlayerReady(false)
    }
  }

  useEffect(() => {
    if (playlist.length && isLoggedIn) {
      setup(
        playlist.map((item) => ({
          ...item,
          artwork: item?.image ?? require('assets/images/empty-image.jpeg'),
          url: `${documentDirectory}${item.id}.mp3`,
        })),
      )
    }
    if (!isLoggedIn) {
      clearPlaylist()
    }
  }, [playlist, isLoggedIn])

  useEffect(() => {
    if (isPlayerReady) {
      hideNext(isFirstTrack, isLastTrack)
    }
  }, [isFirstTrack, isLastTrack, isPlayerReady])

  return {
    isPlayerReady,
    playBackState,
    position,
    duration,
    activeTrack,
    isFirstTrack,
    isLastTrack,
    rewind,
    forward,
    onSlidingComplete,
    togglePlayback,
    skipToNext,
    skipToPrev,
    skipToTrack,
    skipToPosition,
    clearPlaylist,
  }
}
