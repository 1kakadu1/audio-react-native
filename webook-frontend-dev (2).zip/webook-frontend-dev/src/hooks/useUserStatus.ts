import { useMemo } from 'react'

import { useAppSelector } from 'store'

export const useUserStatus = () => {
  const { user } = useAppSelector((state) => state.user)
  const statusInfo = useMemo(() => {
    if (user?.isSubscribed) {
      return {
        title: '' + (user.subscriptionExpiresAt || ''),
        description: undefined,
        status: true,
      }
    }

    return {
      status: false,
      title: 'Подписка не активирована',
      description:
        'Приобретите подписку, чтобы получить доступ к бесплатным урокам и иметь возможность получить сертификат',
    }
  }, [user])

  return statusInfo
}
