import { StackActions, useNavigation } from '@react-navigation/native'
import { Lecture } from 'interfaces/api/catalog.interfaces'
import { Navigation } from 'interfaces/common.interfaces'
import { Routes } from 'routes/routes'
import { useAppSelector } from 'store'

export const usePayToScreen = () => {
  const navigation = useNavigation<Navigation>()
  const { user } = useAppSelector((state) => state.user)
  const { paymentsSubsribe } = useAppSelector((store) => store.payments)
  const payment = paymentsSubsribe.payments[0]
  const goPayScreen = ({
    goBack,
    lection,
    onSuccess,
  }: {
    goBack?: boolean
    lection?: Lecture
    onSuccess?: () => void
  }) => {
    navigation.navigate(
      Routes.Purchase,
      user?.activeSub && lection
        ? { price: lection.price, lectureId: lection.id, title: lection.title, onSuccess }
        : {
            isSubscription: true,
            price: payment?.price.toString() || '699',
            title: payment?.name,
            subscriptionId: payment?.id || null,
            goBack,
            onSuccess,
          },
    )
  }
  const goCreateCardToPaySubscribe = () => {
    navigation.navigate(Routes.CardPurchase, {
      isCard: true,
      onSuccess: () => {
        const popAction = StackActions.pop(2)
        navigation.dispatch(popAction)
        setTimeout(() => {
          goPayScreen({ lection: undefined })
        }, 100)
      },
    })
  }
  return {
    goPayScreen,
    goCreateCardToPaySubscribe,
  }
}
