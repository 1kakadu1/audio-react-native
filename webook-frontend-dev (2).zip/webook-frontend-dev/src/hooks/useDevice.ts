import { useEffect, useState } from 'react'
import { getUniqueId } from 'react-native-device-info'

export const useDevice = () => {
  const [deviceId, setDeviceId] = useState('')

  useEffect(() => {
    getUniqueId().then((data) => setDeviceId(data))
  }, [])

  return { deviceId }
}
