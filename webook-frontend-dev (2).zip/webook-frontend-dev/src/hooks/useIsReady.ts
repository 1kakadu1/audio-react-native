import { useEffect, useState } from 'react'

export const useIsReady = () => {
  const [isReady, setIsReady] = useState(false)

  useEffect(() => {
    setTimeout(() => setIsReady(true))
  }, [])

  return isReady
}
