import { FC, PropsWithChildren } from 'react'
import { Dimensions, View } from 'react-native'
import LinearGradient from 'react-native-linear-gradient'
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context'

import { useNetInfo } from '@react-native-community/netinfo'
import { appStyles } from 'assets/styles/appStyles'
import { DisconnectedBlock } from 'components/templates/DisconnectedBlock'

import styles from './AuthLayout.styles'

export const AuthLayout: FC<PropsWithChildren> = ({ children }) => {
  const insets = useSafeAreaInsets()

  const { isConnected } = useNetInfo()

  const { height, width } = Dimensions.get('screen')

  return (
    <SafeAreaView style={[appStyles.flex1, appStyles.mainBackground, { paddingTop: -insets.top }]}>
      <View style={styles.gradientWrap}>
        <LinearGradient
          colors={['rgba(254, 239, 136, 0.35)', 'rgba(17, 17, 17, 0)']}
          end={{ x: 0.4, y: 0.1 }}
          start={{ x: 1, y: 0 }}
          style={{ width, height: height * 1.5 }}
        />
      </View>
      <View
        style={[
          appStyles.flex1,
          appStyles.mainPaddingHorizontal,
          appStyles.mainPaddingBottom,
          isConnected !== false && appStyles.mainMarginTop,
        ]}
      >
        {isConnected !== false ? children : <DisconnectedBlock />}
      </View>
    </SafeAreaView>
  )
}
