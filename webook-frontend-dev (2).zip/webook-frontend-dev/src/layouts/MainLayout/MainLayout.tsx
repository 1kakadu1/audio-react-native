import { FC, PropsWithChildren } from 'react'
import { Dimensions, ImageBackground, View } from 'react-native'
import LinearGradient from 'react-native-linear-gradient'
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context'

import { appStyles } from 'assets/styles/appStyles'
import { useAudioPlayerContext } from 'contexts/AudioPlayerContext'
import { Routes } from 'routes/routes'

import styles from './MainLayout.styles'

interface Props extends PropsWithChildren {
  pageName?: Routes
  isFullScreen?: boolean
}

export const MainLayout: FC<Props> = ({ pageName, children, isFullScreen }) => {
  const insets = useSafeAreaInsets()

  const { isWidgetPlayerHidden } = useAudioPlayerContext()

  const { height, width } = Dimensions.get('screen')

  return (
    <View style={[appStyles.flex1, appStyles.mainBackground]}>
      <View style={styles.imageWrap}>
        {pageName === Routes.Lecture && (
          <ImageBackground
            resizeMode="cover"
            source={require('assets/images/bg-yellow-sphere.webp')}
            style={styles.image}
          />
        )}
      </View>
      <View style={styles.gradientWrap}>
        {(pageName === Routes.Home ||
          pageName === Routes.Lectures ||
          pageName === Routes.Lecture ||
          pageName === Routes.Statics ||
          pageName === Routes.Categories ||
          pageName === Routes.Profile ||
          pageName === Routes.ProfileEdit ||
          pageName === Routes.Category) && (
          <LinearGradient
            colors={['rgba(254, 239, 136, 0.35)', 'rgba(17, 17, 17, 0)']}
            end={{ x: 0.4, y: 0.1 }}
            start={{ x: 1, y: 0 }}
            style={{ width, height: height * 1.5 }}
          />
        )}
      </View>
      <SafeAreaView
        style={[
          appStyles.flex1,
          (!isFullScreen || (isFullScreen && !isWidgetPlayerHidden)) && appStyles.mainMarginBottom,
          !isWidgetPlayerHidden && !isFullScreen && styles.bigMarginBottom,
          { paddingTop: -insets.top },
        ]}
      >
        {children}
      </SafeAreaView>
    </View>
  )
}
