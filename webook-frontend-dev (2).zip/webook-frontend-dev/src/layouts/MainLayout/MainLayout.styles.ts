import { StyleSheet } from 'react-native'

export default StyleSheet.create({
  image: {
    height: 340,
    opacity: 1,
    width: 140,
  },
  imageWrap: {
    alignItems: 'flex-end',
    left: 0,
    position: 'absolute',
    right: 0,
    top: -16,
    transform: [{ rotate: '270deg' }],
  },
  gradientWrap: {
    left: 0,
    position: 'absolute',
    right: 0,
    top: 0,
  },
  bigMarginBottom: {
    marginBottom: 132,
  },
})
