import TrackPlayer from 'react-native-track-player'

import { registerRootComponent } from 'expo'

import 'react-native-devsettings'
import 'react-native-devsettings/withAsyncStorage'
import 'react-native-gesture-handler'

import App from './App'
import { playbackService } from './utils/playerServices'

registerRootComponent(App)
TrackPlayer.registerPlaybackService(() => playbackService)
