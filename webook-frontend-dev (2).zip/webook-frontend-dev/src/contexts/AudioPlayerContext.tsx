import React, { createContext, FC, PropsWithChildren, useContext, useEffect, useState } from 'react'
import { State, Track } from 'react-native-track-player'

import { AudioPlayerWidget } from 'components/shared/AudioPlayerWidget'
import { useAudioControl } from 'hooks'
import { useAppDispatch, useAppSelector } from 'store'
import { setAudioProgress, setCurrentTrack } from 'store/audio/actions'

interface AudioPlayerContextType {
  duration: number
  forward: (disabled?: boolean | null) => Promise<void>
  isPlayerReady: boolean
  onSlidingComplete: (value: number) => Promise<void>
  playBackState: State | undefined
  position: number
  activeTrack: Track | undefined
  isFirstTrack: boolean
  isLastTrack: boolean
  isWidgetPlayerHidden: boolean
  isWidgetOnBottom: boolean
  setIsWidgetPlayerHidden: (value: boolean) => void
  setIsWidgetOnBottom: (value: boolean) => void
  rewind: (disabled?: boolean | null) => Promise<void>
  togglePlayback: (playback?: State | undefined, disabled?: boolean | null) => Promise<void>
  skipToNext: (disabled?: boolean | null) => Promise<void>
  skipToPrev: (disabled?: boolean | null) => Promise<void>
  skipToTrack: (index: number) => Promise<void>
  skipToPosition: (pos: number, disabled?: boolean | null) => Promise<void>
  clearPlaylist: VoidFunction
}

const AudioPlayerContext = createContext<AudioPlayerContextType | undefined>(undefined)

export const useAudioPlayerContext = () => {
  const context = useContext(AudioPlayerContext)
  if (!context) {
    throw new Error('useAudioPlayerContext must be used within a AudioPlayerProvider')
  }
  return context
}

export const AudioPlayerProvider: FC<PropsWithChildren> = ({ children }) => {
  const [isWidgetPlayerHidden, setIsWidgetPlayerHidden] = useState(true)
  const [isWidgetOnBottom, setIsWidgetOnBottom] = useState(false)

  const { currentTrack } = useAppSelector((state) => state.audio)

  const dispatch = useAppDispatch()

  const {
    duration,
    forward,
    isPlayerReady,
    onSlidingComplete,
    playBackState,
    position,
    activeTrack,
    isFirstTrack,
    isLastTrack,
    rewind,
    togglePlayback,
    skipToNext,
    skipToPrev,
    skipToTrack,
    skipToPosition,
    clearPlaylist,
  } = useAudioControl()

  useEffect(() => {
    if (activeTrack?.id !== undefined && activeTrack?.id !== null && position > 3) {
      dispatch(setAudioProgress({ id: activeTrack.id, progress: position }))
      if (duration && Math.ceil(position) >= duration) {
        setTimeout(() => dispatch(setAudioProgress({ id: activeTrack.id, progress: 0 })), 300)
      }
    }
  }, [Math.floor(position / 3)])

  useEffect(() => {
    if (playBackState !== State.Playing) {
      setIsWidgetPlayerHidden(!isPlayerReady)
    }
  }, [isPlayerReady])

  useEffect(() => {
    if (activeTrack && currentTrack !== activeTrack?.id && playBackState === State.Playing) {
      dispatch(setCurrentTrack(activeTrack.id))
    }
  }, [activeTrack, playBackState])

  return (
    <AudioPlayerContext.Provider
      value={{
        duration,
        forward,
        isPlayerReady,
        onSlidingComplete,
        playBackState,
        position,
        activeTrack,
        isFirstTrack,
        isLastTrack,
        isWidgetPlayerHidden,
        setIsWidgetPlayerHidden,
        isWidgetOnBottom,
        setIsWidgetOnBottom,
        rewind,
        togglePlayback,
        skipToNext,
        skipToPrev,
        skipToTrack,
        skipToPosition,
        clearPlaylist,
      }}
    >
      {children}
      {!isWidgetPlayerHidden && (
        <AudioPlayerWidget
          activeTrack={activeTrack}
          clearPlaylist={clearPlaylist}
          duration={duration}
          isWidgetOnBottom={isWidgetOnBottom}
          playBackState={playBackState}
          position={position}
          setIsWidgetPlayerHidden={setIsWidgetPlayerHidden}
          togglePlayback={togglePlayback}
        />
      )}
    </AudioPlayerContext.Provider>
  )
}
