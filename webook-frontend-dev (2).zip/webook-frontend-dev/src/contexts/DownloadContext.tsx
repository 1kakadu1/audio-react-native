import React, {
  createContext,
  Dispatch,
  FC,
  PropsWithChildren,
  SetStateAction,
  useContext,
  useEffect,
  useState,
} from 'react'

import { Lecture } from 'interfaces/api/catalog.interfaces'
import { useAppDispatch, useAppSelector } from 'store'
import { getListeningTimeUser } from 'store/user/actions'

interface DownloadContextType {
  downloadQueue: Lecture[]
  setDownloadQueue: Dispatch<SetStateAction<Lecture[]>>
  downloadProgress: Record<number, number>
  setDownloadProgress: Dispatch<SetStateAction<Record<number, number>>>
}

const DownloadContext = createContext<DownloadContextType | undefined>(undefined)

export const useDownloadContext = () => {
  const context = useContext(DownloadContext)
  if (!context) {
    throw new Error('useDownloadContext must be used within a DownloadProvider')
  }
  return context
}

export const DownloadProvider: FC<PropsWithChildren> = ({ children }) => {
  const [downloadQueue, setDownloadQueue] = useState<Lecture[]>([])
  const [downloadProgress, setDownloadProgress] = useState<Record<number, number>>({})
  const dispatch = useAppDispatch()
  const { loading } = useAppSelector((state) => state.user.listeningTime)

  useEffect(() => {
    if (!loading && Object.keys(downloadProgress).length > 0) {
      dispatch(getListeningTimeUser())
    }
  }, [downloadProgress, downloadQueue])

  return (
    <DownloadContext.Provider value={{ downloadQueue, setDownloadQueue, downloadProgress, setDownloadProgress }}>
      {children}
    </DownloadContext.Provider>
  )
}
